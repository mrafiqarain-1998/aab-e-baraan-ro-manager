/**
 * ============================================================================
 * AAB-E-BARAAN RO WATER PLANT - TECHNICAL DESIGN SYSTEM & BUSINESS FORMULAS
 * آب باران منرل واٹر پلانٹ - ٹیکنیکل ڈیزائن سسٹم، فنانشل فارمولاز اور کمپوننٹ گائیڈ
 * ============================================================================
 * 
 * This file serves as the single source of architectural truth for any developer
 * maintaining or extending this application. It details:
 * 1. Color Palette Tokens & Usage Guidelines
 * 2. Typography Scale (Mobile-Optimized)
 * 3. Button Styles & Design Patterns
 * 4. Business & Financial Formulas (Ledger, Inventories, Cash Closing, Dues)
 * 5. Bottle Returnable vs One-Time Usage Rules
 */

// ============================================================================
// 1. COLOR PALETTE TOKENS (رنگوں کا نظام)
// ============================================================================
export const APP_COLORS = {
  // Primary Brand Colors (بنیادی برانڈ رنگ)
  brandNavy: '#0A2540',      // Used for: Top AppBar, Primary CTA buttons, Headings, Selected tabs
  brandTeal: '#00A896',      // Used for: Accent highlights, Active icons, Logo accents
  brandTealDeep: '#028090',  // Used for: Secondary actions, links, contact badges
  
  // Background Colors (بیک گراؤنڈ رنگ)
  bgCanvas: '#F0F7FB',       // Used for: Main application background (Pure light mineral water tint)
  bgCard: '#FFFFFF',         // Used for: Content cards, modals, tables
  bgCardSubtle: '#F8FAFC',   // Used for: Table headers, nested cards, input fields
  bgIceBlue: '#E8F4F8',      // Used for: Customer code badges, highlight panels
  
  // Financial & Operational Status Colors (مالی و آپریشنل سٹیٹس)
  successGreen: '#10B981',   // Used for: Paid invoices, cash collections, positive credits, return empties
  successBg: '#D1FAE5',      // Used for: Paid status badges, WhatsApp success
  dangerRed: '#EF4444',      // Used for: Outstanding customer dues (ادھار), OPEX expenses, cancel
  dangerBg: '#FEE2E2',       // Used for: Dues warning badges, delete modals
  warningAmber: '#F59E0B',   // Used for: Partial payments, pending approvals, missing rates
  warningBg: '#FEF3C7',      // Used for: Warning banners, partial badges
  
  // Neutral Typography & Borders (ٹیکسٹ اور بارڈرز)
  textPrimary: '#0F172A',    // Used for: Primary body text, customer names
  textSecondary: '#475569',  // Used for: Subtitles, areas, descriptions
  textMuted: '#94A3B8',      // Used for: Placeholder text, timestamps, captions
  borderColor: '#CBD5E1',    // Used for: Card borders, input outlines, table dividers
};

// ============================================================================
// 2. TYPOGRAPHY SCALE (فونٹ سائز گائیڈ)
// ============================================================================
export const TYPOGRAPHY_SCALE = {
  // Mobile-Optimized Sizes
  micro: 'text-[9px]',       // Used for: Invoice timestamps, subtle table sub-labels, badge tags
  caption: 'text-[10px]',    // Used for: Customer code tags, area subtext, dropdown option details
  compact: 'text-[11px]',    // Used for: Dropdown selects, table data cells, form labels, phone numbers
  bodySmall: 'text-xs',      // Used for: Standard card content, summary statistics (12px)
  body: 'text-sm',           // Used for: Section titles, customer names, grand totals (14px)
  heading: 'text-base',      // Used for: Modal headers, screen top titles (16px)
  display: 'text-lg',        // Used for: Cash drawer totals, dashboard revenue figures (18px)
};

// ============================================================================
// 3. BUTTON DESIGN PATTERNS (بٹن سٹائلز)
// ============================================================================
export const BUTTON_STYLES = {
  // Primary CTA (e.g. Save Customer, Dispatch Delivery)
  primary: 'bg-[#0A2540] hover:bg-[#07192C] text-white font-bold text-xs py-2.5 px-4 rounded-xl shadow-xs transition-all active:scale-95',
  
  // Emerald Financial Action (e.g. Receive Payment, Confirm Rate)
  success: 'bg-[#10B981] hover:bg-[#059669] text-white font-bold text-xs py-2 px-3 rounded-xl shadow-xs transition-all active:scale-95',
  
  // Compact Payment Icon Button (on Credit Deliveries)
  iconPay: 'p-1.5 rounded-lg bg-[#10B981] hover:bg-[#059669] text-white shadow-xs transition-colors flex items-center justify-center',
  
  // Secondary / Cancel Button
  secondary: 'bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold text-xs py-2 px-4 rounded-xl transition-all',
  
  // Admin Action Pill (e.g. Edit Customer, Edit Delivery)
  adminEdit: 'py-1 px-2.5 rounded-xl bg-[#0A2540] hover:bg-[#028090] text-white font-bold text-[11px] flex items-center gap-1 shadow-xs transition-colors',
  
  // Danger / Delete Button
  danger: 'py-1.5 px-3 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold text-[11px] transition-colors',
};

// ============================================================================
// 4. BUSINESS & FINANCIAL FORMULAS (فنانشل اور آپریشنل فارمولے)
// ============================================================================
export const BUSINESS_FORMULAS = {
  /**
   * 1. Delivery Line Total Formula:
   * LineTotal = QuantityDelivered * AgreedCustomerRate
   */
  deliveryLineTotal: (qty: number, unitRate: number): number => qty * unitRate,

  /**
   * 2. Delivery Grand Total Formula:
   * GrandTotal = (Σ DeliveryLineTotals) + DeliveryCharges
   */
  deliveryGrandTotal: (lineTotalsSum: number, deliveryCharges: number): number => lineTotalsSum + deliveryCharges,

  /**
   * 3. Customer Balance Formula (Running Debt):
   * Balance = PreviousBalance + (TotalInvoiceAmount - PaymentCollected)
   * A positive balance represents money owed by the customer to the water plant (Receivable/ادھار).
   */
  customerBalanceDelta: (totalAmount: number, paymentCollected: number): number => totalAmount - paymentCollected,

  /**
   * 4. Returnable Bottle Custody Formula (صرف ملٹی ٹائم بوتلیں):
   * HeldDelta = ReturnableBottlesDelivered - EmptiesReturned
   * CRITICAL RULE: Disposable (ONE_TIME) bottles (such as 500 ML packets or 1.5 L disposable)
   * MUST NEVER be counted as held or owed bottles.
   * Only bottles with usageType === 'MULTIPLE_TIME' (or isReturnableBottle === true)
   * can be owed/held by customers.
   */
  returnableHeldDelta: (returnableDeliveredQty: number, emptiesReturnedQty: number): number => {
    return returnableDeliveredQty - emptiesReturnedQty;
  },

  /**
   * 5. Expected Cash Drawer Formula (ڈیلی کیش کلوزنگ فارمولا):
   * ExpectedClosing = OpeningCash + CustomerCollections + OtherCashIncome - CashExpenses - CashRefunds
   */
  expectedCashClosing: (
    openingCash: number,
    collections: number,
    otherIncome: number,
    cashExpenses: number,
    cashRefunds: number
  ): number => {
    return openingCash + collections + otherIncome - cashExpenses - cashRefunds;
  },

  /**
   * 6. Cash Difference Formula (کیش کمی یا بیشی):
   * Difference = ActualCountedCash - ExpectedClosingCash
   * If Difference > 0: Surplus (بیشی)
   * If Difference < 0: Shortage (کمی)
   */
  cashDifference: (actualCash: number, expectedCash: number): number => actualCash - expectedCash,
};
