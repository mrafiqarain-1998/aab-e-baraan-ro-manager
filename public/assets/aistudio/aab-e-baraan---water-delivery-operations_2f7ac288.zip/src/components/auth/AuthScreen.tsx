import React, { useState } from 'react';
import { useWaterApp } from '../../context/WaterAppContext';
import { 
  Droplet, 
  Lock, 
  User, 
  Eye, 
  EyeOff, 
  AlertCircle, 
  CheckCircle2, 
  Phone, 
  MessageSquare, 
  X, 
  ShieldCheck, 
  ArrowRight
} from 'lucide-react';

export const AuthScreen: React.FC = () => {
  const { login, businessProfile, requestPasswordReset } = useWaterApp();

  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  // Forgot password modal state
  const [showForgotModal, setShowForgotModal] = useState(false);
  const [forgotUsername, setForgotUsername] = useState('');
  const [forgotReason, setForgotReason] = useState('');
  const [resetSubmitted, setResetSubmitted] = useState(false);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const u = username.trim();
    const p = password.trim();

    if (!u || !p) {
      setError('Please enter both username and password (براہ کرم یوزر نیم اور پاس ورڈ درج کریں)');
      return;
    }

    setIsLoading(true);

    setTimeout(() => {
      const result = login(u, p);
      setIsLoading(false);

      if (!result.success) {
        setError(result.error || 'Invalid username or password. (غلط یوزر نیم یا پاس ورڈ)');
      }
    }, 250);
  };

  const handleSendResetRequest = (e: React.FormEvent) => {
    e.preventDefault();
    if (!forgotUsername.trim()) return;

    requestPasswordReset(forgotUsername.trim(), forgotReason || 'Password forgotten by staff member');
    setResetSubmitted(true);
    setTimeout(() => {
      setShowForgotModal(false);
      setResetSubmitted(false);
      setForgotUsername('');
      setForgotReason('');
    }, 2500);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0A2540] via-[#0F355A] to-[#0A2540] flex flex-col justify-center items-center p-4 text-[#0F172A] select-none relative overflow-hidden">
      
      {/* Background Ambient Droplets/Mountains */}
      <div className="absolute -top-24 -right-24 w-72 h-72 rounded-full bg-[#00A896]/10 blur-3xl pointer-events-none"></div>
      <div className="absolute -bottom-24 -left-24 w-72 h-72 rounded-full bg-[#028090]/15 blur-3xl pointer-events-none"></div>

      {/* Centered Mobile-first Login Card */}
      <div className="w-full max-w-sm bg-white rounded-3xl shadow-2xl overflow-hidden border border-white/20 relative z-10">
        
        {/* Top Header / Official Logo Banner */}
        <div className="bg-[#0A2540] text-white p-5 pt-6 text-center relative overflow-hidden">
          
          {/* Official Brand Logo Image */}
          <div className="relative mx-auto w-52 max-w-full py-1.5 mb-2.5 flex items-center justify-center bg-white/95 rounded-2xl p-2 shadow-lg ring-2 ring-[#00A896]/40">
            <img 
              src="/aab_e_baraan_logo.png" 
              alt="Aab-e-Baraan Natural Purity" 
              className="w-full max-h-24 object-contain"
            />
          </div>

          <h1 className="text-base font-black tracking-tight text-white">
            {businessProfile.businessName}
          </h1>
          <p className="text-xs text-[#00A896] font-urdu font-bold mt-0.5">
            {businessProfile.urduBusinessName || 'آبِ باراں منرل واٹر پلانٹ'}
          </p>

          <div className="mt-2 inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-white/10 text-[10px] text-[#E8F4F8]">
            <ShieldCheck className="w-3 h-3 text-[#00A896]" />
            <span>Authorized Plant Login (محفوظ لاگ ان)</span>
          </div>
        </div>

        {/* Login Form Body */}
        <div className="p-6 space-y-4">
          
          {error && (
            <div className="p-3 rounded-xl bg-red-50 border border-red-200 text-red-700 text-xs flex items-start gap-2 animate-in fade-in">
              <AlertCircle className="w-4 h-4 shrink-0 text-red-600 mt-0.5" />
              <div>
                <p className="font-semibold">{error}</p>
              </div>
            </div>
          )}

          <form onSubmit={handleLogin} className="space-y-3.5">
            
            {/* Username Input */}
            <div>
              <label className="block text-xs font-bold text-[#0A2540] mb-1">
                Username (یوزر نیم)
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                  <User className="w-4 h-4" />
                </div>
                <input
                  type="text"
                  required
                  autoCapitalize="none"
                  autoCorrect="off"
                  value={username}
                  onChange={(e) => {
                    setUsername(e.target.value);
                    if (error) setError(null);
                  }}
                  placeholder="Enter username (e.g. admin)"
                  className="w-full pl-9 pr-3 py-2.5 bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl text-xs sm:text-sm font-medium text-[#0F172A] placeholder-slate-400 focus:outline-none focus:border-[#0A2540] focus:ring-1 focus:ring-[#0A2540]"
                />
              </div>
            </div>

            {/* Password Input with Eye Toggle */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs font-bold text-[#0A2540]">
                  Password (پاس ورڈ)
                </label>
                <button
                  type="button"
                  onClick={() => setShowForgotModal(true)}
                  className="text-[11px] font-semibold text-[#028090] hover:text-[#0A2540] transition-colors"
                >
                  Forgot? (پاس ورڈ بھول گئے؟)
                </button>
              </div>

              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                  <Lock className="w-4 h-4" />
                </div>
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={password}
                  onChange={(e) => {
                    setPassword(e.target.value);
                    if (error) setError(null);
                  }}
                  placeholder="Enter your password"
                  className="w-full pl-9 pr-10 py-2.5 bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl text-xs sm:text-sm font-medium text-[#0F172A] placeholder-slate-400 focus:outline-none focus:border-[#0A2540] focus:ring-1 focus:ring-[#0A2540]"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-400 hover:text-slate-600 focus:outline-none"
                  title={showPassword ? "Hide password" : "Show password"}
                >
                  {showPassword ? (
                    <EyeOff className="w-4 h-4 text-[#0A2540]" />
                  ) : (
                    <Eye className="w-4 h-4" />
                  )}
                </button>
              </div>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-3 px-4 rounded-xl bg-[#0A2540] hover:bg-[#07192C] text-white font-bold text-sm shadow-md active:scale-[0.99] transition-all flex items-center justify-center gap-2 disabled:opacity-70 mt-3"
            >
              {isLoading ? (
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              ) : (
                <>
                  <span>Sign In (لاگ ان کریں)</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>

          <div className="text-center pt-2 border-t border-slate-100">
            <p className="text-[10px] text-slate-400">
              Aab-e-Baraan RO Plant Operations
            </p>
          </div>

        </div>

      </div>

      {/* FORGOT PASSWORD MODAL */}
      {showForgotModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl w-full max-w-sm p-5 shadow-2xl space-y-4 animate-in zoom-in-95 text-xs">
            <div className="flex items-start justify-between border-b pb-2">
              <div>
                <h3 className="font-bold text-sm text-[#0A2540]">
                  Password Recovery (پاس ورڈ بحالی)
                </h3>
                <p className="text-[11px] text-slate-500 mt-0.5">
                  Contact Plant Administrator to reset your password:
                </p>
              </div>
              <button 
                onClick={() => setShowForgotModal(false)}
                className="p-1 rounded-full bg-slate-100 text-slate-500 hover:bg-slate-200"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {resetSubmitted ? (
              <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-center space-y-2">
                <CheckCircle2 className="w-8 h-8 text-emerald-600 mx-auto" />
                <h4 className="font-bold text-emerald-800 text-sm">Request Sent to Admin!</h4>
                <p className="text-[11px] text-emerald-700">
                  Muhammad Rafiq has been notified. He will update your password shortly.
                </p>
              </div>
            ) : (
              <div className="space-y-3.5">
                {/* Admin Direct Contact Card */}
                <div className="p-3 rounded-2xl bg-[#F0F7FB] border border-[#CBD5E1]/70 space-y-2">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-full bg-[#0A2540] text-white flex items-center justify-center font-bold text-xs">
                      MR
                    </div>
                    <div>
                      <p className="font-bold text-[#0A2540] text-xs">Muhammad Rafiq</p>
                      <p className="text-[10px] text-slate-500">System Admin</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2 pt-1">
                    <a
                      href="tel:+923008472910"
                      className="py-2 px-2.5 rounded-xl bg-white border border-[#CBD5E1] text-[#0A2540] font-bold text-[11px] flex items-center justify-center gap-1.5 shadow-xs"
                    >
                      <Phone className="w-3.5 h-3.5 text-[#00A896]" />
                      <span>0300-8472910</span>
                    </a>
                    <a
                      href="https://wa.me/923008472910?text=Salam%2C+I+need+to+reset+my+Aab-e-Baraan+app+password."
                      target="_blank"
                      rel="noopener noreferrer"
                      className="py-2 px-2.5 rounded-xl bg-[#25D366] text-white font-bold text-[11px] flex items-center justify-center gap-1.5 shadow-xs"
                    >
                      <MessageSquare className="w-3.5 h-3.5" />
                      <span>WhatsApp</span>
                    </a>
                  </div>
                </div>

                {/* Send In-App Notification */}
                <form onSubmit={handleSendResetRequest} className="space-y-2.5 pt-1 border-t border-slate-100">
                  <p className="font-bold text-slate-700 text-[11px]">
                    Or send an in-app reset alert to Admin:
                  </p>
                  <div>
                    <input
                      type="text"
                      required
                      placeholder="Your Username (e.g. aslam)"
                      value={forgotUsername}
                      onChange={(e) => setForgotUsername(e.target.value)}
                      className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-3 py-2 text-xs text-[#0F172A]"
                    />
                  </div>
                  <div>
                    <input
                      type="text"
                      placeholder="Note (e.g. Forgot password on morning shift)"
                      value={forgotReason}
                      onChange={(e) => setForgotReason(e.target.value)}
                      className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-3 py-2 text-xs text-[#0F172A]"
                    />
                  </div>
                  <button
                    type="submit"
                    className="w-full py-2.5 rounded-xl bg-[#0A2540] text-white font-bold text-xs"
                  >
                    Submit Reset Alert
                  </button>
                </form>
              </div>
            )}

            <button
              type="button"
              onClick={() => setShowForgotModal(false)}
              className="w-full py-2 text-center text-slate-500 text-xs font-semibold hover:text-slate-700"
            >
              Back to Login
            </button>
          </div>
        </div>
      )}

    </div>
  );
};
