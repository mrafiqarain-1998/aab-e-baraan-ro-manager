import React, { useState, useEffect } from 'react';

interface NumericInputProps extends Omit<React.InputHTMLAttributes<HTMLInputElement>, 'value' | 'onChange'> {
  value: number;
  onChange: (val: number) => void;
  min?: number;
  max?: number;
  allowDecimals?: boolean;
}

export const NumericInput: React.FC<NumericInputProps> = ({
  value,
  onChange,
  min,
  max,
  allowDecimals = false,
  className = '',
  placeholder = '0',
  ...rest
}) => {
  // Maintain internal string representation so the user can backspace and clear completely
  const [text, setText] = useState<string>(() => (value === 0 ? '' : String(value)));

  // Sync when prop value changes externally
  useEffect(() => {
    const currentNum = allowDecimals ? parseFloat(text) : parseInt(text, 10);
    if (isNaN(currentNum)) {
      if (value !== 0) {
        setText(String(value));
      }
    } else if (currentNum !== value) {
      setText(value === 0 ? '' : String(value));
    }
  }, [value, allowDecimals]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const raw = e.target.value;
    
    // Allow empty string so user can delete completely
    if (raw === '') {
      setText('');
      onChange(0);
      return;
    }

    // Only allow numbers and optionally one dot
    if (allowDecimals) {
      if (!/^\d*\.?\d*$/.test(raw)) return;
    } else {
      if (!/^\d*$/.test(raw)) return;
    }

    setText(raw);
    const parsed = allowDecimals ? parseFloat(raw) : parseInt(raw, 10);
    if (!isNaN(parsed)) {
      let finalVal = parsed;
      if (min !== undefined && finalVal < min) finalVal = min;
      if (max !== undefined && finalVal > max) finalVal = max;
      onChange(finalVal);
    }
  };

  const handleFocus = (e: React.FocusEvent<HTMLInputElement>) => {
    // Select all content on click/focus for instantaneous overwrite
    e.target.select();
  };

  const handleBlur = () => {
    if (text === '' || isNaN(allowDecimals ? parseFloat(text) : parseInt(text, 10))) {
      setText('');
      onChange(0);
    }
  };

  return (
    <input
      type="text"
      inputMode={allowDecimals ? "decimal" : "numeric"}
      value={text}
      placeholder={placeholder}
      onChange={handleChange}
      onFocus={handleFocus}
      onBlur={handleBlur}
      className={className}
      {...rest}
    />
  );
};
