import React, { useState } from 'react';
import { useWaterApp } from '../../context/WaterAppContext';
import { 
  PackageCheck, 
  ShoppingCart, 
  AlertOctagon, 
  Plus, 
  X, 
  CheckCircle2, 
  Share2, 
  Trash2,
  Pencil,
  RotateCcw,
  AlertTriangle,
  Building,
  User,
  Truck
} from 'lucide-react';
import { 
  BottleSize, 
  FactoryMaterial, 
  MaterialIssueCategory, 
  BottleUsageType,
  MaterialCategory,
  MaterialUOM,
  MaterialIssueTo,
  PaymentMethod,
  PaymentSource
} from '../../types';
import { NumericInput } from '../common/NumericInput';

const MATERIAL_CATEGORIES: MaterialCategory[] = [
  'Packing Material',
  'RO Plant Parts',
  'Vehicle Parts',
  'Bottle and Caps',
  'Tools',
  'Filter and Cartages',
  'Plumbing Items',
  'Electric Items',
  'General Items'
];

const MATERIAL_UOMS: MaterialUOM[] = [
  'Piece',
  'Packet',
  'Carton',
  'Pair',
  'Liter',
  'Kg',
  'Gram',
  'Nos'
];

const MATERIAL_ISSUE_TO_OPTIONS: MaterialIssueTo[] = [
  'Issue to RO plant',
  'Issue For Production',
  'Issue to Driver',
  'Issue for Disposal'
];

export const InventoryView: React.FC = () => {
  const { 
    bottleSizes, 
    bottleInventory, 
    customers,
    customerAllocations,
    factoryMaterials, 
    bottleCostings, 
    monthlyRecurringExpenses, 
    recordRefillBatch, 
    purchaseBottles, 
    recordDamagedBottles, 
    issueBottles,
    resetAllBottleStocksToZero,
    addBottleSize,
    updateBottleSize,
    deleteBottleSize,
    issueMaterial, 
    refillMaterial,
    addFactoryMaterial,
    updateFactoryMaterial,
    deleteFactoryMaterial,
    addExpense,
    currentUser,
    businessProfile 
  } = useWaterApp();

  const [activeSubTab, setActiveSubTab] = useState<'bottles' | 'materials' | 'costing'>('bottles');

  // Modal states
  const [showRefillModal, setShowRefillModal] = useState(false);
  const [showIssueModal, setShowIssueModal] = useState(false);
  const [showPurchaseModal, setShowPurchaseModal] = useState(false);
  const [showDamageModal, setShowDamageModal] = useState(false);
  const [showIssueMaterialModal, setShowIssueMaterialModal] = useState(false);
  const [showPurchaseMaterialModal, setShowPurchaseMaterialModal] = useState(false);
  const [showResetConfirm, setShowResetConfirm] = useState(false);
  const [showAddBottleModal, setShowAddBottleModal] = useState(false);
  const [editingBottleSize, setEditingBottleSize] = useState<BottleSize | null>(null);
  const [deletingBottleSize, setDeletingBottleSize] = useState<BottleSize | null>(null);

  // Form states - Refill Batch (Only for One-Time / Disposable bottles: 500ml, 6L)
  const oneTimeSizes = bottleSizes.filter(bs => bs.usageType === 'ONE_TIME' || !bs.isReturnableBottle);
  const returnableSizes = bottleSizes.filter(bs => bs.usageType === 'MULTIPLE_TIME' || bs.isReturnableBottle);

  const [refillBottleId, setRefillBottleId] = useState(() => oneTimeSizes[0]?.id || bottleSizes[0]?.id || '');
  const [refillQty, setRefillQty] = useState(50);
  const [refillOperator, setRefillOperator] = useState('Aslam Operator');

  // Form states - Issue Bottle (For Multiple-Time returnable bottles: 19L, 12.5L to Customer or RO Plant)
  const [issueTargetType, setIssueTargetType] = useState<'CUSTOMER' | 'RO_PLANT'>('CUSTOMER');
  const [issueCustomerId, setIssueCustomerId] = useState(() => customers[0]?.id || '');
  const [issueBottleId, setIssueBottleId] = useState(() => returnableSizes[0]?.id || bottleSizes[0]?.id || '');
  const [issueQty, setIssueQty] = useState(1);
  const [issueNotes, setIssueNotes] = useState('');

  // Form states - Purchase Bottles
  const [purchaseBottleId, setPurchaseBottleId] = useState(() => bottleSizes[0]?.id || '');
  const [purchaseQty, setPurchaseQty] = useState(20);
  const [purchaseUnitCost, setPurchaseUnitCost] = useState(800);
  const [purchaseSupplier, setPurchaseSupplier] = useState('Pak Plastics Lahore');
  const [purchasePaymentSource, setPurchasePaymentSource] = useState<PaymentSource>('PAY_FROM_SALE');
  const [purchasePaymentMethod, setPurchasePaymentMethod] = useState<PaymentMethod>('CASH');

  // Form states - Log Damage
  const [damageBottleId, setDamageBottleId] = useState(() => returnableSizes[0]?.id || bottleSizes[0]?.id || '');
  const [damageLocationId, setDamageLocationId] = useState<string>('WAREHOUSE');
  const [damageQty, setDamageQty] = useState(1);
  const [damageNotes, setDamageNotes] = useState('');

  // Form states - Material
  const [selectedMaterialId, setSelectedMaterialId] = useState('');
  const [materialQty, setMaterialQty] = useState(1);
  const [materialIssueTo, setMaterialIssueTo] = useState<MaterialIssueTo>('Issue to RO plant');
  const [materialIssueNotes, setMaterialIssueNotes] = useState('');
  const [materialUnitCost, setMaterialUnitCost] = useState(0);
  const [materialSupplier, setMaterialSupplier] = useState('');

  // Add & Edit Material Modal states
  const [showAddMaterialModal, setShowAddMaterialModal] = useState(false);
  const [editingMaterial, setEditingMaterial] = useState<FactoryMaterial | null>(null);
  const [deletingMaterial, setDeletingMaterial] = useState<FactoryMaterial | null>(null);

  const [matFormName, setMatFormName] = useState('');
  const [matFormCategory, setMatFormCategory] = useState<MaterialCategory>('Packing Material');
  const [matFormUom, setMatFormUom] = useState<MaterialUOM>('Piece');
  const [matFormStock, setMatFormStock] = useState(0);
  const [matFormRate, setMatFormRate] = useState(0);
  const [matFormSupplier, setMatFormSupplier] = useState('');

  // Form states - Admin Add / Edit Bottle Size
  const [sizeFormName, setSizeFormName] = useState('');
  const [sizeFormCapacity, setSizeFormCapacity] = useState(19);
  const [sizeFormUsageType, setSizeFormUsageType] = useState<BottleUsageType>('MULTIPLE_TIME');
  const [sizeFormRefillPrice, setSizeFormRefillPrice] = useState(120);
  const [sizeFormPurchaseCost, setSizeFormPurchaseCost] = useState(800);
  const [sizeFormDepositAmount, setSizeFormDepositAmount] = useState(1000);
  const [sizeFormUom, setSizeFormUom] = useState('Bottles');

  const isAdmin = currentUser.role === 'ADMIN';

  // Submissions
  const handleRefillSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (refillQty <= 0) return;
    recordRefillBatch(refillBottleId, refillQty, refillOperator);
    setShowRefillModal(false);
    alert(`Refill batch of ${refillQty} bottles recorded successfully!`);
  };

  const handleIssueBottleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (issueQty <= 0) {
      alert("Please enter a valid quantity to issue.");
      return;
    }
    if (issueTargetType === 'CUSTOMER' && !issueCustomerId) {
      alert("Please select a customer.");
      return;
    }

    const res = issueBottles({
      targetType: issueTargetType,
      customerId: issueTargetType === 'CUSTOMER' ? issueCustomerId : undefined,
      bottleSizeId: issueBottleId,
      quantity: issueQty,
      notes: issueNotes
    });

    if (res.success) {
      setShowIssueModal(false);
      setIssueNotes('');
      alert(`Successfully issued ${issueQty} bottle(s) to ${issueTargetType === 'CUSTOMER' ? 'customer' : 'RO Plant Internal'}!`);
    } else {
      alert(res.error || "Failed to issue bottle.");
    }
  };

  const handlePurchaseSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (purchaseQty <= 0) return;
    purchaseBottles(purchaseBottleId, purchaseQty, purchaseUnitCost, purchaseSupplier, purchasePaymentSource, purchasePaymentMethod);
    setShowPurchaseModal(false);
    alert(`Purchased ${purchaseQty} new bottles (${purchasePaymentSource === 'INVESTMENT' ? 'Investment' : 'Pay from Sale'} • ${purchasePaymentMethod})!`);
  };

  const handleDamageSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (damageQty <= 0) {
      alert("Please enter a valid damaged quantity.");
      return;
    }

    const targetCustomer = damageLocationId === 'WAREHOUSE' ? undefined : damageLocationId;
    recordDamagedBottles(damageBottleId, damageQty, targetCustomer, damageNotes);
    setShowDamageModal(false);
    setDamageNotes('');
    alert(`Damaged bottle(s) logged and deducted from custody.`);
  };

  const handleOpenAddMaterial = () => {
    setMatFormName('');
    setMatFormCategory('Packing Material');
    setMatFormUom('Piece');
    setMatFormStock(0);
    setMatFormRate(0);
    setMatFormSupplier('');
    setShowAddMaterialModal(true);
  };

  const handleOpenEditMaterial = (mat: FactoryMaterial) => {
    setEditingMaterial(mat);
    setMatFormName(mat.name);
    setMatFormCategory(mat.category || 'General Items');
    setMatFormUom((mat.uom as MaterialUOM) || 'Piece');
    setMatFormStock(mat.currentStock);
    setMatFormRate(mat.purchaseRate);
    setMatFormSupplier(mat.supplierName || '');
  };

  const handleSaveMaterialSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!matFormName.trim()) {
      alert("Please enter item name (سامان کا نام درج کریں)");
      return;
    }

    if (editingMaterial) {
      updateFactoryMaterial(editingMaterial.id, {
        name: matFormName.trim(),
        category: matFormCategory,
        uom: matFormUom,
        currentStock: matFormStock,
        purchaseRate: matFormRate,
        supplierName: matFormSupplier.trim()
      });
      setEditingMaterial(null);
    } else {
      addFactoryMaterial({
        name: matFormName.trim(),
        category: matFormCategory,
        uom: matFormUom,
        purchaseRate: matFormRate,
        perPackQty: 1,
        currentStock: matFormStock,
        openingStock: matFormStock,
        supplierName: matFormSupplier.trim(),
        active: true
      });
      setShowAddMaterialModal(false);
    }
  };

  const handleDeleteMaterialConfirm = () => {
    if (deletingMaterial) {
      deleteFactoryMaterial(deletingMaterial.id);
      setDeletingMaterial(null);
    }
  };

  const handleIssueMaterialSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedMaterialId) return;
    if (materialQty <= 0) {
      alert("Please enter a valid quantity");
      return;
    }
    issueMaterial(selectedMaterialId, materialQty, materialIssueTo, materialIssueNotes);
    setShowIssueMaterialModal(false);
    setMaterialIssueNotes('');
  };

  const handlePurchaseMaterialSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedMaterialId) return;
    refillMaterial(selectedMaterialId, materialQty, materialUnitCost, materialSupplier);
    const mat = factoryMaterials.find(m => m.id === selectedMaterialId);
    if (materialUnitCost > 0 && materialQty > 0) {
      addExpense({
        date: new Date().toISOString().split('T')[0],
        expenseType: 'OPEX',
        categoryId: 'cat_raw_material',
        categoryName: 'Raw Material',
        description: `Purchased ${materialQty} ${mat?.uom || ''} ${mat?.name || 'Material'} from ${materialSupplier || 'Vendor'}`,
        amount: materialQty * materialUnitCost,
        paymentSource: purchasePaymentSource,
        paymentMethod: purchasePaymentMethod,
        payee: materialSupplier || 'Vendor',
        notes: `Unit cost: Rs. ${materialUnitCost} • Source: ${purchasePaymentSource === 'PAY_FROM_SALE' ? 'Pay from Sale' : 'Investment'} • Method: ${purchasePaymentMethod}`,
        enteredBy: currentUser.name,
        enteredByRole: currentUser.role,
        isAcknowledged: true,
        acknowledgedBy: currentUser.name,
        isApprovedByOwner: true
      });
    }
    setShowPurchaseMaterialModal(false);
    alert(`Material stock purchased (${purchasePaymentSource === 'INVESTMENT' ? 'Investment' : 'Pay from Sale'} • ${purchasePaymentMethod})!`);
  };

  const handleOpenEditBottle = (bs: BottleSize) => {
    setEditingBottleSize(bs);
    setSizeFormName(bs.name);
    setSizeFormCapacity(bs.capacityLitres);
    setSizeFormUsageType(bs.usageType || (bs.isReturnableBottle ? 'MULTIPLE_TIME' : 'ONE_TIME'));
    setSizeFormRefillPrice(bs.defaultRefillPrice);
    setSizeFormPurchaseCost(bs.latestPurchaseRate || bs.purchaseCost || 0);
    setSizeFormDepositAmount(bs.depositAmount || 0);
    setSizeFormUom(bs.uom || 'Bottles');
  };

  const handleSaveEditedBottle = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingBottleSize) return;
    if (!sizeFormName.trim()) {
      alert("Please enter bottle size name.");
      return;
    }

    const isReturnable = sizeFormUsageType === 'MULTIPLE_TIME';
    const updated: BottleSize = {
      ...editingBottleSize,
      name: sizeFormName.trim(),
      capacityLitres: sizeFormCapacity,
      usageType: sizeFormUsageType,
      isReturnableBottle: isReturnable,
      defaultRefillPrice: sizeFormRefillPrice,
      latestPurchaseRate: sizeFormPurchaseCost,
      purchaseCost: sizeFormPurchaseCost,
      depositAmount: isReturnable ? sizeFormDepositAmount : 0,
      uom: sizeFormUom.trim() || 'Bottles'
    };

    updateBottleSize(updated);
    setEditingBottleSize(null);
    alert(`Bottle size "${updated.name}" updated successfully!`);
  };

  const handleSaveNewBottle = (e: React.FormEvent) => {
    e.preventDefault();
    if (!sizeFormName.trim()) {
      alert("Please enter bottle size name.");
      return;
    }

    const isReturnable = sizeFormUsageType === 'MULTIPLE_TIME';
    const res = addBottleSize({
      name: sizeFormName.trim(),
      capacityLitres: sizeFormCapacity,
      usageType: sizeFormUsageType,
      isReturnableBottle: isReturnable,
      packQuantity: 1,
      defaultRefillPrice: sizeFormRefillPrice,
      bottleSalePrice: sizeFormPurchaseCost,
      depositAmount: isReturnable ? sizeFormDepositAmount : 0,
      replacementPrice: sizeFormPurchaseCost,
      active: true,
      refillCost: 25,
      deliveryCost: 15,
      deliveryUnit: "PER_BOTTLE",
      packetPackagingQty: 1,
      uom: sizeFormUom.trim() || 'Bottles',
      openingStock: 0,
      purchaseCost: sizeFormPurchaseCost,
      latestPurchaseRate: sizeFormPurchaseCost
    });

    if (res.success) {
      setShowAddBottleModal(false);
      alert(`New bottle size "${sizeFormName}" added successfully with initial 0 stock!`);
    } else {
      alert(res.error || "Failed to add bottle size");
    }
  };

  // Find holders for Log Damage modal
  const activeHoldersForDamage = customerAllocations.filter(
    a => a.bottleSizeId === damageBottleId && a.emptyHeld > 0
  );

  return (
    <div className="space-y-3.5 pb-24 text-xs">
      
      {/* 1. Header & Sub-Tabs Navigation */}
      <div className="bg-[#0A2540] text-white rounded-2xl p-4 shadow-sm space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-sm font-bold tracking-tight">Stock & Cost Module</h2>
            <p className="text-[11px] text-[#E8F4F8]/80 font-urdu">اسٹاک، بوتل اجراء اور لاگت کا نظام</p>
          </div>
        </div>

        {/* Segmented Sub-tabs */}
        <div className="flex items-center gap-1.5 p-1 bg-white/10 rounded-xl text-xs font-bold">
          <button
            onClick={() => setActiveSubTab('bottles')}
            className={`flex-1 py-1.5 rounded-lg transition-all text-center ${
              activeSubTab === 'bottles' ? 'bg-[#00A896] text-[#07192C] font-bold shadow-xs' : 'text-white/80 hover:text-white'
            }`}
          >
            Bottle Stock (بوتل اسٹاک)
          </button>

          <button
            onClick={() => setActiveSubTab('materials')}
            className={`flex-1 py-1.5 rounded-lg transition-all text-center ${
              activeSubTab === 'materials' ? 'bg-[#00A896] text-[#07192C] font-bold shadow-xs' : 'text-white/80 hover:text-white'
            }`}
          >
            Materials (دیگر سامان)
          </button>

          {isAdmin && (
            <button
              onClick={() => setActiveSubTab('costing')}
              className={`flex-1 py-1.5 rounded-lg transition-all text-center flex items-center justify-center gap-1 ${
                activeSubTab === 'costing' ? 'bg-[#00A896] text-[#07192C] font-bold shadow-xs' : 'text-white/80 hover:text-white'
              }`}
            >
              <span>Costing (لاگت)</span>
              <span className="px-1 py-0.2 rounded bg-rose-500 text-white text-[9px]">Admin</span>
            </button>
          )}
        </div>
      </div>

      {/* SUBTAB 1: BOTTLE STOCK */}
      {activeSubTab === 'bottles' && (
        <div className="space-y-3">
          
          {/* Action Buttons Row */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            
            {/* 1. Refill Batch: Only for one-time bottles (500ml, 6L) */}
            <button
              onClick={() => {
                const firstOneTime = bottleSizes.find(bs => bs.usageType === 'ONE_TIME' || !bs.isReturnableBottle);
                setRefillBottleId(firstOneTime?.id || bottleSizes[0]?.id || '');
                setShowRefillModal(true);
              }}
              className="py-2.5 px-2 rounded-xl bg-white border border-[#CBD5E1] text-[#0A2540] hover:bg-slate-50 font-bold flex flex-col items-center justify-center text-center shadow-2xs transition-all active:scale-95"
            >
              <PackageCheck className="w-4 h-4 text-[#00A896] mb-0.5" />
              <span className="text-[11px] leading-tight">Refill Batch</span>
              <span className="text-[9px] text-slate-400 font-urdu">ڈسپوزل فلنگ</span>
            </button>

            {/* 2. Issue Bottle: Directly next to Refill Batch! For returnable bottles (19L, 12.5L) */}
            <button
              onClick={() => {
                const firstReturnable = bottleSizes.find(bs => bs.usageType === 'MULTIPLE_TIME' || bs.isReturnableBottle);
                setIssueBottleId(firstReturnable?.id || bottleSizes[0]?.id || '');
                setIssueCustomerId(customers[0]?.id || '');
                setIssueTargetType('CUSTOMER');
                setIssueQty(1);
                setIssueNotes('');
                setShowIssueModal(true);
              }}
              className="py-2.5 px-2 rounded-xl bg-[#0A2540] hover:bg-[#07192C] text-white font-bold flex flex-col items-center justify-center text-center shadow-xs transition-all active:scale-95"
            >
              <Share2 className="w-4 h-4 text-[#00A896] mb-0.5" />
              <span className="text-[11px] leading-tight">Issue Bottle</span>
              <span className="text-[9px] text-[#E8F4F8]/70 font-urdu">بوتل جاری کریں</span>
            </button>

            {/* 3. Buy Bottles */}
            <button
              onClick={() => setShowPurchaseModal(true)}
              className="py-2.5 px-2 rounded-xl bg-white border border-[#CBD5E1] text-[#0A2540] hover:bg-slate-50 font-bold flex flex-col items-center justify-center text-center shadow-2xs transition-all active:scale-95"
            >
              <ShoppingCart className="w-4 h-4 text-[#028090] mb-0.5" />
              <span className="text-[11px] leading-tight">Buy Bottles</span>
              <span className="text-[9px] text-slate-400 font-urdu">نئی خریداری</span>
            </button>

            {/* 4. Log Damage */}
            <button
              onClick={() => {
                const firstReturnable = bottleSizes.find(bs => bs.usageType === 'MULTIPLE_TIME' || bs.isReturnableBottle);
                const sid = firstReturnable?.id || bottleSizes[0]?.id || '';
                setDamageBottleId(sid);
                const holder = customerAllocations.find(a => a.bottleSizeId === sid && a.emptyHeld > 0);
                setDamageLocationId(holder ? holder.customerId : 'WAREHOUSE');
                setDamageQty(1);
                setDamageNotes('');
                setShowDamageModal(true);
              }}
              className="py-2.5 px-2 rounded-xl bg-white border border-[#CBD5E1] text-[#EF4444] hover:bg-red-50/50 font-bold flex flex-col items-center justify-center text-center shadow-2xs transition-all active:scale-95"
            >
              <AlertOctagon className="w-4 h-4 mb-0.5 text-[#EF4444]" />
              <span className="text-[11px] leading-tight">Log Damage</span>
              <span className="text-[9px] text-slate-400 font-urdu">نقصان اندراج</span>
            </button>
          </div>

          {/* Admin Header Action Bar */}
          <div className="flex items-center justify-between pt-1">
            <span className="text-xs font-bold text-[#0A2540]">
              Registered Bottle Sizes ({bottleSizes.length})
            </span>
            {isAdmin && (
              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => setShowResetConfirm(true)}
                  className="py-1 px-2.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-600 font-semibold text-[10px] flex items-center gap-1 border border-slate-200"
                  title="Reset all bottle stock counts to 0"
                >
                  <RotateCcw className="w-3 h-3" />
                  <span>Reset Stock to 0</span>
                </button>

                <button
                  onClick={() => {
                    setSizeFormName('');
                    setSizeFormCapacity(19);
                    setSizeFormUsageType('MULTIPLE_TIME');
                    setSizeFormRefillPrice(120);
                    setSizeFormPurchaseCost(800);
                    setSizeFormDepositAmount(1000);
                    setSizeFormUom('Bottles');
                    setShowAddBottleModal(true);
                  }}
                  className="py-1 px-2.5 rounded-lg bg-[#0A2540] hover:bg-[#07192C] text-white font-bold text-[10px] flex items-center gap-1 shadow-2xs transition-colors"
                >
                  <Plus className="w-3 h-3" />
                  <span>Add Bottle Size</span>
                </button>
              </div>
            )}
          </div>

          {/* Bottle Cards */}
          <div className="space-y-2.5">
            {bottleInventory.map(inv => {
              const size = bottleSizes.find(b => b.id === inv.bottleSizeId);
              const totalPool = inv.atPlantFull + inv.atPlantEmpty + inv.withCustomers + inv.withStaff + inv.damaged;

              return (
                <div
                  key={inv.id}
                  className="bg-white border border-[#CBD5E1]/70 rounded-2xl p-4 shadow-xs space-y-3"
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                        size?.isReturnableBottle 
                          ? 'bg-[#E8F4F8] text-[#0A2540]' 
                          : 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                      }`}>
                        {size?.isReturnableBottle ? 'Multiple Time Use (واپسی)' : 'One-Time Packaging (ڈسپوزل)'}
                      </span>
                      <h3 className="font-black text-sm text-[#0A2540] mt-1">{inv.sizeName}</h3>
                      <p className="text-[11px] text-slate-500">
                        Purchase: Rs. {size?.latestPurchaseRate} • Refill: Rs. {size?.defaultRefillPrice}
                        {size?.isReturnableBottle && ` • Deposit: Rs. ${size?.depositAmount || 0}`}
                      </p>
                    </div>

                    <div className="text-right">
                      <span className="text-[10px] text-slate-400 block font-semibold">Total Fleet Pool</span>
                      <strong className="text-base font-black text-[#0A2540]">{totalPool} Pcs</strong>
                    </div>
                  </div>

                  {/* Stock KPI Grid */}
                  <div className="grid grid-cols-4 gap-1.5 text-center">
                    <div className="p-2 rounded-xl bg-[#D1FAE5]">
                      <span className="text-[9px] text-[#065F46] block font-bold">Plant Full</span>
                      <strong className="text-sm font-black text-[#10B981]">{inv.atPlantFull}</strong>
                      <span className="text-[8px] text-[#065F46] font-urdu block">تیار بھری</span>
                    </div>

                    <div className="p-2 rounded-xl bg-[#E8F4F8]">
                      <span className="text-[9px] text-[#0A2540] block font-bold">Plant Empty</span>
                      <strong className="text-sm font-black text-[#0A2540]">{inv.atPlantEmpty}</strong>
                      <span className="text-[8px] text-[#0A2540] font-urdu block">خالی گودام</span>
                    </div>

                    <div className="p-2 rounded-xl bg-[#FEF3C7]">
                      <span className="text-[9px] text-[#92400E] block font-bold">In-Use / Cust.</span>
                      <strong className="text-sm font-black text-[#D97706]">{inv.withCustomers}</strong>
                      <span className="text-[8px] text-[#92400E] font-urdu block">گاہک / پلانٹ پاس</span>
                    </div>

                    <div className="p-2 rounded-xl bg-[#FEE2E2]">
                      <span className="text-[9px] text-[#991B1B] block font-bold">Damaged</span>
                      <strong className="text-sm font-black text-[#EF4444]">{inv.damaged}</strong>
                      <span className="text-[8px] text-[#991B1B] font-urdu block">خراب</span>
                    </div>
                  </div>

                  {/* Admin Edit & Delete Bottle Size Options */}
                  {isAdmin && (
                    <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
                      <span className="text-[10px] text-slate-400">
                        Admin Options (ترمیم و حذف)
                      </span>
                      <div className="flex items-center gap-2">
                        {size && (
                          <button
                            onClick={() => handleOpenEditBottle(size)}
                            className="py-1 px-2.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-[#0A2540] font-bold text-[10px] flex items-center gap-1 transition-colors"
                            title="Edit Bottle Size"
                          >
                            <Pencil className="w-3 h-3 text-[#028090]" />
                            <span>Edit (تبدیل کریں)</span>
                          </button>
                        )}
                        <button
                          onClick={() => {
                            if (size) setDeletingBottleSize(size);
                          }}
                          className="py-1 px-2.5 rounded-lg bg-red-50 hover:bg-red-100 text-red-600 font-bold text-[10px] flex items-center gap-1 border border-red-200 transition-colors"
                          title="Delete Bottle Size"
                        >
                          <Trash2 className="w-3 h-3 text-red-600" />
                          <span>Delete (ختم کریں)</span>
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>

        </div>
      )}

      {/* SUBTAB 2: FACTORY MATERIALS (OTHER MATERIAL / دیگر سامان) */}
      {activeSubTab === 'materials' && (
        <div className="space-y-3">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <div>
              <span className="font-bold text-xs text-[#0A2540] block">
                Other Material Inventory ({factoryMaterials.length})
              </span>
              <span className="text-[10px] text-[#00A896] font-urdu font-bold">
                دیگر سامان و فیکٹری سپلائیز
              </span>
            </div>

            <div className="flex items-center gap-1.5 flex-wrap">
              <button
                onClick={handleOpenAddMaterial}
                className="px-2.5 py-1.5 rounded-xl bg-[#0A2540] hover:bg-[#07192C] text-white text-[11px] font-bold flex items-center gap-1 shadow-xs transition-colors"
              >
                <Plus className="w-3.5 h-3.5 text-[#00A896]" />
                <span>Add Item (نیا سامان)</span>
              </button>

              <button
                onClick={() => {
                  setSelectedMaterialId(factoryMaterials[0]?.id || '');
                  setShowIssueMaterialModal(true);
                }}
                disabled={factoryMaterials.length === 0}
                className="px-2.5 py-1.5 rounded-xl bg-[#028090] hover:bg-[#026c7a] text-white text-[11px] font-bold flex items-center gap-1 shadow-xs transition-colors disabled:opacity-50"
              >
                <span>Issue Material (جاری کریں)</span>
              </button>

              <button
                onClick={() => {
                  setSelectedMaterialId(factoryMaterials[0]?.id || '');
                  setShowPurchaseMaterialModal(true);
                }}
                disabled={factoryMaterials.length === 0}
                className="px-2.5 py-1.5 rounded-xl bg-[#10B981] hover:bg-[#059669] text-white text-[11px] font-bold flex items-center gap-1 shadow-xs transition-colors disabled:opacity-50"
              >
                <ShoppingCart className="w-3.5 h-3.5" />
                <span>Refill Stock (خریداری)</span>
              </button>
            </div>
          </div>

          <div className="space-y-2">
            {factoryMaterials.length === 0 ? (
              <div className="p-8 text-center bg-white rounded-2xl border border-slate-200">
                <p className="text-xs text-slate-500 mb-2">No other material items added yet.</p>
                <button
                  onClick={handleOpenAddMaterial}
                  className="px-3 py-1.5 rounded-xl bg-[#0A2540] text-white text-xs font-bold inline-flex items-center gap-1"
                >
                  <Plus className="w-3.5 h-3.5 text-[#00A896]" />
                  <span>Add First Item (پہلا سامان شامل کریں)</span>
                </button>
              </div>
            ) : (
              factoryMaterials.map(mat => {
                return (
                  <div
                    key={mat.id}
                    className="bg-white border border-[#CBD5E1]/70 rounded-2xl p-3.5 shadow-xs space-y-2"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="space-y-0.5">
                        <span className="text-[9px] font-bold px-2 py-0.5 rounded-full bg-slate-100 text-[#028090] border border-slate-200 inline-block">
                          {mat.category || 'General Items'}
                        </span>
                        <h4 className="font-bold text-xs sm:text-sm text-[#0A2540]">{mat.name}</h4>
                        {mat.supplierName && (
                          <p className="text-[10px] text-slate-400">Supplier: {mat.supplierName}</p>
                        )}
                        {mat.issueTo && (
                          <p className="text-[9px] text-[#00A896] font-medium">Last: {mat.issueTo}</p>
                        )}
                      </div>

                      <div className="text-right flex flex-col items-end">
                        <span className="text-xs font-black text-[#0A2540]">
                          {mat.currentStock.toLocaleString()} {mat.uom}
                        </span>
                        <span className="text-[10px] text-slate-500 block">
                          Rate: Rs. {mat.purchaseRate} / {mat.uom}
                        </span>

                        {/* Admin / Supervisor Edit & Delete Action Buttons */}
                        <div className="flex items-center gap-1.5 mt-2">
                          <button
                            onClick={() => handleOpenEditMaterial(mat)}
                            className="p-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors"
                            title="Edit Item"
                          >
                            <Pencil className="w-3 h-3 text-[#0A2540]" />
                          </button>
                          
                          {isAdmin && (
                            <button
                              onClick={() => setDeletingMaterial(mat)}
                              className="p-1.5 rounded-lg bg-red-50 hover:bg-red-100 text-red-600 transition-colors"
                              title="Delete Item"
                            >
                              <Trash2 className="w-3 h-3" />
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}

      {/* SUBTAB 3: COSTING & PROFIT MATRIX (ADMIN) */}
      {activeSubTab === 'costing' && isAdmin && (
        <div className="space-y-3">
          <div className="bg-white border border-[#CBD5E1]/70 rounded-2xl p-4 shadow-xs space-y-3">
            <h3 className="font-black text-xs text-[#0A2540] uppercase tracking-wider">
              Section 1: Bottle Costing Breakdown (لاگت و منافع)
            </h3>

            <div className="space-y-2.5">
              {bottleCostings.map(cost => (
                <div
                  key={cost.id}
                  className="p-3 rounded-xl bg-[#F0F7FB] border border-[#CBD5E1]/60 space-y-2 text-xs"
                >
                  <div className="flex items-center justify-between">
                    <strong className="text-sm font-black text-[#0A2540]">{cost.bottleSizeName}</strong>
                    <span className="font-black text-sm text-[#10B981]">
                      Profit: Rs. {cost.profitPerPackOrBottle.toFixed(2)}
                    </span>
                  </div>

                  <div className="grid grid-cols-3 gap-2 text-center text-[11px]">
                    <div className="p-1.5 rounded-lg bg-white">
                      <span className="text-slate-400 block text-[10px]">Total Cost</span>
                      <strong className="text-[#0A2540]">Rs. {cost.totalCostPerPackOrBottle.toFixed(2)}</strong>
                    </div>
                    <div className="p-1.5 rounded-lg bg-white">
                      <span className="text-slate-400 block text-[10px]">Selling Price</span>
                      <strong className="text-[#0A2540]">Rs. {cost.salePrice.toFixed(2)}</strong>
                    </div>
                    <div className="p-1.5 rounded-lg bg-white">
                      <span className="text-slate-400 block text-[10px]">Margin</span>
                      <strong className="text-[#10B981]">
                        {((cost.profitPerPackOrBottle / cost.salePrice) * 100).toFixed(0)}%
                      </strong>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white border border-[#CBD5E1]/70 rounded-2xl p-4 shadow-xs space-y-2 text-xs">
            <h3 className="font-black text-xs text-[#0A2540] uppercase tracking-wider">
              Section 2: Fixed Monthly Plant Overheads (ماہانہ مستقل خرچ)
            </h3>
            {monthlyRecurringExpenses.map(mre => (
              <div key={mre.id} className="p-2 rounded-xl bg-[#F0F7FB] flex justify-between items-center text-[11px]">
                <div>
                  <strong className="text-[#0A2540]">{mre.description}</strong>
                  <span className="text-slate-400 block text-[10px]">{mre.notes}</span>
                </div>
                <strong className="text-[#EF4444]">Rs. {mre.amount.toLocaleString()}</strong>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 1. REFILL BATCH MODAL (ONLY ONE-TIME / DISPOSABLE BOTTLES) */}
      {/* ========================================================================= */}
      {showRefillModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl w-full max-w-sm p-5 shadow-2xl space-y-3.5 animate-in fade-in">
            <div className="flex items-center justify-between border-b pb-2">
              <div>
                <h3 className="font-bold text-sm text-[#0A2540]">Record Refill Batch (ڈسپوزل فلنگ)</h3>
                <p className="text-[10px] text-slate-500">صرف ون ٹائم / ڈسپوزل بوتلیں (جو واپس نہیں آتیں)</p>
              </div>
              <button 
                onClick={() => setShowRefillModal(false)}
                className="p-1 rounded-full bg-slate-100 text-slate-500 hover:bg-slate-200"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {oneTimeSizes.length === 0 ? (
              <div className="p-4 bg-amber-50 rounded-xl border border-amber-200 text-amber-900 text-xs text-center space-y-2">
                <p className="font-bold">No One-Time Packaging Sizes Found</p>
                <p className="text-[10px]">
                  ریفِل بیچ صرف ان بوتلوں کے لیے ہے جو گاہک کو بوتل سمیت بکتی ہیں (جیسے 500ml یا 6 لیٹر)۔ ایڈمن سے نیا ون ٹائم سائز ایڈ کروائیں۔
                </p>
                <button
                  onClick={() => setShowRefillModal(false)}
                  className="py-1 px-3 bg-slate-200 text-slate-700 font-bold text-xs rounded-lg"
                >
                  Close
                </button>
              </div>
            ) : (
              <form onSubmit={handleRefillSubmit} className="space-y-3">
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    Select Disposable Bottle (ون ٹائم بوتل سائز) *
                  </label>
                  <select
                    value={refillBottleId}
                    onChange={e => setRefillBottleId(e.target.value)}
                    className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-2.5 py-2 text-xs font-semibold text-[#0A2540]"
                  >
                    {oneTimeSizes.map(bs => (
                      <option key={bs.id} value={bs.id}>{bs.name}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    Quantity Filled (تیار بھری تعداد) *
                  </label>
                  <NumericInput
                    value={refillQty}
                    onChange={val => setRefillQty(val)}
                    placeholder="50"
                    className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-3 py-2 text-sm font-black text-[#10B981] text-center"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">Operator Name</label>
                  <input
                    type="text"
                    value={refillOperator}
                    onChange={e => setRefillOperator(e.target.value)}
                    className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-3 py-2 text-xs font-semibold text-[#0A2540]"
                  />
                </div>

                <div className="flex gap-2 pt-2 border-t border-slate-100">
                  <button type="button" onClick={() => setShowRefillModal(false)} className="flex-1 py-2.5 rounded-xl bg-slate-200 font-bold text-xs">
                    Cancel
                  </button>
                  <button type="submit" className="flex-1 py-2.5 rounded-xl bg-[#0A2540] hover:bg-[#028090] text-white font-bold text-xs shadow-xs transition-colors">
                    Save Refill Batch
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 2. ISSUE BOTTLE MODAL (BAR BAR REFILL HONI WALI BOTTLES: 19L, 12.5L) */}
      {/* ========================================================================= */}
      {showIssueModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl w-full max-w-sm p-5 shadow-2xl space-y-3.5 animate-in fade-in">
            <div className="flex items-center justify-between border-b pb-2">
              <div>
                <h3 className="font-bold text-sm text-[#0A2540]">Issue Returnable Bottle (بوتل اجراء)</h3>
                <p className="text-[10px] text-slate-500">بار بار ری فل ہونے والی بوتلیں (19L، 12.5L)</p>
              </div>
              <button 
                onClick={() => setShowIssueModal(false)}
                className="p-1 rounded-full bg-slate-100 text-slate-500 hover:bg-slate-200"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleIssueBottleSubmit} className="space-y-3">
              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">
                  Issue To (کس کو جاری کرنی ہے؟) *
                </label>
                <div className="grid grid-cols-2 gap-1.5 mb-2">
                  <button
                    type="button"
                    onClick={() => setIssueTargetType('CUSTOMER')}
                    className={`py-1.5 px-2 rounded-xl text-[11px] font-bold flex items-center justify-center gap-1 border transition-all ${
                      issueTargetType === 'CUSTOMER'
                        ? 'bg-[#0A2540] text-white border-[#0A2540]'
                        : 'bg-white text-slate-700 border-[#CBD5E1]'
                    }`}
                  >
                    <User className="w-3.5 h-3.5" />
                    <span>Customer (گاہک)</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setIssueTargetType('RO_PLANT')}
                    className={`py-1.5 px-2 rounded-xl text-[11px] font-bold flex items-center justify-center gap-1 border transition-all ${
                      issueTargetType === 'RO_PLANT'
                        ? 'bg-[#00A896] text-white border-[#00A896]'
                        : 'bg-white text-slate-700 border-[#CBD5E1]'
                    }`}
                  >
                    <Building className="w-3.5 h-3.5" />
                    <span>RO Plant (پلانٹ استعمال)</span>
                  </button>
                </div>

                {issueTargetType === 'CUSTOMER' && (
                  <div>
                    <select
                      value={issueCustomerId}
                      onChange={e => setIssueCustomerId(e.target.value)}
                      className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-2.5 py-1.5 text-[10px] font-semibold text-[#0A2540]"
                    >
                      <option value="">-- Choose Customer ({customers.length}) --</option>
                      {customers.map(c => (
                        <option key={c.id} value={c.id}>
                          {c.name} • {c.area || 'General'} (Held: {c.emptyBottlesOwed} Pcs)
                        </option>
                      ))}
                    </select>
                  </div>
                )}
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">
                  Select Bottle Size (بوتل سائز) *
                </label>
                <select
                  value={issueBottleId}
                  onChange={e => setIssueBottleId(e.target.value)}
                  className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-2.5 py-2 text-xs font-semibold text-[#0A2540]"
                >
                  {returnableSizes.map(bs => (
                    <option key={bs.id} value={bs.id}>{bs.name}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">
                  Quantity to Issue (جاری شدہ تعداد) *
                </label>
                <NumericInput
                  value={issueQty}
                  onChange={val => setIssueQty(val)}
                  placeholder="1"
                  className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-3 py-2 text-sm font-black text-[#0A2540] text-center"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">
                  Issue Note (اختیاری نوٹ)
                </label>
                <input
                  type="text"
                  value={issueNotes}
                  onChange={e => setIssueNotes(e.target.value)}
                  placeholder="e.g. New dispenser security / Office cooler bottle"
                  className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-3 py-2 text-xs font-medium text-[#0F172A]"
                />
              </div>

              <div className="flex gap-2 pt-2 border-t border-slate-100">
                <button type="button" onClick={() => setShowIssueModal(false)} className="flex-1 py-2.5 rounded-xl bg-slate-200 font-bold text-xs">
                  Cancel
                </button>
                <button type="submit" className="flex-1 py-2.5 rounded-xl bg-[#0A2540] hover:bg-[#028090] text-white font-bold text-xs shadow-xs transition-colors">
                  Confirm Issue (بوتل جاری کریں)
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 3. LOG DAMAGE MODAL (STEP 1: SIZE -> STEP 2: CUSTODY / LOCATION -> QTY) */}
      {/* ========================================================================= */}
      {showDamageModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl w-full max-w-sm p-5 shadow-2xl space-y-3.5 animate-in fade-in">
            <div className="flex items-center justify-between border-b pb-2">
              <div>
                <h3 className="font-bold text-sm text-[#EF4444] flex items-center gap-1.5">
                  <AlertOctagon className="w-4 h-4" />
                  <span>Log Damaged Bottle (نقصان اندراج)</span>
                </h3>
                <p className="text-[10px] text-slate-500">بوتل سائز و متعلقہ گاہک یا پلانٹ منتخب کریں</p>
              </div>
              <button 
                onClick={() => setShowDamageModal(false)}
                className="p-1 rounded-full bg-slate-100 text-slate-500 hover:bg-slate-200"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleDamageSubmit} className="space-y-3">
              {/* Step 1: Select Bottle Size (Multiple time use sizes) */}
              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">
                  1. Select Bottle Size (بوتل کا سائز) *
                </label>
                <select
                  value={damageBottleId}
                  onChange={e => {
                    const sid = e.target.value;
                    setDamageBottleId(sid);
                    const holder = customerAllocations.find(a => a.bottleSizeId === sid && a.emptyHeld > 0);
                    setDamageLocationId(holder ? holder.customerId : 'WAREHOUSE');
                  }}
                  className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-2.5 py-2 text-xs font-semibold text-[#0A2540]"
                >
                  {returnableSizes.map(bs => (
                    <option key={bs.id} value={bs.id}>{bs.name}</option>
                  ))}
                </select>
              </div>

              {/* Step 2: Select Customer or Location who currently holds this size */}
              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">
                  2. Damaged At / Custody (بوتل کہاں خراب ہوئی؟) *
                </label>
                <select
                  value={damageLocationId}
                  onChange={e => setDamageLocationId(e.target.value)}
                  className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-2.5 py-2 text-xs font-semibold text-[#0A2540]"
                >
                  <option value="WAREHOUSE">Plant Warehouse / Yard (پلانٹ گودام)</option>
                  {activeHoldersForDamage.map(h => (
                    <option key={h.customerId} value={h.customerId}>
                      {h.customerName} (موجود بوتلیں: {h.emptyHeld} Pcs)
                    </option>
                  ))}
                </select>
                {activeHoldersForDamage.length === 0 && (
                  <p className="text-[10px] text-slate-400 mt-1">
                    * فی الحال کسی کسٹمر یا آر او پلانٹ کے پاس یہ سائز موجود نہیں۔
                  </p>
                )}
              </div>

              {/* Step 3: Damaged Quantity */}
              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">
                  3. Damaged Quantity (نقصان تعداد) *
                </label>
                <NumericInput
                  value={damageQty}
                  onChange={val => setDamageQty(val)}
                  placeholder="1"
                  className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-3 py-2 text-sm font-black text-[#EF4444] text-center"
                />
              </div>

              {/* Step 4: Note / Reason */}
              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">
                  4. Damage Reason / Notes (اختیاری تفصیل)
                </label>
                <input
                  type="text"
                  value={damageNotes}
                  onChange={e => setDamageNotes(e.target.value)}
                  placeholder="e.g. Neck crack / Puncture / Broken base"
                  className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-3 py-2 text-xs font-medium text-[#0F172A]"
                />
              </div>

              <div className="flex gap-2 pt-2 border-t border-slate-100">
                <button type="button" onClick={() => setShowDamageModal(false)} className="flex-1 py-2.5 rounded-xl bg-slate-200 font-bold text-xs">
                  Cancel
                </button>
                <button type="submit" className="flex-1 py-2.5 rounded-xl bg-[#EF4444] hover:bg-red-700 text-white font-bold text-xs shadow-xs transition-colors">
                  Log Damage (نقصان درج کریں)
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 4. PURCHASE NEW BOTTLES MODAL */}
      {/* ========================================================================= */}
      {showPurchaseModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl w-full max-w-sm p-5 shadow-2xl space-y-3.5 animate-in fade-in">
            <div className="flex items-center justify-between border-b pb-2">
              <h3 className="font-bold text-sm text-[#0A2540]">Purchase New Bottles (خریداری)</h3>
              <button onClick={() => setShowPurchaseModal(false)} className="p-1 rounded-full bg-slate-100 text-slate-500 hover:bg-slate-200">
                <X className="w-4 h-4" />
              </button>
            </div>
            <form onSubmit={handlePurchaseSubmit} className="space-y-2.5">
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">Bottle Size</label>
                <select
                  value={purchaseBottleId}
                  onChange={e => setPurchaseBottleId(e.target.value)}
                  className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-3 py-2 text-xs font-semibold text-[#0A2540]"
                >
                  {bottleSizes.map(bs => (
                    <option key={bs.id} value={bs.id}>{bs.name}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">Quantity</label>
                <NumericInput
                  value={purchaseQty}
                  onChange={val => setPurchaseQty(val)}
                  placeholder="20"
                  className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-3 py-2 text-xs font-bold text-[#0A2540]"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">Rate per Bottle (Rs.)</label>
                <NumericInput
                  value={purchaseUnitCost}
                  onChange={val => setPurchaseUnitCost(val)}
                  placeholder="800"
                  className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-3 py-2 text-xs font-bold text-[#0A2540]"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">Supplier Name</label>
                <input
                  type="text"
                  value={purchaseSupplier}
                  onChange={e => setPurchaseSupplier(e.target.value)}
                  className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-3 py-2 text-xs"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                    Payment Source (فنڈنگ)
                  </label>
                  <select
                    value={purchasePaymentSource}
                    onChange={e => setPurchasePaymentSource(e.target.value as PaymentSource)}
                    className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-2.5 py-2 text-xs font-semibold text-[#0A2540]"
                  >
                    <option value="PAY_FROM_SALE">Pay from Sale (سیل سے)</option>
                    <option value="INVESTMENT">Investment (ذاتی سرمایہ)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                    Payment Mode (طریقہ)
                  </label>
                  <select
                    value={purchasePaymentMethod}
                    onChange={e => setPurchasePaymentMethod(e.target.value as PaymentMethod)}
                    className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-2.5 py-2 text-xs font-semibold text-[#0A2540]"
                  >
                    <option value="CASH">Cash (نقد)</option>
                    <option value="BANK_TRANSFER">Bank (بینک)</option>
                    <option value="JAZZCASH">JazzCash</option>
                    <option value="EASYPAISA">Easypaisa</option>
                  </select>
                </div>
              </div>

              <div className="flex gap-2 pt-2 border-t border-slate-100">
                <button type="button" onClick={() => setShowPurchaseModal(false)} className="flex-1 py-2.5 rounded-xl bg-slate-200 font-bold text-xs">
                  Cancel
                </button>
                <button type="submit" className="flex-1 py-2.5 rounded-xl bg-[#0A2540] hover:bg-[#028090] text-white font-bold text-xs">
                  Confirm Purchase
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 5. ADMIN EDIT BOTTLE SIZE MODAL */}
      {/* ========================================================================= */}
      {editingBottleSize && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl w-full max-w-sm p-5 shadow-2xl space-y-3.5 animate-in fade-in">
            <div className="flex items-center justify-between border-b pb-2">
              <div>
                <h3 className="font-bold text-sm text-[#0A2540]">Edit Bottle Size (سائز ترمیم)</h3>
                <p className="text-[10px] text-slate-500">{editingBottleSize.name}</p>
              </div>
              <button onClick={() => setEditingBottleSize(null)} className="p-1 rounded-full bg-slate-100 text-slate-500 hover:bg-slate-200">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveEditedBottle} className="space-y-2.5">
              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-0.5">Bottle Name *</label>
                <input
                  type="text"
                  required
                  value={sizeFormName}
                  onChange={e => setSizeFormName(e.target.value)}
                  className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-3 py-2 text-xs font-bold text-[#0A2540]"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-0.5">Capacity (Litres)</label>
                  <NumericInput
                    value={sizeFormCapacity}
                    onChange={val => setSizeFormCapacity(val)}
                    placeholder="19"
                    className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-3 py-2 text-xs font-bold text-[#0A2540]"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-0.5">Usage Type *</label>
                  <select
                    value={sizeFormUsageType}
                    onChange={e => setSizeFormUsageType(e.target.value as BottleUsageType)}
                    className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-2 py-2 text-[10px] font-semibold text-[#0A2540]"
                  >
                    <option value="MULTIPLE_TIME">Multiple Time (واپسی)</option>
                    <option value="ONE_TIME">One-Time (ڈسپوزل)</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-0.5">Refill Price (Rs.)</label>
                  <NumericInput
                    value={sizeFormRefillPrice}
                    onChange={val => setSizeFormRefillPrice(val)}
                    placeholder="120"
                    className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-3 py-2 text-xs font-bold text-[#0A2540]"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-0.5">Purchase Cost (Rs.)</label>
                  <NumericInput
                    value={sizeFormPurchaseCost}
                    onChange={val => setSizeFormPurchaseCost(val)}
                    placeholder="800"
                    className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-3 py-2 text-xs font-bold text-[#0A2540]"
                  />
                </div>
              </div>

              {sizeFormUsageType === 'MULTIPLE_TIME' && (
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-0.5">Security Deposit (Rs.)</label>
                  <NumericInput
                    value={sizeFormDepositAmount}
                    onChange={val => setSizeFormDepositAmount(val)}
                    placeholder="1000"
                    className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-3 py-2 text-xs font-bold text-emerald-700"
                  />
                </div>
              )}

              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-0.5">UOM (یونٹ)</label>
                <input
                  type="text"
                  value={sizeFormUom}
                  onChange={e => setSizeFormUom(e.target.value)}
                  placeholder="e.g. Bottles / Cartons"
                  className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-3 py-2 text-xs font-semibold text-[#0A2540]"
                />
              </div>

              <div className="flex gap-2 pt-2 border-t border-slate-100">
                <button type="button" onClick={() => setEditingBottleSize(null)} className="flex-1 py-2.5 rounded-xl bg-slate-200 font-bold text-xs">
                  Cancel
                </button>
                <button type="submit" className="flex-1 py-2.5 rounded-xl bg-[#0A2540] hover:bg-[#028090] text-white font-bold text-xs">
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 6. ADMIN ADD NEW BOTTLE SIZE MODAL */}
      {/* ========================================================================= */}
      {showAddBottleModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl w-full max-w-sm p-5 shadow-2xl space-y-3.5 animate-in fade-in">
            <div className="flex items-center justify-between border-b pb-2">
              <div>
                <h3 className="font-bold text-sm text-[#0A2540]">Add New Bottle Size (نیا سائز)</h3>
                <p className="text-[10px] text-slate-500">پلانٹ میں نیا بوتل سائز رجسٹر کریں</p>
              </div>
              <button onClick={() => setShowAddBottleModal(false)} className="p-1 rounded-full bg-slate-100 text-slate-500 hover:bg-slate-200">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveNewBottle} className="space-y-2.5">
              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-0.5">Bottle Name *</label>
                <input
                  type="text"
                  required
                  value={sizeFormName}
                  onChange={e => setSizeFormName(e.target.value)}
                  placeholder="e.g. 19 Litre Bottle"
                  className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-3 py-2 text-xs font-bold text-[#0A2540]"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-0.5">Capacity (Litres)</label>
                  <NumericInput
                    value={sizeFormCapacity}
                    onChange={val => setSizeFormCapacity(val)}
                    placeholder="19"
                    className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-3 py-2 text-xs font-bold text-[#0A2540]"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-0.5">Usage Type *</label>
                  <select
                    value={sizeFormUsageType}
                    onChange={e => setSizeFormUsageType(e.target.value as BottleUsageType)}
                    className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-2 py-2 text-[10px] font-semibold text-[#0A2540]"
                  >
                    <option value="MULTIPLE_TIME">Multiple Time (واپسی)</option>
                    <option value="ONE_TIME">One-Time (ڈسپوزل)</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-0.5">Refill Price (Rs.)</label>
                  <NumericInput
                    value={sizeFormRefillPrice}
                    onChange={val => setSizeFormRefillPrice(val)}
                    placeholder="120"
                    className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-3 py-2 text-xs font-bold text-[#0A2540]"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-0.5">Purchase Cost (Rs.)</label>
                  <NumericInput
                    value={sizeFormPurchaseCost}
                    onChange={val => setSizeFormPurchaseCost(val)}
                    placeholder="800"
                    className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-3 py-2 text-xs font-bold text-[#0A2540]"
                  />
                </div>
              </div>

              {sizeFormUsageType === 'MULTIPLE_TIME' && (
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-0.5">Security Deposit (Rs.)</label>
                  <NumericInput
                    value={sizeFormDepositAmount}
                    onChange={val => setSizeFormDepositAmount(val)}
                    placeholder="1000"
                    className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-3 py-2 text-xs font-bold text-emerald-700"
                  />
                </div>
              )}

              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-0.5">UOM (یونٹ)</label>
                <input
                  type="text"
                  value={sizeFormUom}
                  onChange={e => setSizeFormUom(e.target.value)}
                  placeholder="e.g. Bottles / Cartons"
                  className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-3 py-2 text-xs font-semibold text-[#0A2540]"
                />
              </div>

              <div className="flex gap-2 pt-2 border-t border-slate-100">
                <button type="button" onClick={() => setShowAddBottleModal(false)} className="flex-1 py-2.5 rounded-xl bg-slate-200 font-bold text-xs">
                  Cancel
                </button>
                <button type="submit" className="flex-1 py-2.5 rounded-xl bg-[#0A2540] hover:bg-[#028090] text-white font-bold text-xs shadow-xs transition-colors">
                  Add Size (شامل کریں)
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 7. ADMIN DELETE BOTTLE SIZE CONFIRMATION */}
      {/* ========================================================================= */}
      {deletingBottleSize && (
        <div className="fixed inset-0 z-60 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl w-full max-w-sm p-5 shadow-2xl space-y-3.5 text-center animate-in fade-in">
            <div className="w-12 h-12 rounded-full bg-red-100 text-red-600 flex items-center justify-center mx-auto">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <h3 className="font-bold text-sm text-[#0A2540]">
              Delete &quot;{deletingBottleSize.name}&quot;?
            </h3>
            <p className="text-[11px] text-slate-500">
              کیا آپ واقعی اس بوتل سائز کو مکمل ختم کرنا چاہتے ہیں؟ اس سے متعلقہ انوینٹری اور طے شدہ ریٹ بھی صاف ہو جائیں گے۔
            </p>
            <div className="flex items-center gap-2 pt-2">
              <button
                type="button"
                onClick={() => setDeletingBottleSize(null)}
                className="flex-1 py-2.5 rounded-xl bg-slate-200 font-bold text-xs text-slate-700"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  deleteBottleSize(deletingBottleSize.id);
                  setDeletingBottleSize(null);
                  alert(`Bottle size "${deletingBottleSize.name}" has been deleted.`);
                }}
                className="flex-1 py-2.5 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold text-xs shadow-xs transition-colors"
              >
                Confirm Delete
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 8. RESET STOCK TO 0 CONFIRMATION */}
      {/* ========================================================================= */}
      {showResetConfirm && (
        <div className="fixed inset-0 z-60 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl w-full max-w-sm p-5 shadow-2xl space-y-3.5 text-center animate-in fade-in">
            <div className="w-12 h-12 rounded-full bg-amber-100 text-amber-700 flex items-center justify-center mx-auto">
              <RotateCcw className="w-6 h-6" />
            </div>
            <h3 className="font-bold text-sm text-[#0A2540]">Reset All Bottle Stocks to 0?</h3>
            <p className="text-[11px] text-slate-500">
              تمام بوٹل انوینٹری (Full, Empty, With Customers, Damaged) اور گاہکوں کے پاس موجود ہولڈ بوتلیں زیرو ہو جائیں گی۔
            </p>
            <div className="flex items-center gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowResetConfirm(false)}
                className="flex-1 py-2.5 rounded-xl bg-slate-200 font-bold text-xs text-slate-700"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  resetAllBottleStocksToZero();
                  setShowResetConfirm(false);
                  alert("تمام بوتل اسٹاک اور ہولڈ بوتلیں 0 پر سیٹ کر دی گئی ہیں!");
                }}
                className="flex-1 py-2.5 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold text-xs shadow-xs transition-colors"
              >
                Reset to 0
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* ADD / EDIT MATERIAL MODAL */}
      {/* ========================================================================= */}
      {(showAddMaterialModal || editingMaterial) && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl w-full max-w-sm p-5 shadow-2xl space-y-3 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b pb-2">
              <div>
                <h3 className="font-bold text-sm text-[#0A2540]">
                  {editingMaterial ? 'Edit Material Item' : 'Add New Material Item'}
                </h3>
                <p className="text-[10px] text-[#00A896] font-urdu font-bold">
                  {editingMaterial ? 'سامان کی تفصیلات تبدیل کریں' : 'نیا سامان شامل کریں'}
                </p>
              </div>
              <button
                type="button"
                onClick={() => {
                  setShowAddMaterialModal(false);
                  setEditingMaterial(null);
                }}
                className="p-1 rounded-full bg-slate-100 text-slate-500"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveMaterialSubmit} className="space-y-2.5">
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                  Item Name (سامان کا نام) *
                </label>
                <input
                  required
                  type="text"
                  value={matFormName}
                  onChange={e => setMatFormName(e.target.value)}
                  placeholder="e.g. 19L Blue Caps / CTO Filter 20-Inch"
                  className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-3 py-2 text-xs font-medium"
                />
              </div>

              {/* Requirement: Category Selection */}
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                  Item Category (کیٹیگری) *
                </label>
                <select
                  required
                  value={matFormCategory}
                  onChange={e => setMatFormCategory(e.target.value as MaterialCategory)}
                  className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-2.5 py-1.5 text-xs font-semibold text-[#0A2540]"
                >
                  {MATERIAL_CATEGORIES.map(cat => (
                    <option key={cat} value={cat}>{cat}</option>
                  ))}
                </select>
              </div>

              {/* Requirement: Mandatory UOM Selection */}
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                  Unit of Measure - UOM (پیمائش کی اکائی) *
                </label>
                <select
                  required
                  value={matFormUom}
                  onChange={e => setMatFormUom(e.target.value as MaterialUOM)}
                  className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-2.5 py-1.5 text-xs font-semibold text-[#0A2540]"
                >
                  {MATERIAL_UOMS.map(u => (
                    <option key={u} value={u}>{u}</option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                    Current Stock ({matFormUom})
                  </label>
                  <NumericInput
                    value={matFormStock}
                    onChange={val => setMatFormStock(val)}
                    placeholder="0"
                    className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-3 py-2 text-xs font-bold"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                    Purchase Rate (Rs./{matFormUom})
                  </label>
                  <NumericInput
                    value={matFormRate}
                    onChange={val => setMatFormRate(val)}
                    placeholder="0"
                    className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-3 py-2 text-xs font-bold"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                  Supplier / Vendor Name
                </label>
                <input
                  type="text"
                  value={matFormSupplier}
                  onChange={e => setMatFormSupplier(e.target.value)}
                  placeholder="e.g. Al-Madina Plastic Karachi"
                  className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-3 py-2 text-xs"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => {
                    setShowAddMaterialModal(false);
                    setEditingMaterial(null);
                  }}
                  className="flex-1 py-2 rounded-xl bg-slate-200 text-slate-700 font-bold text-xs"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 rounded-xl bg-[#0A2540] hover:bg-[#07192C] text-white font-bold text-xs"
                >
                  {editingMaterial ? 'Update Item' : 'Save Item'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* DELETE MATERIAL CONFIRMATION MODAL */}
      {/* ========================================================================= */}
      {deletingMaterial && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl w-full max-w-sm p-5 shadow-2xl space-y-3 text-center">
            <AlertTriangle className="w-8 h-8 text-red-600 mx-auto" />
            <h3 className="font-bold text-sm text-red-900">
              Delete &quot;{deletingMaterial.name}&quot;?
            </h3>
            <p className="text-[11px] text-slate-600">
              This will remove this item from the material inventory. This action cannot be undone.
            </p>
            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={() => setDeletingMaterial(null)}
                className="flex-1 py-2 rounded-xl bg-slate-200 font-bold text-xs"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleDeleteMaterialConfirm}
                className="flex-1 py-2 rounded-xl bg-red-600 text-white font-bold text-xs hover:bg-red-700"
              >
                Yes, Delete Item
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* ISSUE MATERIAL MODAL (With "Issue To" dropdown) */}
      {/* ========================================================================= */}
      {showIssueMaterialModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl w-full max-w-sm p-5 shadow-2xl space-y-3">
            <h3 className="font-bold text-sm text-[#0A2540]">Issue Material (سامان جاری کریں)</h3>
            <form onSubmit={handleIssueMaterialSubmit} className="space-y-2.5">
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">Select Material</label>
                <select
                  value={selectedMaterialId}
                  onChange={e => setSelectedMaterialId(e.target.value)}
                  className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-3 py-2 text-xs font-semibold"
                >
                  {factoryMaterials.map(m => (
                    <option key={m.id} value={m.id}>{m.name} ({m.currentStock} {m.uom})</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">Quantity to Issue</label>
                <NumericInput
                  value={materialQty}
                  onChange={val => setMaterialQty(val)}
                  placeholder="1"
                  className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-3 py-2 text-xs font-bold"
                />
              </div>

              {/* Requirement: "issue catagery ki jaga issue to ho or issue to me ye ye option ho" */}
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                  Issue To (سامان کس کو جاری ہوا) *
                </label>
                <select
                  value={materialIssueTo}
                  onChange={e => setMaterialIssueTo(e.target.value as MaterialIssueTo)}
                  className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-3 py-2 text-xs font-semibold text-[#0A2540]"
                >
                  {MATERIAL_ISSUE_TO_OPTIONS.map(opt => (
                    <option key={opt} value={opt}>{opt}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">Notes / Remarks (اختیاری)</label>
                <input
                  type="text"
                  value={materialIssueNotes}
                  onChange={e => setMaterialIssueNotes(e.target.value)}
                  placeholder="e.g. Issued for plant maintenance shift"
                  className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-3 py-2 text-xs"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button type="button" onClick={() => setShowIssueMaterialModal(false)} className="flex-1 py-2 rounded-xl bg-slate-200 font-bold text-xs">
                  Cancel
                </button>
                <button type="submit" className="flex-1 py-2 rounded-xl bg-[#0A2540] text-white font-bold text-xs">
                  Confirm Issue
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* PURCHASE / REFILL MATERIAL MODAL */}
      {/* ========================================================================= */}
      {showPurchaseMaterialModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl w-full max-w-sm p-5 shadow-2xl space-y-3">
            <h3 className="font-bold text-sm text-[#0A2540]">Purchase Material Stock</h3>
            <form onSubmit={handlePurchaseMaterialSubmit} className="space-y-2.5">
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">Select Material</label>
                <select
                  value={selectedMaterialId}
                  onChange={e => setSelectedMaterialId(e.target.value)}
                  className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-3 py-2 text-xs"
                >
                  {factoryMaterials.map(m => (
                    <option key={m.id} value={m.id}>{m.name} ({m.uom})</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">Quantity</label>
                <NumericInput
                  value={materialQty}
                  onChange={val => setMaterialQty(val)}
                  placeholder="1000"
                  className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-3 py-2 text-xs font-bold"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">Unit Cost (Rs.)</label>
                <NumericInput
                  value={materialUnitCost}
                  onChange={val => setMaterialUnitCost(val)}
                  placeholder="0"
                  className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-3 py-2 text-xs font-bold"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">Supplier</label>
                <input
                  type="text"
                  value={materialSupplier}
                  onChange={e => setMaterialSupplier(e.target.value)}
                  className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-3 py-2 text-xs"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                    Payment Source (فنڈنگ)
                  </label>
                  <select
                    value={purchasePaymentSource}
                    onChange={e => setPurchasePaymentSource(e.target.value as PaymentSource)}
                    className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-2.5 py-2 text-xs font-semibold text-[#0A2540]"
                  >
                    <option value="PAY_FROM_SALE">Pay from Sale (سیل سے)</option>
                    <option value="INVESTMENT">Investment (ذاتی سرمایہ)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                    Payment Mode (طریقہ)
                  </label>
                  <select
                    value={purchasePaymentMethod}
                    onChange={e => setPurchasePaymentMethod(e.target.value as PaymentMethod)}
                    className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-2.5 py-2 text-xs font-semibold text-[#0A2540]"
                  >
                    <option value="CASH">Cash (نقد)</option>
                    <option value="BANK_TRANSFER">Bank (بینک)</option>
                    <option value="JAZZCASH">JazzCash</option>
                    <option value="EASYPAISA">Easypaisa</option>
                  </select>
                </div>
              </div>

              <div className="flex gap-2 pt-2">
                <button type="button" onClick={() => setShowPurchaseMaterialModal(false)} className="flex-1 py-2 rounded-xl bg-slate-200 font-bold text-xs">
                  Cancel
                </button>
                <button type="submit" className="flex-1 py-2 rounded-xl bg-[#10B981] text-white font-bold text-xs">
                  Refill Stock
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
