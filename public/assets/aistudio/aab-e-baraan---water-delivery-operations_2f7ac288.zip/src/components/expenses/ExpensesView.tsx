import React, { useState } from 'react';
import { useWaterApp } from '../../context/WaterAppContext';
import { 
  Receipt, 
  Plus, 
  Search, 
  CheckCircle2, 
  Calendar, 
  X, 
  Coins, 
  Tag, 
  Filter, 
  Check, 
  Trash2, 
  ChevronDown, 
  AlertTriangle, 
  User,
  Pencil
} from 'lucide-react';
import { Expense, ExpenseType, PaymentMethod, PaymentSource } from '../../types';
import { NumericInput } from '../common/NumericInput';

interface ExpensesViewProps {
  onOpenAddExpense?: () => void;
  isAddExpenseOpen?: boolean;
  onCloseAddExpense?: () => void;
}

type Period = 'ALL' | 'TODAY' | 'YESTERDAY' | 'LAST_WEEK' | 'LAST_MONTH';
type StatusFilter = 'ALL' | 'VERIFIED' | 'PENDING';

export const ExpensesView: React.FC<ExpensesViewProps> = ({
  onOpenAddExpense,
  isAddExpenseOpen = false,
  onCloseAddExpense
}) => {
  const { 
    expenses, 
    expenseCategories, 
    addExpense, 
    updateExpense,
    approveExpense, 
    deleteExpense, 
    currentUser, 
    businessProfile 
  } = useWaterApp();

  const [selectedPeriod, setSelectedPeriod] = useState<Period>('ALL');
  const [selectedTypeFilter, setSelectedTypeFilter] = useState<ExpenseType | null>(null);
  const [selectedCategoryFilter, setSelectedCategoryFilter] = useState<string | null>(null);
  const [selectedStatusFilter, setSelectedStatusFilter] = useState<StatusFilter>('ALL');
  const [showAddDialog, setShowAddDialog] = useState(isAddExpenseOpen);
  const [searchTerm, setSearchTerm] = useState('');

  // Expense detail modal state
  const [selectedExpense, setSelectedExpense] = useState<Expense | null>(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  // Edit Expense modal state (Requirement 10)
  const [editingExpense, setEditingExpense] = useState<Expense | null>(null);
  const [editAmount, setEditAmount] = useState<number>(0);
  const [editDesc, setEditDesc] = useState('');
  const [editPayee, setEditPayee] = useState('');
  const [editCatId, setEditCatId] = useState('');
  const [editSource, setEditSource] = useState<PaymentSource>('PAY_FROM_SALE');
  const [editMethod, setEditMethod] = useState<PaymentMethod>('CASH');
  const [editDate, setEditDate] = useState('');
  const [editNotes, setEditNotes] = useState('');

  React.useEffect(() => {
    if (isAddExpenseOpen) setShowAddDialog(true);
  }, [isAddExpenseOpen]);

  // Form states for new expense
  const [formType, setFormType] = useState<ExpenseType>('OPEX');
  const [formCategoryId, setFormCategoryId] = useState(() => expenseCategories[0]?.id || 'cat_ro_maint');
  const [formDescription, setFormDescription] = useState('');
  const [formAmountNum, setFormAmountNum] = useState<number>(0);
  const [formPaymentSource, setFormPaymentSource] = useState<PaymentSource>('PAY_FROM_SALE');
  const [formPaymentMethod, setFormPaymentMethod] = useState<PaymentMethod>('CASH');
  const [formPayee, setFormPayee] = useState('');
  const [formNotes, setFormNotes] = useState('');

  const todayStr = new Date().toISOString().split('T')[0];
  const yesterdayStr = new Date(Date.now() - 86400000).toISOString().split('T')[0];
  const weekStartStr = new Date(Date.now() - 7 * 86400000).toISOString().split('T')[0];
  const monthStartStr = `${new Date().getFullYear()}-${String(new Date().getMonth() + 1).padStart(2, '0')}-01`;

  // Filter by period
  const periodExpenses = expenses.filter(exp => {
    if (selectedPeriod === 'TODAY') return exp.date === todayStr;
    if (selectedPeriod === 'YESTERDAY') return exp.date === yesterdayStr;
    if (selectedPeriod === 'LAST_WEEK') return exp.date >= weekStartStr;
    if (selectedPeriod === 'LAST_MONTH') return exp.date >= monthStartStr;
    return true;
  });

  // Filter by search, type, category, status
  const filteredExpenses = periodExpenses.filter(exp => {
    const matchesSearch = 
      exp.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      exp.voucherNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      exp.categoryName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      exp.payee.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesType = selectedTypeFilter === null || exp.expenseType === selectedTypeFilter;
    const matchesCategory = selectedCategoryFilter === null || exp.categoryId === selectedCategoryFilter;
    const matchesStatus = 
      selectedStatusFilter === 'ALL' ||
      (selectedStatusFilter === 'VERIFIED' && exp.isAcknowledged) ||
      (selectedStatusFilter === 'PENDING' && !exp.isAcknowledged);

    return matchesSearch && matchesType && matchesCategory && matchesStatus;
  });

  const totalFilteredAmount = filteredExpenses.reduce((sum, e) => sum + e.amount, 0);
  const totalOpex = filteredExpenses.filter(e => e.expenseType === 'OPEX').reduce((sum, e) => sum + e.amount, 0);
  const totalCapex = filteredExpenses.filter(e => e.expenseType === 'CAPEX').reduce((sum, e) => sum + e.amount, 0);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (formAmountNum <= 0 || !formDescription.trim()) {
      alert("Please provide amount and description.");
      return;
    }

    const cat = expenseCategories.find(c => c.id === formCategoryId);

    addExpense({
      date: todayStr,
      expenseType: formType,
      categoryId: formCategoryId,
      categoryName: cat ? cat.name : 'General',
      description: formDescription.trim(),
      amount: formAmountNum,
      paymentSource: formPaymentSource,
      paymentMethod: formPaymentMethod,
      payee: formPayee.trim() || 'Vendor',
      notes: formNotes.trim(),
      enteredBy: currentUser.name,
      enteredByRole: currentUser.role,
      isAcknowledged: true,
      acknowledgedBy: currentUser.name,
      isApprovedByOwner: currentUser.role === 'ADMIN'
    });

    setShowAddDialog(false);
    if (onCloseAddExpense) onCloseAddExpense();
    setFormDescription('');
    setFormAmountNum(0);
    setFormPayee('');
    setFormNotes('');
  };

  const handleOpenEdit = (exp: Expense) => {
    setEditingExpense(exp);
    setEditAmount(exp.amount);
    setEditDesc(exp.description);
    setEditPayee(exp.payee);
    setEditCatId(exp.categoryId);
    setEditSource(exp.paymentSource || ((exp.paymentMethod as any) === 'INVESTMENT' ? 'INVESTMENT' : 'PAY_FROM_SALE'));
    setEditMethod((exp.paymentMethod as any) === 'PAY_FROM_SALE' || (exp.paymentMethod as any) === 'INVESTMENT' ? 'CASH' : exp.paymentMethod);
    setEditDate(exp.date);
    setEditNotes(exp.notes || '');
  };

  const handleSaveEditedExpense = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingExpense) return;
    if (editAmount <= 0 || !editDesc.trim()) {
      alert("Please enter valid amount and description.");
      return;
    }

    const cat = expenseCategories.find(c => c.id === editCatId);
    const res = updateExpense(editingExpense.id, {
      amount: editAmount,
      description: editDesc.trim(),
      payee: editPayee.trim() || 'Vendor',
      categoryId: editCatId,
      categoryName: cat ? cat.name : editingExpense.categoryName,
      paymentSource: editSource,
      paymentMethod: editMethod,
      date: editDate,
      notes: editNotes.trim()
    });

    if (res.success) {
      if (selectedExpense && selectedExpense.id === editingExpense.id) {
        setSelectedExpense({
          ...selectedExpense,
          amount: editAmount,
          description: editDesc.trim(),
          payee: editPayee.trim() || 'Vendor',
          categoryName: cat ? cat.name : selectedExpense.categoryName,
          paymentSource: editSource,
          paymentMethod: editMethod,
          date: editDate,
          notes: editNotes.trim(),
          lastEditedAt: Date.now(),
          lastEditedBy: currentUser.name
        });
      }
      setEditingExpense(null);
    } else {
      alert(res.error || "Failed to update expense");
    }
  };

  const handleDeleteExpense = () => {
    if (!selectedExpense) return;
    const res = deleteExpense(selectedExpense.id);
    if (res.success) {
      setShowDeleteConfirm(false);
      setSelectedExpense(null);
    } else {
      alert(res.error || "Failed to delete expense.");
    }
  };

  const isAdmin = currentUser.role === 'ADMIN';

  return (
    <div className="space-y-3.5 pb-24 text-xs">
      
      {/* 1. Header Card with Period Selector & Add Button */}
      <div className="bg-white border border-[#CBD5E1]/70 rounded-2xl p-4 shadow-xs space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-sm font-bold text-[#0A2540]">
              Plant Expenses (اخراجات)
            </h2>
            <p className="text-[11px] text-[#475569] font-urdu">
              پلانٹ کے روزمرہ بلز، فیول، سروس اور مشینری اخراجات
            </p>
          </div>

          <button
            onClick={() => setShowAddDialog(true)}
            className="px-3 py-1.5 rounded-xl bg-[#0A2540] hover:bg-[#07192C] text-white font-bold text-xs flex items-center gap-1.5 shadow-sm active:scale-95 transition-all"
          >
            <Plus className="w-4 h-4" />
            <span>Add Expense</span>
          </button>
        </div>

        {/* Period Chips */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar">
          {[
            { id: 'TODAY' as Period, label: 'Today (آج)' },
            { id: 'YESTERDAY' as Period, label: 'Yesterday (کل)' },
            { id: 'LAST_WEEK' as Period, label: 'Last 7 Days' },
            { id: 'LAST_MONTH' as Period, label: 'This Month' },
            { id: 'ALL' as Period, label: 'All Expenses' },
          ].map(p => (
            <button
              key={p.id}
              onClick={() => setSelectedPeriod(p.id)}
              className={`px-3 py-1.5 rounded-full font-bold whitespace-nowrap text-[11px] transition-all ${
                selectedPeriod === p.id
                  ? 'bg-[#0A2540] text-white shadow-xs'
                  : 'bg-[#F0F7FB] text-slate-700 hover:bg-[#E8F4F8]'
              }`}
            >
              {p.label}
            </button>
          ))}
        </div>

        {/* Cost Summary Breakdown */}
        <div className="grid grid-cols-3 gap-2 pt-1 text-center">
          <div className="p-2 rounded-xl bg-[#F0F7FB]">
            <span className="text-[10px] text-slate-500 block">Total Expenses</span>
            <strong className="text-sm font-black text-[#EF4444]">
              Rs. {totalFilteredAmount.toLocaleString()}
            </strong>
          </div>
          <div className="p-2 rounded-xl bg-[#FEF3C7]/60">
            <span className="text-[10px] text-[#92400E] block">OPEX (روزمرہ)</span>
            <strong className="text-xs font-bold text-[#D97706]">
              Rs. {totalOpex.toLocaleString()}
            </strong>
          </div>
          <div className="p-2 rounded-xl bg-[#F3E5F5]/60">
            <span className="text-[10px] text-[#6A1B9A] block">CAPEX (اثاثہ)</span>
            <strong className="text-xs font-bold text-[#8E24AA]">
              Rs. {totalCapex.toLocaleString()}
            </strong>
          </div>
        </div>
      </div>

      {/* 2. Filters & Search */}
      <div className="space-y-2">
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Search description, payee, voucher #..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3 py-2 bg-white border border-[#CBD5E1] rounded-xl text-xs text-[#0F172A] focus:outline-none focus:border-[#0A2540]"
          />
        </div>

        {/* Type Filter */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-0.5 no-scrollbar">
          <button
            onClick={() => setSelectedTypeFilter(null)}
            className={`px-3 py-1 rounded-full font-bold whitespace-nowrap text-[11px] ${
              selectedTypeFilter === null ? 'bg-[#0A2540] text-white' : 'bg-white text-slate-700 border border-[#CBD5E1]'
            }`}
          >
            All Types
          </button>
          <button
            onClick={() => setSelectedTypeFilter('OPEX')}
            className={`px-3 py-1 rounded-full font-bold whitespace-nowrap text-[11px] ${
              selectedTypeFilter === 'OPEX' ? 'bg-[#0A2540] text-white' : 'bg-white text-slate-700 border border-[#CBD5E1]'
            }`}
          >
            OPEX (Daily)
          </button>
          <button
            onClick={() => setSelectedTypeFilter('CAPEX')}
            className={`px-3 py-1 rounded-full font-bold whitespace-nowrap text-[11px] ${
              selectedTypeFilter === 'CAPEX' ? 'bg-[#0A2540] text-white' : 'bg-white text-slate-700 border border-[#CBD5E1]'
            }`}
          >
            CAPEX (Asset)
          </button>
        </div>
      </div>

      {/* 3. Expense Cards List */}
      <div className="space-y-2">
        {filteredExpenses.length === 0 ? (
          <div className="bg-white border border-[#CBD5E1]/70 rounded-2xl p-8 text-center text-xs text-[#475569]">
            <Receipt className="w-8 h-8 text-slate-300 mx-auto mb-2" />
            <p className="font-semibold text-slate-600">No expenses recorded for this period.</p>
          </div>
        ) : (
          filteredExpenses.map(exp => (
            <div
              key={exp.id}
              onClick={() => setSelectedExpense(exp)}
              className="bg-white border border-[#CBD5E1]/70 rounded-2xl p-3.5 shadow-xs space-y-2 cursor-pointer hover:border-[#0A2540]/40 transition-colors"
            >
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-2">
                  <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold ${
                    exp.expenseType === 'CAPEX' ? 'bg-[#F3E5F5] text-[#6A1B9A]' : 'bg-[#0A2540]/10 text-[#0A2540]'
                  }`}>
                    {exp.expenseType}
                  </span>
                  <span className="font-bold text-xs text-[#0A2540]">{exp.categoryName}</span>
                </div>

                <span className="font-black text-sm text-[#EF4444]">
                  Rs. {exp.amount.toLocaleString()}
                </span>
              </div>

              <p className="text-xs font-semibold text-[#0F172A]">{exp.description}</p>

              <div className="pt-2 border-t border-[#E2E8F0] flex items-center justify-between text-[11px] text-[#475569]">
                <span>
                  {exp.date} • {exp.payee} • <strong className="text-[#0A2540] font-mono">{exp.voucherNumber}</strong>
                </span>

                <div className="flex items-center gap-1">
                  <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                    exp.paymentSource === 'INVESTMENT' ? 'bg-purple-100 text-purple-800' : 'bg-[#FEF3C7] text-[#92400E]'
                  }`}>
                    {exp.paymentSource === 'INVESTMENT' ? 'Investment' : 'Pay from Sale'}
                  </span>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-[#E8F4F8] text-[#0A2540]">
                    {exp.paymentMethod}
                  </span>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* EXPENSE DETAIL MODAL */}
      {selectedExpense && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl w-full max-w-sm p-5 shadow-2xl space-y-3 font-sans text-xs">
            <div className="flex items-center justify-between border-b pb-2">
              <div>
                <h3 className="font-bold text-sm text-[#0A2540]">{selectedExpense.voucherNumber}</h3>
                <p className="text-[11px] text-[#00A896] font-urdu font-bold">خرچہ تفصیل واؤچر</p>
              </div>
              <button 
                onClick={() => {
                  setSelectedExpense(null);
                  setShowDeleteConfirm(false);
                }}
                className="p-1 rounded-full bg-slate-100 text-slate-500 hover:bg-slate-200"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-3 rounded-2xl bg-[#F0F7FB] border border-[#CBD5E1]/60 space-y-1.5 text-xs">
              <div className="flex justify-between">
                <span className="text-slate-500">Category:</span>
                <strong className="text-[#0A2540]">{selectedExpense.categoryName} ({selectedExpense.expenseType})</strong>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Amount:</span>
                <strong className="text-sm font-black text-[#EF4444]">Rs. {selectedExpense.amount.toLocaleString()}</strong>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Payee / Vendor:</span>
                <span className="font-semibold">{selectedExpense.payee}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Payment Method:</span>
                <span className="font-semibold">{selectedExpense.paymentMethod}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Date:</span>
                <span>{selectedExpense.date}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Entered By:</span>
                <span>{selectedExpense.enteredBy} ({selectedExpense.enteredByRole})</span>
              </div>
            </div>

            <div>
              <p className="font-bold text-[#0A2540] text-xs mb-1">Description (تفصیل):</p>
              <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 text-slate-800">
                {selectedExpense.description}
              </div>
            </div>

            {selectedExpense.notes && (
              <div>
                <p className="font-bold text-slate-500 text-[11px] mb-0.5">Notes:</p>
                <p className="text-slate-600 italic text-[11px]">{selectedExpense.notes}</p>
              </div>
            )}

            <div className="flex items-center justify-between pt-1">
              {isAdmin && (
                <button
                  onClick={() => handleOpenEdit(selectedExpense)}
                  className="py-1.5 px-3 rounded-xl bg-[#0A2540] hover:bg-[#028090] text-white font-bold text-xs flex items-center gap-1 shadow-xs transition-colors"
                  title="Edit Expense (صرف ایڈمن)"
                >
                  <Pencil className="w-3 h-3" />
                  <span>Edit Expense</span>
                </button>
              )}

              <button
                onClick={() => {
                  setSelectedExpense(null);
                  setShowDeleteConfirm(false);
                }}
                className="py-2 px-4 rounded-xl bg-slate-200 text-slate-700 font-bold"
              >
                Close
              </button>
            </div>

            {/* ADMIN ONLY DELETE EXPENSE */}
            {isAdmin && (
              <div className="pt-2 border-t border-red-100">
                {!showDeleteConfirm ? (
                  <button
                    onClick={() => setShowDeleteConfirm(true)}
                    className="w-full py-2 px-3 rounded-xl bg-red-50 hover:bg-red-100 text-red-700 font-bold text-xs flex items-center justify-center gap-2 border border-red-200"
                  >
                    <Trash2 className="w-3.5 h-3.5 text-red-600" />
                    <span>Delete Expense (صرف ایڈمن)</span>
                  </button>
                ) : (
                  <div className="p-3 rounded-2xl bg-red-50 border border-red-300 space-y-2 text-center animate-in fade-in">
                    <AlertTriangle className="w-6 h-6 text-red-600 mx-auto" />
                    <p className="font-bold text-red-800 text-xs">
                      Delete Expense {selectedExpense.voucherNumber}?
                    </p>
                    <p className="text-[11px] text-red-700">
                      Amount: Rs. {selectedExpense.amount}. This cannot be undone.
                    </p>
                    <div className="flex items-center gap-2 pt-1">
                      <button
                        onClick={() => setShowDeleteConfirm(false)}
                        className="flex-1 py-1.5 rounded-xl bg-slate-200 text-slate-700 font-bold text-[11px]"
                      >
                        Cancel
                      </button>
                      <button
                        onClick={handleDeleteExpense}
                        className="flex-1 py-1.5 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold text-[11px]"
                      >
                        Yes, Delete
                      </button>
                    </div>
                  </div>
                )}
              </div>
            )}

          </div>
        </div>
      )}

      {/* ADD EXPENSE DIALOG */}
      {showAddDialog && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl w-full max-w-md p-5 shadow-2xl space-y-3 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b pb-2">
              <div>
                <h3 className="font-bold text-sm text-[#0A2540]">Add Plant Expense Voucher</h3>
                <p className="text-[11px] text-[#00A896] font-urdu">نیا خرچہ واؤچر درج کریں</p>
              </div>
              <button 
                onClick={() => {
                  setShowAddDialog(false);
                  if (onCloseAddExpense) onCloseAddExpense();
                }} 
                className="p-1 rounded-full bg-slate-100 text-slate-500"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-2.5">
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">Expense Type</label>
                  <select
                    value={formType}
                    onChange={e => setFormType(e.target.value as ExpenseType)}
                    className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-2.5 py-2 text-xs"
                  >
                    <option value="OPEX">OPEX (روزمرہ خرچ)</option>
                    <option value="CAPEX">CAPEX (اثاثہ جات)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">Category</label>
                  <select
                    value={formCategoryId}
                    onChange={e => setFormCategoryId(e.target.value)}
                    className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-2.5 py-2 text-xs font-semibold text-[#0A2540]"
                  >
                    {expenseCategories.map(cat => (
                      <option key={cat.id} value={cat.id} className="text-xs py-0.5">{cat.name} ({cat.urduName})</option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">Description (تفصیل) *</label>
                <input
                  required
                  type="text"
                  value={formDescription}
                  onChange={e => setFormDescription(e.target.value)}
                  placeholder="e.g. 5L petrol for delivery van / Plant tea"
                  className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-3 py-2 text-xs"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">Amount (رقم) *</label>
                  <NumericInput
                    value={formAmountNum}
                    onChange={val => setFormAmountNum(val)}
                    placeholder="0"
                    className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-3 py-2 text-xs font-bold text-[#EF4444]"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">Paid To (Payee)</label>
                  <input
                    type="text"
                    value={formPayee}
                    onChange={e => setFormPayee(e.target.value)}
                    placeholder="Vendor / Person"
                    className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-3 py-2 text-xs"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                    Payment Source (فنڈنگ)
                  </label>
                  <select
                    value={formPaymentSource}
                    onChange={e => setFormPaymentSource(e.target.value as PaymentSource)}
                    className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-2.5 py-2 text-xs font-semibold text-[#0A2540]"
                  >
                    <option value="PAY_FROM_SALE">Pay from Sale (سیل سے)</option>
                    <option value="INVESTMENT">Investment (ذاتی سرمایہ)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                    Payment Mode (ادائیگی طریقہ)
                  </label>
                  <select
                    value={formPaymentMethod}
                    onChange={e => setFormPaymentMethod(e.target.value as PaymentMethod)}
                    className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-2.5 py-2 text-xs font-semibold text-[#0A2540]"
                  >
                    <option value="CASH">Cash (نقد)</option>
                    <option value="BANK_TRANSFER">Bank Transfer (بینک)</option>
                    <option value="JAZZCASH">JazzCash (جاز کیش)</option>
                    <option value="EASYPAISA">Easypaisa (ایزی پیسہ)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">Notes / Remarks</label>
                <input
                  type="text"
                  value={formNotes}
                  onChange={e => setFormNotes(e.target.value)}
                  placeholder="Optional details"
                  className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-3 py-2 text-xs"
                />
              </div>

              <div className="flex items-center gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => {
                    setShowAddDialog(false);
                    if (onCloseAddExpense) onCloseAddExpense();
                  }}
                  className="flex-1 py-2.5 rounded-xl bg-slate-200 text-slate-700 font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-[#0A2540] text-white font-bold"
                >
                  Save Voucher
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* REQUIREMENT 10: ADMIN EDIT EXPENSE MODAL */}
      {editingExpense && (
        <div className="fixed inset-0 z-60 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl w-full max-w-md p-5 shadow-2xl space-y-3.5 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b pb-2">
              <div>
                <h3 className="font-bold text-sm text-[#0A2540]">Edit Expense Voucher (صرف ایڈمن)</h3>
                <p className="text-[10px] text-slate-500">{editingExpense.voucherNumber}</p>
              </div>
              <button 
                onClick={() => setEditingExpense(null)}
                className="p-1 rounded-full bg-slate-100 text-slate-500 hover:bg-slate-200"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveEditedExpense} className="space-y-3">
              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">Expense Date</label>
                <input
                  type="date"
                  value={editDate}
                  onChange={e => setEditDate(e.target.value)}
                  className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-3 py-2 text-xs font-semibold text-[#0A2540]"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">Category</label>
                <select
                  value={editCatId}
                  onChange={e => setEditCatId(e.target.value)}
                  className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-2.5 py-1.5 text-[10px] font-semibold text-[#0A2540] leading-tight"
                >
                  {expenseCategories.map(cat => (
                    <option key={cat.id} value={cat.id} className="text-[10px] py-0.5">{cat.name} ({cat.urduName})</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">Description (تفصیل) *</label>
                <input
                  required
                  type="text"
                  value={editDesc}
                  onChange={e => setEditDesc(e.target.value)}
                  className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-3 py-2 text-xs text-[#0F172A]"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 mb-1">Amount (رقم) *</label>
                  <NumericInput
                    value={editAmount}
                    onChange={val => setEditAmount(val)}
                    placeholder="0"
                    className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-3 py-2 text-xs font-black text-[#EF4444]"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-600 mb-1">Paid To (Payee)</label>
                  <input
                    type="text"
                    value={editPayee}
                    onChange={e => setEditPayee(e.target.value)}
                    className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-3 py-2 text-xs"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 mb-1">Payment Source (فنڈنگ)</label>
                  <select
                    value={editSource}
                    onChange={e => setEditSource(e.target.value as PaymentSource)}
                    className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-2.5 py-2 text-xs font-semibold text-[#0A2540]"
                  >
                    <option value="PAY_FROM_SALE">Pay from Sale (سیل سے)</option>
                    <option value="INVESTMENT">Investment (ذاتی سرمایہ)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-600 mb-1">Payment Mode (ادائیگی طریقہ)</label>
                  <select
                    value={editMethod}
                    onChange={e => setEditMethod(e.target.value as PaymentMethod)}
                    className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-2.5 py-2 text-xs font-semibold text-[#0A2540]"
                  >
                    <option value="CASH">Cash (نقد)</option>
                    <option value="BANK_TRANSFER">Bank Transfer (بینک)</option>
                    <option value="JAZZCASH">JazzCash (جاز کیش)</option>
                    <option value="EASYPAISA">Easypaisa (ایزی پیسہ)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">Notes / Remarks</label>
                <input
                  type="text"
                  value={editNotes}
                  onChange={e => setEditNotes(e.target.value)}
                  className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-3 py-2 text-xs"
                />
              </div>

              <div className="flex items-center gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setEditingExpense(null)}
                  className="flex-1 py-2.5 rounded-xl bg-slate-200 text-slate-700 font-bold text-xs"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-[#0A2540] hover:bg-[#028090] text-white font-bold text-xs shadow-xs transition-colors"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
