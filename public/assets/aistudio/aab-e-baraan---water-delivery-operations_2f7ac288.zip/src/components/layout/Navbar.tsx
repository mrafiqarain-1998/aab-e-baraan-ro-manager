import React, { useState } from 'react';
import { useWaterApp } from '../../context/WaterAppContext';
import { 
  Droplet, 
  ArrowLeft, 
  BarChart2, 
  MoreVertical, 
  ShieldCheck, 
  Check, 
  Users, 
  Database, 
  RefreshCw,
  LogOut,
  ChevronDown,
  Lock,
  User,
  Eye,
  EyeOff,
  X,
  AlertCircle,
  Smartphone
} from 'lucide-react';
import { UserRole } from '../../types';

interface NavbarProps {
  currentTitle: string;
  currentUrduTitle?: string;
  isSubScreen?: boolean;
  onBack?: () => void;
  onNavigateToReports?: () => void;
  onNavigateToStaff?: () => void;
  onNavigateToBackup?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentTitle,
  currentUrduTitle,
  isSubScreen = false,
  onBack,
  onNavigateToReports,
  onNavigateToStaff,
  onNavigateToBackup
}) => {
  const { 
    currentUser, 
    logout,
    switchUserWithCredentials,
    userAccounts,
    resetToDemoData,
    businessProfile 
  } = useWaterApp();

  const [showUserMenu, setShowUserMenu] = useState(false);
  const [showMoreMenu, setShowMoreMenu] = useState(false);
  
  // PWA Install state
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [showInstallHelp, setShowInstallHelp] = useState(false);

  React.useEffect(() => {
    const handlePrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };
    window.addEventListener('beforeinstallprompt', handlePrompt);
    return () => window.removeEventListener('beforeinstallprompt', handlePrompt);
  }, []);

  const handleInstallClick = async () => {
    setShowMoreMenu(false);
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const choice = await deferredPrompt.userChoice;
      if (choice && choice.outcome === 'accepted') {
        setDeferredPrompt(null);
      }
    } else {
      setShowInstallHelp(true);
    }
  };

  // Switch User Modal states
  const [showSwitchModal, setShowSwitchModal] = useState(false);
  const [switchUsername, setSwitchUsername] = useState('');
  const [switchPassword, setSwitchPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [switchError, setSwitchError] = useState<string | null>(null);

  const handleOpenSwitchModal = (prefillUsername?: string) => {
    setSwitchUsername(prefillUsername || '');
    setSwitchPassword('');
    setSwitchError(null);
    setShowUserMenu(false);
    setShowMoreMenu(false);
    setShowSwitchModal(true);
  };

  const handleSwitchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!switchUsername.trim() || !switchPassword.trim()) {
      setSwitchError("Please enter both username and password.");
      return;
    }

    const res = switchUserWithCredentials(switchUsername.trim(), switchPassword);
    if (res.success) {
      setShowSwitchModal(false);
      setSwitchUsername('');
      setSwitchPassword('');
      setSwitchError(null);
    } else {
      setSwitchError(res.error || "Incorrect password.");
    }
  };

  return (
    <>
      <header className="sticky top-0 z-40 bg-[#0A2540] text-white shadow-md select-none">
        <div className="max-w-2xl mx-auto px-4 h-14 flex items-center justify-between gap-2">
          
          {/* Left: Navigation Icon / Title */}
          <div className="flex items-center gap-2.5 overflow-hidden">
            {isSubScreen && onBack ? (
              <button
                onClick={onBack}
                className="p-1.5 -ml-1.5 rounded-full hover:bg-white/10 text-white transition-colors"
                title="Back"
              >
                <ArrowLeft className="w-5 h-5" />
              </button>
            ) : (
              <div className="w-8 h-8 rounded-xl bg-white p-0.5 flex items-center justify-center shrink-0 shadow-xs overflow-hidden">
                <img 
                  src="/aab_e_baraan_logo.png" 
                  alt="Aab-e-Baraan Logo" 
                  className="w-full h-full object-contain" 
                />
              </div>
            )}

            <div className="overflow-hidden">
              <h1 className="font-bold text-sm sm:text-base leading-tight truncate text-white">
                {currentTitle}
              </h1>
              {currentUrduTitle && (
                <p className="text-[11px] text-[#E8F4F8]/80 font-urdu leading-none truncate">
                  {currentUrduTitle}
                </p>
              )}
            </div>
          </div>

          {/* Right Actions: Authenticated User Badge & Menu */}
          <div className="flex items-center gap-1.5 shrink-0">
            
            {/* Authenticated User Role Pill */}
            <div className="relative">
              <button
                onClick={() => setShowUserMenu(!showUserMenu)}
                className="px-2.5 py-1 rounded-full bg-[#00A896] hover:bg-[#009282] text-[#07192C] text-[11px] font-bold flex items-center gap-1 transition-colors shadow-xs"
              >
                <ShieldCheck className="w-3.5 h-3.5 text-[#07192C]" />
                <span className="max-w-[70px] truncate">{currentUser.username}</span>
                <ChevronDown className="w-3 h-3 text-[#07192C]" />
              </button>

              {/* Backdrop to close user menu on any outside click */}
              {showUserMenu && (
                <div 
                  className="fixed inset-0 z-40 bg-transparent" 
                  onClick={() => setShowUserMenu(false)} 
                />
              )}

              {/* User Account Dropdown */}
              {showUserMenu && (
                <div 
                  className="absolute right-0 mt-1.5 w-60 bg-white text-[#0F172A] border border-[#CBD5E1] rounded-2xl shadow-2xl py-2 z-50 text-xs animate-in fade-in"
                >
                  <div className="px-3.5 py-2 border-b border-slate-100">
                    <p className="font-bold text-[#0A2540] truncate">{currentUser.name}</p>
                    <div className="flex items-center justify-between mt-0.5">
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#E8F4F8] text-[#0A2540] font-bold">
                        Role: {currentUser.role}
                      </span>
                      <span className="text-[10px] text-slate-400 font-mono">@{currentUser.username}</span>
                    </div>
                  </div>

                  <div className="p-1 space-y-0.5">
                    {/* Switch User (Protected by Password) */}
                    <button
                      onClick={() => handleOpenSwitchModal()}
                      className="w-full px-3 py-2 text-left flex items-center gap-2 hover:bg-[#F0F7FB] rounded-xl text-slate-700 font-medium transition-colors"
                    >
                      <Lock className="w-4 h-4 text-[#00A896]" />
                      <div className="flex-1">
                        <p className="font-bold text-xs text-[#0A2540]">Switch User (یوزر تبدیل)</p>
                        <p className="text-[10px] text-slate-400">Requires password</p>
                      </div>
                    </button>

                    {/* Direct Logout */}
                    <button
                      onClick={() => {
                        setShowUserMenu(false);
                        logout();
                      }}
                      className="w-full px-3 py-2 text-left flex items-center gap-2 text-red-600 hover:bg-red-50 rounded-xl font-bold transition-colors"
                    >
                      <LogOut className="w-4 h-4 text-red-500" />
                      <span>Log Out (لاگ آؤٹ)</span>
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Reports Quick Icon */}
            {onNavigateToReports && (
              <button
                onClick={onNavigateToReports}
                className="p-2 rounded-full hover:bg-white/10 text-white transition-colors"
                title="Reports & Analytics"
              >
                <BarChart2 className="w-4 h-4" />
              </button>
            )}

            {/* Overflow Options Menu - ONLY SHOWN TO ADMIN */}
            {currentUser.role === 'ADMIN' && (
              <div className="relative">
                <button
                  onClick={() => setShowMoreMenu(!showMoreMenu)}
                  className="p-2 rounded-full hover:bg-white/10 text-white transition-colors"
                  title="More Options"
                >
                  <MoreVertical className="w-4 h-4" />
                </button>

                {/* Backdrop to close 3-dot menu on any outside click */}
                {showMoreMenu && (
                  <div 
                    className="fixed inset-0 z-40 bg-transparent" 
                    onClick={() => setShowMoreMenu(false)} 
                  />
                )}

                {showMoreMenu && (
                  <div 
                    className="absolute right-0 mt-1.5 w-52 bg-white text-[#0F172A] border border-[#CBD5E1] rounded-2xl shadow-2xl py-1.5 z-50 text-xs animate-in fade-in"
                  >
                    {onNavigateToStaff && (
                      <button
                        onClick={() => {
                          setShowMoreMenu(false);
                          onNavigateToStaff();
                        }}
                        className="w-full px-3.5 py-2 text-left flex items-center gap-2.5 hover:bg-[#F0F7FB]"
                      >
                        <Users className="w-4 h-4 text-[#0A2540]" />
                        <span>Staff Accounts (عملہ لاگ ان)</span>
                      </button>
                    )}

                    {onNavigateToBackup && (
                      <button
                        onClick={() => {
                          setShowMoreMenu(false);
                          onNavigateToBackup();
                        }}
                        className="w-full px-3.5 py-2 text-left flex items-center gap-2.5 hover:bg-[#F0F7FB]"
                      >
                        <Database className="w-4 h-4 text-[#0A2540]" />
                        <span>Backup & Restore (بیک اپ)</span>
                      </button>
                    )}

                    <button
                      onClick={() => {
                        setShowMoreMenu(false);
                        handleOpenSwitchModal();
                      }}
                      className="w-full px-3.5 py-2 text-left flex items-center gap-2.5 hover:bg-[#F0F7FB]"
                    >
                      <Lock className="w-4 h-4 text-[#00A896]" />
                      <span>Switch User (پاس ورڈ مطلوب)</span>
                    </button>

                    <button
                      onClick={handleInstallClick}
                      className="w-full px-3.5 py-2 text-left flex items-center gap-2.5 text-[#0F3B66] hover:bg-[#F0F7FB] font-semibold"
                    >
                      <Smartphone className="w-4 h-4 text-[#00A896]" />
                      <span>Install Mobile App (موبائل میں انسٹال)</span>
                    </button>

                    <div className="my-1 border-t border-slate-100" />

                    {/* Logout Button */}
                    <button
                      onClick={() => {
                        setShowMoreMenu(false);
                        logout();
                      }}
                      className="w-full px-3.5 py-2 text-left flex items-center gap-2.5 text-red-600 hover:bg-red-50 font-bold"
                    >
                      <LogOut className="w-4 h-4" />
                      <span>Logout (لاگ آؤٹ کریں)</span>
                    </button>

                    <div className="my-1 border-t border-slate-100" />

                    <button
                      onClick={() => {
                        setShowMoreMenu(false);
                        if (window.confirm("Purge old records and reset demo data?")) {
                          resetToDemoData();
                        }
                      }}
                      className="w-full px-3.5 py-2 text-left flex items-center gap-2.5 text-slate-500 hover:bg-slate-50 text-[11px]"
                    >
                      <RefreshCw className="w-3.5 h-3.5" />
                      <span>Clear Data & Reset</span>
                    </button>
                  </div>
                )}
              </div>
            )}

          </div>

        </div>
      </header>

      {/* SECURE SWITCH USER MODAL (REQUIRES USERNAME & PASSWORD) */}
      {showSwitchModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl w-full max-w-sm p-5 shadow-2xl space-y-3.5 animate-in zoom-in-95 text-xs">
            
            <div className="flex items-center justify-between border-b pb-2">
              <div>
                <h3 className="font-bold text-sm text-[#0A2540] flex items-center gap-1.5">
                  <Lock className="w-4 h-4 text-[#00A896]" />
                  <span>Switch User Account</span>
                </h3>
                <p className="text-[11px] text-[#475569] font-urdu">
                  دوسرے یوزر کے اکاؤنٹ میں جانے کے لیے پاس ورڈ لازمی ہے
                </p>
              </div>
              <button 
                onClick={() => setShowSwitchModal(false)}
                className="p-1 rounded-full bg-slate-100 text-slate-500 hover:bg-slate-200"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {switchError && (
              <div className="p-2.5 rounded-xl bg-red-50 border border-red-200 text-red-700 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 text-red-600" />
                <span>{switchError}</span>
              </div>
            )}

            <form onSubmit={handleSwitchSubmit} className="space-y-3 pt-1">
              {/* Username field */}
              <div>
                <label className="block text-[11px] font-bold text-[#0A2540] mb-1">
                  Username
                </label>
                <div className="relative">
                  <User className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-3" />
                  <input
                    type="text"
                    required
                    value={switchUsername}
                    onChange={(e) => setSwitchUsername(e.target.value)}
                    placeholder="Enter username"
                    className="w-full pl-9 pr-3 py-2 bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl text-xs text-[#0F172A] focus:outline-none focus:border-[#0A2540]"
                  />
                </div>
              </div>

              {/* Password field with Show/Hide toggle */}
              <div>
                <label className="block text-[11px] font-bold text-[#0A2540] mb-1">
                  Password (پاس ورڈ) *
                </label>
                <div className="relative">
                  <Lock className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-3" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={switchPassword}
                    onChange={(e) => setSwitchPassword(e.target.value)}
                    placeholder="Enter user password"
                    className="w-full pl-9 pr-9 py-2 bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl text-xs text-[#0F172A] focus:outline-none focus:border-[#0A2540]"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-400 hover:text-slate-600"
                  >
                    {showPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>

              <div className="flex items-center gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowSwitchModal(false)}
                  className="flex-1 py-2.5 rounded-xl bg-slate-200 text-slate-700 font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-[#0A2540] hover:bg-[#07192C] text-white font-bold"
                >
                  Confirm & Switch
                </button>
              </div>
            </form>

          </div>
        </div>
      )}

      {/* MOBILE APP INSTALL GUIDE MODAL */}
      {showInstallHelp && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl w-full max-w-sm p-5 shadow-2xl space-y-3.5 text-xs animate-in zoom-in-95">
            <div className="flex items-center justify-between border-b pb-2">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-xl bg-[#00A896]/15 text-[#00A896]">
                  <Smartphone className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-sm text-[#0A2540]">
                    Install on Mobile (موبائل میں انسٹال کریں)
                  </h3>
                  <p className="text-[10px] text-slate-500 font-urdu">
                    بغیر کیبل یا یو ایس بی کے ڈائریکٹ انسٹال
                  </p>
                </div>
              </div>
              <button 
                onClick={() => setShowInstallHelp(false)}
                className="p-1 rounded-full bg-slate-100 text-slate-500 hover:bg-slate-200"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 py-1">
              {/* Android Instructions */}
              <div className="p-3 rounded-2xl bg-[#F0F7FB] border border-[#CBD5E1]/60 space-y-1.5">
                <p className="font-bold text-[#0A2540] flex items-center gap-1.5">
                  <span className="w-5 h-5 rounded-full bg-[#0A2540] text-white flex items-center justify-center text-[10px]">1</span>
                  Android Mobile (کروم براؤزر):
                </p>
                <p className="text-slate-600 pl-6 leading-relaxed">
                  اپنے موبائل کے <strong>Chrome</strong> براؤزر میں اوپر دائیں جانب <strong>تین نقطے (⋮)</strong> دبائیں اور <strong>"Install app"</strong> یا <strong>"Add to Home screen"</strong> منتخب کریں۔
                </p>
              </div>

              {/* iPhone Instructions */}
              <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200 space-y-1.5">
                <p className="font-bold text-slate-800 flex items-center gap-1.5">
                  <span className="w-5 h-5 rounded-full bg-slate-700 text-white flex items-center justify-center text-[10px]">2</span>
                  iPhone / Safari:
                </p>
                <p className="text-slate-600 pl-6 leading-relaxed">
                  سفاری میں نیچے موجود <strong>Share</strong> آئیکن دبائیں اور لسٹ میں سے <strong>"Add to Home Screen"</strong> پر کلک کریں۔
                </p>
              </div>

              <div className="p-2.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-[11px] flex items-start gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <span>
                  انسٹال ہونے کے بعد یہ بغیر ایڈریس بار کے مکمل فل اسکرین ایپ کی طرح چلے گی اور فائر بیس ڈیٹا آن لائن سنک ہوگا۔
                </span>
              </div>
            </div>

            <button
              onClick={() => setShowInstallHelp(false)}
              className="w-full py-2.5 rounded-xl bg-[#0A2540] text-white font-bold"
            >
              ٹھیک ہے، سمجھ آ گئی (Close)
            </button>
          </div>
        </div>
      )}
    </>
  );
};
