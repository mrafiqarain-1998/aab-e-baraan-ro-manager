import React from 'react';
import { LayoutDashboard, Truck, Users, Receipt, Boxes } from 'lucide-react';

export type MainNavTab = 'dashboard' | 'deliveries' | 'customers' | 'expenses' | 'stock';

interface MobileBottomNavProps {
  currentTab: MainNavTab;
  onTabSelect: (tab: MainNavTab) => void;
}

export const MobileBottomNav: React.FC<MobileBottomNavProps> = ({ currentTab, onTabSelect }) => {
  const tabs = [
    { id: 'dashboard' as MainNavTab, title: 'Dashboard', icon: <LayoutDashboard className="w-5 h-5" /> },
    { id: 'deliveries' as MainNavTab, title: 'Deliveries', icon: <Truck className="w-5 h-5" /> },
    { id: 'customers' as MainNavTab, title: 'Customers', icon: <Users className="w-5 h-5" /> },
    { id: 'expenses' as MainNavTab, title: 'Expenses', icon: <Receipt className="w-5 h-5" /> },
    { id: 'stock' as MainNavTab, title: 'Stock & Cost', icon: <Boxes className="w-5 h-5" /> },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-white border-t border-[#E2E8F0] shadow-lg select-none">
      <div className="max-w-2xl mx-auto flex items-center justify-around h-14 px-1">
        {tabs.map(tab => {
          const isSelected = currentTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => onTabSelect(tab.id)}
              className="flex-1 flex flex-col items-center justify-center h-full transition-all group"
            >
              <div className={`px-4 py-1 rounded-full transition-colors ${
                isSelected ? 'bg-[#028090]/20 text-[#0A2540]' : 'text-[#475569] group-hover:text-[#0A2540]'
              }`}>
                {tab.icon}
              </div>
              <span className={`text-[10px] font-bold mt-0.5 truncate max-w-[64px] ${
                isSelected ? 'text-[#0A2540]' : 'text-[#475569]'
              }`}>
                {tab.title}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
