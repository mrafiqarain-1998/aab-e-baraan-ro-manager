import React, { useState, useRef } from 'react';
import { useWaterApp } from '../../context/WaterAppContext';
import { 
  Database, 
  Download, 
  Upload, 
  RefreshCw, 
  Save, 
  Settings,
  CheckCircle2,
  FileUp,
  FileJson
} from 'lucide-react';

export const BackupView: React.FC = () => {
  const { 
    exportBackupJson, 
    importBackupJson, 
    resetToDemoData, 
    businessProfile, 
    updateBusinessProfile
  } = useWaterApp();

  const [importText, setImportText] = useState('');
  const [profileForm, setProfileForm] = useState({ ...businessProfile });
  const [isSavedNotice, setIsSavedNotice] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDownloadBackup = () => {
    const jsonStr = exportBackupJson();
    const blob = new Blob([jsonStr], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `aab_e_baraan_backup_${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      if (content) {
        setImportText(content);
        if (window.confirm(`Restore database from file "${file.name}"? This will update plant records.`)) {
          const ok = importBackupJson(content);
          if (ok) {
            alert(`Database restored successfully from "${file.name}"!`);
            setImportText('');
          } else {
            alert("Invalid JSON format in the selected file. Please verify your backup file.");
          }
        }
      }
    };
    reader.readAsText(file);
    // Reset input so same file can be selected again if needed
    e.target.value = '';
  };

  const handleRestoreSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!importText.trim()) return;
    const ok = importBackupJson(importText);
    if (ok) {
      alert("Database restored successfully from backup JSON!");
      setImportText('');
    } else {
      alert("Invalid JSON format. Please verify your backup file.");
    }
  };

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    updateBusinessProfile(profileForm);
    setIsSavedNotice(true);
    setTimeout(() => setIsSavedNotice(false), 3000);
  };

  return (
    <div className="space-y-3.5 pb-24 text-xs">
      
      {/* 1. Header Card */}
      <div className="bg-white border border-[#CBD5E1]/70 rounded-2xl p-4 shadow-xs space-y-1">
        <h2 className="text-sm font-bold text-[#0A2540]">
          Backup, Restore & Settings (بیک اپ اور بحالی)
        </h2>
        <p className="text-[11px] text-[#475569] font-urdu">
          پلانٹ ڈیٹا کا مکمل بیک اپ، بحالی اور پروفائل ترتیبات
        </p>
      </div>

      {/* 2. Export & Restore Cards */}
      <div className="space-y-3">
        {/* Export Card */}
        <div className="bg-white border border-[#CBD5E1]/70 rounded-2xl p-4 shadow-xs space-y-2.5">
          <h3 className="font-bold text-xs text-[#0A2540] flex items-center gap-1.5">
            <Download className="w-4 h-4 text-[#00A896]" />
            <span>Export Full Backup JSON (بیک اپ فائل ڈاؤن لوڈ)</span>
          </h3>
          <p className="text-[11px] text-slate-500">
            Download complete records (customers, ledgers, deliveries, stock, expenses) to a single file.
          </p>

          <button
            onClick={handleDownloadBackup}
            className="w-full py-2.5 rounded-xl bg-[#0A2540] text-white font-bold flex items-center justify-center gap-2 shadow-xs active:scale-95 transition-all"
          >
            <Download className="w-4 h-4" />
            <span>Download Backup File</span>
          </button>
        </div>

        {/* Restore Card */}
        <div className="bg-white border border-[#CBD5E1]/70 rounded-2xl p-4 shadow-xs space-y-3">
          <h3 className="font-bold text-xs text-[#0A2540] flex items-center gap-1.5">
            <Upload className="w-4 h-4 text-[#10B981]" />
            <span>Restore From Backup JSON (بیک اپ سے ڈیٹا بحال کریں)</span>
          </h3>

          {/* Hidden File Input */}
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileUpload}
            accept=".json,application/json"
            className="hidden"
          />

          {/* Direct File Upload Button */}
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="w-full py-2.5 px-3 rounded-xl bg-[#0F3B66] hover:bg-[#0A2540] text-white font-bold flex items-center justify-center gap-2 shadow-xs active:scale-95 transition-all"
          >
            <FileUp className="w-4 h-4 text-[#00A896]" />
            <span>Upload Backup File (.json) (فائل منتخب کریں اور بحال کریں)</span>
          </button>

          <div className="flex items-center gap-2 my-1">
            <div className="h-px bg-slate-200 flex-1" />
            <span className="text-[10px] text-slate-400 font-semibold uppercase">Or paste JSON</span>
            <div className="h-px bg-slate-200 flex-1" />
          </div>

          <form onSubmit={handleRestoreSubmit} className="space-y-2">
            <textarea
              rows={3}
              value={importText}
              onChange={e => setImportText(e.target.value)}
              placeholder="Paste exported backup JSON here..."
              className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl p-2.5 text-[11px] font-mono text-[#0F172A] focus:outline-none focus:border-[#0A2540]"
            />

            <button
              type="submit"
              className="w-full py-2.5 rounded-xl bg-[#10B981] hover:bg-[#059669] text-white font-bold"
            >
              Restore Database from Text
            </button>
          </form>
        </div>

        {/* Reset Demo Data */}
        <div className="bg-white border border-[#CBD5E1]/70 rounded-2xl p-4 shadow-xs space-y-2">
          <h3 className="font-bold text-xs text-[#0A2540] flex items-center gap-1.5">
            <RefreshCw className="w-4 h-4 text-[#F59E0B]" />
            <span>Reset To Default Demo Data (سیمپل ڈیٹا بحال کریں)</span>
          </h3>
          <p className="text-[11px] text-slate-500">
            Loads clean verified sample customers, routes, and stock for testing.
          </p>

          <button
            onClick={() => {
              if (window.confirm("Reload demo dataset?")) {
                resetToDemoData();
                alert("Demo data reloaded!");
              }
            }}
            className="w-full py-2 rounded-xl bg-[#FEF3C7] text-[#92400E] font-bold border border-[#F59E0B]/30"
          >
            Reload Sample Records
          </button>
        </div>

        {/* Business Profile Settings */}
        <div className="bg-white border border-[#CBD5E1]/70 rounded-2xl p-4 shadow-xs space-y-3">
          <div className="flex items-center justify-between border-b pb-2">
            <h3 className="font-bold text-xs text-[#0A2540]">Plant Profile Settings</h3>
            {isSavedNotice && (
              <span className="text-[10px] font-bold text-[#10B981]">Saved!</span>
            )}
          </div>

          <form onSubmit={handleSaveProfile} className="space-y-2.5 text-xs">
            <div>
              <label className="block text-[11px] font-semibold text-slate-600 mb-1">Business Name</label>
              <input
                type="text"
                value={profileForm.businessName}
                onChange={e => setProfileForm({ ...profileForm, businessName: e.target.value })}
                className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-3 py-2 font-bold text-[#0A2540]"
              />
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-slate-600 mb-1">Urdu Name (اردو نام)</label>
              <input
                type="text"
                value={profileForm.urduBusinessName}
                onChange={e => setProfileForm({ ...profileForm, urduBusinessName: e.target.value })}
                className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-3 py-2 font-urdu font-bold text-[#00A896]"
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">Phone</label>
                <input
                  type="text"
                  value={profileForm.phone}
                  onChange={e => setProfileForm({ ...profileForm, phone: e.target.value })}
                  className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-3 py-2"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">WhatsApp</label>
                <input
                  type="text"
                  value={profileForm.whatsapp}
                  onChange={e => setProfileForm({ ...profileForm, whatsapp: e.target.value })}
                  className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-3 py-2"
                />
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-slate-600 mb-1">Address</label>
              <input
                type="text"
                value={profileForm.address}
                onChange={e => setProfileForm({ ...profileForm, address: e.target.value })}
                className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-3 py-2"
              />
            </div>

            <button
              type="submit"
              className="w-full py-2.5 rounded-xl bg-[#0A2540] text-white font-bold flex items-center justify-center gap-1.5"
            >
              <Save className="w-4 h-4" />
              <span>Save Settings</span>
            </button>
          </form>
        </div>
      </div>

    </div>
  );
};
