import React, { useState, useEffect } from 'react';
import { useWaterApp } from '../../context/WaterAppContext';
import { 
  Search, 
  CheckCircle2, 
  User, 
  DollarSign, 
  Wallet, 
  CreditCard, 
  Printer, 
  ArrowLeft,
  X,
  Phone,
  MapPin,
  Clock,
  Trash2,
  AlertTriangle,
  MessageCircle,
  Pencil
} from 'lucide-react';
import { Customer, PaymentMethod, Payment } from '../../types';
import { NumericInput } from '../common/NumericInput';

interface ReceivePaymentScreenProps {
  preSelectedCustomer?: Customer | null;
  onPaymentCompleted: () => void;
  onCancel: () => void;
}

export const ReceivePaymentScreen: React.FC<ReceivePaymentScreenProps> = ({
  preSelectedCustomer,
  onPaymentCompleted,
  onCancel
}) => {
  const { 
    customers, 
    invoices, 
    payments, 
    receivePayment, 
    updatePayment,
    deletePayment,
    currentUser,
    businessProfile 
  } = useWaterApp();

  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(preSelectedCustomer || null);
  const [customerSearchQuery, setCustomerSearchQuery] = useState('');
  const [showOnlyDueFilter, setShowOnlyDueFilter] = useState(true);

  const [paymentAmount, setPaymentAmount] = useState<number>(0);
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('CASH');
  const [transRef, setTransRef] = useState('');
  const [notes, setNotes] = useState('');

  // Payment receipt detail modal
  const [selectedReceipt, setSelectedReceipt] = useState<Payment | null>(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  // Edit Payment State (Requirement 10)
  const [editingPayment, setEditingPayment] = useState<Payment | null>(null);
  const [editAmount, setEditAmount] = useState<number>(0);
  const [editMethod, setEditMethod] = useState<PaymentMethod>('CASH');
  const [editRef, setEditRef] = useState('');
  const [editNotes, setEditNotes] = useState('');
  const [editDate, setEditDate] = useState('');

  // Unpaid invoices for customer
  const unpaidInvoices = selectedCustomer 
    ? invoices.filter(inv => inv.customerId === selectedCustomer.id && inv.status !== 'PAID')
    : [];

  // When customer changes, auto-populate amount with current debt
  useEffect(() => {
    if (selectedCustomer) {
      setPaymentAmount(selectedCustomer.currentBalance > 0 ? selectedCustomer.currentBalance : 0);
    }
  }, [selectedCustomer]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedCustomer) return;

    if (paymentAmount <= 0) {
      alert("Please enter a valid payment amount.");
      return;
    }

    const res = receivePayment({
      customerId: selectedCustomer.id,
      amount: paymentAmount,
      paymentMethod,
      transactionRef: transRef,
      notes
    });

    if (res.success) {
      alert(`Payment of Rs. ${paymentAmount} received successfully!`);
      onPaymentCompleted();
    }
  };

  const handleOpenEditPayment = (pay: Payment) => {
    setEditingPayment(pay);
    setEditAmount(pay.amount);
    setEditMethod(pay.paymentMethod);
    setEditRef(pay.transactionRef || '');
    setEditNotes(pay.notes || '');
    setEditDate(pay.date);
  };

  const handleSaveEditedPayment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingPayment) return;
    if (editAmount <= 0) {
      alert("Payment amount must be greater than 0");
      return;
    }

    const res = updatePayment(editingPayment.id, {
      amount: editAmount,
      paymentMethod: editMethod,
      transactionRef: editRef,
      notes: editNotes,
      date: editDate
    });

    if (res.success) {
      if (selectedReceipt && selectedReceipt.id === editingPayment.id) {
        setSelectedReceipt({
          ...selectedReceipt,
          amount: editAmount,
          paymentMethod: editMethod,
          transactionRef: editRef,
          notes: editNotes,
          date: editDate,
          lastEditedAt: Date.now(),
          lastEditedBy: currentUser.name
        });
      }
      setEditingPayment(null);
    } else {
      alert(res.error || "Failed to update payment");
    }
  };

  const handleDeletePayment = () => {
    if (!selectedReceipt) return;
    const res = deletePayment(selectedReceipt.id);
    if (res.success) {
      setShowDeleteConfirm(false);
      setSelectedReceipt(null);
    } else {
      alert(res.error || "Failed to delete payment.");
    }
  };

  const filteredCustomers = customers.filter(c => {
    const matchesSearch = 
      c.name.toLowerCase().includes(customerSearchQuery.toLowerCase()) ||
      c.phone.includes(customerSearchQuery) ||
      c.area.toLowerCase().includes(customerSearchQuery.toLowerCase());

    const matchesDue = !showOnlyDueFilter || c.currentBalance > 0;
    return matchesSearch && matchesDue;
  });

  const isAdmin = currentUser.role === 'ADMIN';

  return (
    <div className="space-y-3.5 pb-24 text-xs">
      
      {/* 1. CUSTOMER SELECTION / PENDING DUES LIST */}
      {selectedCustomer === null ? (
        <div className="bg-white border border-[#CBD5E1]/70 rounded-2xl p-4 shadow-xs space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-sm font-bold text-[#0A2540]">
                Receive Cash (پیمنٹ وصولی)
              </h2>
              <p className="text-[11px] text-[#475569] font-urdu">
                جس گاہک سے رقم وصول کرنی ہے اسے منتخب کریں
              </p>
            </div>

            <span className="px-2 py-0.5 rounded-full bg-[#FEE2E2] text-[#EF4444] font-bold text-[10px]">
              {customers.filter(c => c.currentBalance > 0).length} Pending Dues
            </span>
          </div>

          {/* Customer Search Bar */}
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search name, phone, area (گاہک تلاش کریں)..."
              value={customerSearchQuery}
              onChange={e => setCustomerSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-2 bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl text-xs text-[#0F172A] focus:outline-none focus:border-[#0A2540]"
            />
          </div>

          {/* Dues filter toggle */}
          <div className="flex items-center justify-between pt-1">
            <button
              onClick={() => setShowOnlyDueFilter(!showOnlyDueFilter)}
              className={`px-3 py-1 rounded-full text-[11px] font-bold transition-all ${
                showOnlyDueFilter
                  ? 'bg-[#0A2540] text-white shadow-xs'
                  : 'bg-[#F0F7FB] text-slate-700'
              }`}
            >
              {showOnlyDueFilter ? 'Only Customers With Dues (بقایا جات)' : 'All Customers'}
            </button>
            <span className="text-[10px] text-slate-400">
              {filteredCustomers.length} customers listed
            </span>
          </div>

          {/* Customer Selection List */}
          <div className="space-y-2 max-h-96 overflow-y-auto pt-1">
            {filteredCustomers.length === 0 ? (
              <p className="text-center text-slate-400 py-6">No matching customers found.</p>
            ) : (
              filteredCustomers.map(c => (
                <div
                  key={c.id}
                  onClick={() => setSelectedCustomer(c)}
                  className="p-3 rounded-xl bg-[#F0F7FB] hover:bg-[#E8F4F8] border border-[#CBD5E1]/60 flex items-center justify-between cursor-pointer transition-colors"
                >
                  <div>
                    <p className="font-bold text-xs text-[#0A2540]">{c.name}</p>
                    <p className="text-[10px] text-slate-500">{c.phone.replace(/[^0-9+]/g, '')} • {c.area}</p>
                  </div>
                  <div className="text-right">
                    <span className="text-xs font-black text-[#EF4444] block">
                      Rs. {c.currentBalance.toLocaleString()}
                    </span>
                    <span className="text-[10px] text-[#00A896] font-bold">Select →</span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      ) : (
        /* 2. PAYMENT RECORDING FORM FOR SELECTED CUSTOMER */
        <div className="space-y-3">
          {/* Customer Header Info */}
          <div className="bg-[#0A2540] text-white p-4 rounded-2xl flex items-center justify-between">
            <div>
              <p className="text-[10px] text-[#00A896] font-bold uppercase tracking-wider">Receiving Payment From:</p>
              <h3 className="font-bold text-sm">{selectedCustomer.name}</h3>
              <p className="text-[11px] text-slate-300">{selectedCustomer.phone} • {selectedCustomer.area}</p>
            </div>

            <div className="text-right">
              <span className="text-[10px] text-slate-300 block">Total Due (بقایا):</span>
              <span className="text-base font-black text-[#F87171]">
                Rs. {selectedCustomer.currentBalance.toLocaleString()}
              </span>
              <button
                onClick={() => setSelectedCustomer(null)}
                className="text-[10px] text-white/80 hover:text-white underline block mt-0.5"
              >
                Change Customer
              </button>
            </div>
          </div>

          {/* Unpaid Invoices List */}
          {unpaidInvoices.length > 0 && (
            <div className="bg-white border border-[#CBD5E1]/70 rounded-2xl p-3.5 shadow-xs space-y-1.5">
              <span className="font-bold text-[11px] text-[#0A2540] block">
                Unpaid Invoices Breakdown (بقایا بل جات):
              </span>
              {unpaidInvoices.map(inv => (
                <div key={inv.id} className="p-2 rounded-lg bg-[#F0F7FB] flex justify-between text-[11px]">
                  <span>{inv.invoiceNumber} ({inv.date}) - {inv.itemsSummary}</span>
                  <strong className="text-[#D97706]">Rs. {inv.balanceDue}</strong>
                </div>
              ))}
            </div>
          )}

          {/* Payment Form */}
          <form onSubmit={handleSubmit} className="bg-white border border-[#CBD5E1]/70 rounded-2xl p-4 shadow-xs space-y-3">
            <div>
              <label className="block text-xs font-bold text-[#0A2540] mb-1">
                Payment Amount (وصول شدہ رقم)*
              </label>
              <NumericInput
                value={paymentAmount}
                onChange={val => setPaymentAmount(val)}
                placeholder="0"
                className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-3 py-2 text-base font-black text-[#10B981] focus:outline-none focus:border-[#0A2540]"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-[#0A2540] mb-1">
                Payment Method (ادائیگی کا طریقہ)
              </label>
              <div className="grid grid-cols-4 gap-1.5">
                {(['CASH', 'JAZZCASH', 'EASYPAISA', 'BANK_TRANSFER'] as PaymentMethod[]).map(m => (
                  <button
                    key={m}
                    type="button"
                    onClick={() => setPaymentMethod(m)}
                    className={`py-2 px-1 rounded-xl font-bold text-center text-[10px] transition-all ${
                      paymentMethod === m
                        ? 'bg-[#0A2540] text-white shadow-xs'
                        : 'bg-[#F0F7FB] text-slate-700 hover:bg-[#E8F4F8]'
                    }`}
                  >
                    {m === 'CASH' ? 'Cash (نقد)' : m === 'JAZZCASH' ? 'JazzCash' : m === 'EASYPAISA' ? 'Easypaisa' : 'Bank'}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                Transaction Reference / Slip #
              </label>
              <input
                type="text"
                value={transRef}
                onChange={e => setTransRef(e.target.value)}
                placeholder="e.g. TID-982189 / Cheque 102"
                className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-3 py-2 text-xs text-[#0F172A]"
              />
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                Receipt Notes
              </label>
              <input
                type="text"
                value={notes}
                onChange={e => setNotes(e.target.value)}
                placeholder="e.g. Paid in full"
                className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-3 py-2 text-xs text-[#0F172A]"
              />
            </div>

            <div className="flex items-center gap-2 pt-2">
              <button
                type="button"
                onClick={onCancel}
                className="flex-1 py-3 rounded-xl bg-slate-200 text-slate-700 font-bold"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="flex-2 py-3 rounded-xl bg-[#10B981] hover:bg-[#059669] text-white font-bold flex items-center justify-center gap-2 shadow-md"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>Save Payment & Receipt</span>
              </button>
            </div>
          </form>

        </div>
      )}

      {/* Past Payments List */}
      <div className="space-y-2">
        <h3 className="font-bold text-xs text-[#0A2540] uppercase tracking-wider">
          Recent Payment Receipts
        </h3>

        <div className="space-y-1.5">
          {payments.length === 0 ? (
            <p className="text-slate-400 text-center py-4 bg-white rounded-xl border border-slate-200">
              No payments recorded yet.
            </p>
          ) : (
            payments.slice(0, 10).map(p => (
              <div
                key={p.id}
                onClick={() => setSelectedReceipt(p)}
                className="bg-white border border-[#CBD5E1]/70 rounded-xl p-3 flex items-center justify-between text-xs cursor-pointer hover:border-[#0A2540]/40 transition-colors"
              >
                <div>
                  <p className="font-bold text-[#0A2540]">{p.customerName}</p>
                  <p className="text-[10px] text-slate-500">{p.receiptNumber} • {p.date} • {p.paymentMethod}</p>
                </div>

                <div className="text-right">
                  <span className="font-black text-[#10B981] text-xs block">
                    Rs. {p.amount.toLocaleString()}
                  </span>
                  <span className="text-[10px] text-[#028090]">View Receipt →</span>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* PAYMENT RECEIPT MODAL */}
      {selectedReceipt && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl w-full max-w-sm p-5 shadow-2xl space-y-3 font-sans text-xs">
            
            {/* Official Logo on Payment Receipt */}
            <div className="text-center pt-1 pb-2 border-b border-slate-100">
              <img 
                src="/aab_e_baraan_logo.png" 
                alt="Aab-e-Baraan" 
                className="h-16 mx-auto object-contain mb-1" 
              />
              <h3 className="text-sm font-bold text-[#0A2540]">{businessProfile.businessName}</h3>
              <p className="text-[11px] text-[#00A896] font-urdu font-bold">آفیشل کیش وصولی رسید</p>
            </div>

            <div className="flex items-center justify-between pb-1">
              <div>
                <span className="text-[10px] text-slate-400 font-mono">Receipt #: {selectedReceipt.receiptNumber}</span>
              </div>
              <button 
                onClick={() => {
                  setSelectedReceipt(null);
                  setShowDeleteConfirm(false);
                }}
                className="p-1 rounded-full bg-slate-100 text-slate-500 hover:bg-slate-200"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-3 rounded-2xl bg-[#F0F7FB] border border-[#CBD5E1]/60 space-y-1.5 text-xs">
              <div className="flex justify-between">
                <span className="text-slate-500">Customer:</span>
                <strong className="text-[#0A2540]">{selectedReceipt.customerName}</strong>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Amount Received:</span>
                <strong className="text-base font-black text-[#10B981]">Rs. {selectedReceipt.amount.toLocaleString()}</strong>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Method:</span>
                <span className="font-semibold">{selectedReceipt.paymentMethod}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Date:</span>
                <span>{selectedReceipt.date}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Received By:</span>
                <span>{selectedReceipt.receivedBy} ({selectedReceipt.receivedByRole})</span>
              </div>
              {selectedReceipt.transactionRef && (
                <div className="flex justify-between">
                  <span className="text-slate-500">Reference:</span>
                  <span className="font-mono">{selectedReceipt.transactionRef}</span>
                </div>
              )}
            </div>

            <div className="flex items-center justify-between gap-2 pt-1">
              {isAdmin && (
                <button
                  onClick={() => handleOpenEditPayment(selectedReceipt)}
                  className="py-2 px-3 rounded-xl bg-[#0A2540] hover:bg-[#028090] text-white font-bold text-xs flex items-center gap-1 shadow-xs transition-colors"
                  title="Edit Payment (صرف ایڈمن)"
                >
                  <Pencil className="w-3 h-3" />
                  <span>Edit Payment</span>
                </button>
              )}

              <button
                onClick={() => {
                  setSelectedReceipt(null);
                  setShowDeleteConfirm(false);
                }}
                className="py-2 px-5 rounded-xl bg-slate-200 text-slate-700 font-bold"
              >
                Close
              </button>
            </div>

            {/* ADMIN ONLY DELETE PAYMENT */}
            {isAdmin && (
              <div className="pt-2 border-t border-red-100">
                {!showDeleteConfirm ? (
                  <button
                    onClick={() => setShowDeleteConfirm(true)}
                    className="w-full py-2 px-3 rounded-xl bg-red-50 hover:bg-red-100 text-red-700 font-bold text-xs flex items-center justify-center gap-2 border border-red-200"
                  >
                    <Trash2 className="w-3.5 h-3.5 text-red-600" />
                    <span>Delete Payment Receipt (صرف ایڈمن)</span>
                  </button>
                ) : (
                  <div className="p-3 rounded-2xl bg-red-50 border border-red-300 space-y-2 text-center animate-in fade-in">
                    <AlertTriangle className="w-6 h-6 text-red-600 mx-auto" />
                    <p className="font-bold text-red-800 text-xs">
                      Delete Payment {selectedReceipt.receiptNumber}?
                    </p>
                    <p className="text-[11px] text-red-700">
                      Amount: Rs. {selectedReceipt.amount}. Customer debt will be restored!
                    </p>
                    <div className="flex items-center gap-2 pt-1">
                      <button
                        onClick={() => setShowDeleteConfirm(false)}
                        className="flex-1 py-1.5 rounded-xl bg-slate-200 text-slate-700 font-bold text-[11px]"
                      >
                        Cancel
                      </button>
                      <button
                        onClick={handleDeletePayment}
                        className="flex-1 py-1.5 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold text-[11px]"
                      >
                        Yes, Delete
                      </button>
                    </div>
                  </div>
                )}
              </div>
            )}

          </div>
        </div>
      )}

      {/* REQUIREMENT 10: ADMIN EDIT PAYMENT MODAL */}
      {editingPayment && (
        <div className="fixed inset-0 z-60 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl w-full max-w-md p-5 shadow-2xl space-y-3.5 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b pb-2">
              <div>
                <h3 className="font-bold text-sm text-[#0A2540]">Edit Payment Record (صرف ایڈمن)</h3>
                <p className="text-[10px] text-slate-500">{editingPayment.receiptNumber} • {editingPayment.customerName}</p>
              </div>
              <button 
                onClick={() => setEditingPayment(null)}
                className="p-1 rounded-full bg-slate-100 text-slate-500 hover:bg-slate-200"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveEditedPayment} className="space-y-3">
              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">Payment Date</label>
                <input
                  type="date"
                  value={editDate}
                  onChange={e => setEditDate(e.target.value)}
                  className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-3 py-2 text-xs font-semibold text-[#0A2540]"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  Payment Amount (وصول شدہ رقم) *
                </label>
                <NumericInput
                  value={editAmount}
                  onChange={val => setEditAmount(val)}
                  placeholder="0"
                  className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-3 py-2 text-base font-black text-emerald-700"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">Payment Method</label>
                <select
                  value={editMethod}
                  onChange={e => setEditMethod(e.target.value as PaymentMethod)}
                  className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-2.5 py-2 text-xs font-semibold"
                >
                  <option value="CASH">Cash (نقد)</option>
                  <option value="JAZZCASH">JazzCash</option>
                  <option value="EASYPAISA">Easypaisa</option>
                  <option value="BANK_TRANSFER">Bank Transfer</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  Transaction Reference
                </label>
                <input
                  type="text"
                  value={editRef}
                  onChange={e => setEditRef(e.target.value)}
                  placeholder="e.g. TID / Bank receipt #"
                  className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-3 py-2 text-xs text-[#0F172A]"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">Notes</label>
                <input
                  type="text"
                  value={editNotes}
                  onChange={e => setEditNotes(e.target.value)}
                  className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-3 py-2 text-xs"
                />
              </div>

              <div className="p-2.5 rounded-xl bg-amber-50 border border-amber-200 text-[10px] text-amber-900 leading-relaxed">
                Saving will automatically adjust the customer outstanding balance and update the financial ledger.
              </div>

              <div className="flex items-center gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setEditingPayment(null)}
                  className="flex-1 py-2.5 rounded-xl bg-slate-200 text-slate-700 font-bold text-xs"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-[#0A2540] hover:bg-[#028090] text-white font-bold text-xs shadow-xs transition-colors"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
