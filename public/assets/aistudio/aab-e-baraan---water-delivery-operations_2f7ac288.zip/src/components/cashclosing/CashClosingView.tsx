import React, { useState } from 'react';
import { useWaterApp } from '../../context/WaterAppContext';
import { 
  Lock, 
  PlusCircle, 
  MinusCircle, 
  CheckCircle2, 
  AlertTriangle, 
  Info, 
  Verified, 
  Calendar,
  Clock
} from 'lucide-react';

interface CashClosingViewProps {
  onClosingSubmitted?: () => void;
}

export const CashClosingView: React.FC<CashClosingViewProps> = ({ onClosingSubmitted }) => {
  const { 
    cashClosings, 
    recordCashClosing, 
    payments, 
    expenses, 
    currentUser 
  } = useWaterApp();

  const todayStr = new Date().toISOString().split('T')[0];

  // Daily cash collections from payments/deliveries (Cash or Pay from Sale)
  const todayCashCollected = payments
    .filter(p => p.date === todayStr && (p.paymentMethod === 'CASH' || (p as any).paymentMethod === 'PAY_FROM_SALE'))
    .reduce((sum, p) => sum + p.amount, 0);

  // Daily cash expenses (Only deduct if funding source is PAY_FROM_SALE and payment method is CASH)
  // Non-cash (Bank, JazzCash) or Investment expenses do not reduce the physical cash drawer.
  const todayCashExpenses = expenses
    .filter(e => {
      if (e.date !== todayStr) return false;
      const isFromSale = e.paymentSource === 'PAY_FROM_SALE' || (!e.paymentSource && (e.paymentMethod as any) !== 'INVESTMENT');
      const isCash = e.paymentMethod === 'CASH' || (e.paymentMethod as any) === 'PAY_FROM_SALE';
      return isFromSale && isCash;
    })
    .reduce((sum, e) => sum + e.amount, 0);

  const openingCash = 0.0;
  const expectedClosing = openingCash + todayCashCollected - todayCashExpenses;

  const [actualCashText, setActualCashText] = useState('');
  const [notes, setNotes] = useState('');

  const actualCash = parseFloat(actualCashText) || 0;
  const hasEnteredActual = actualCashText.trim().length > 0;
  const difference = actualCash - expectedClosing;
  const isBalanced = Math.abs(difference) < 0.01;
  const isShortage = difference < -0.01;
  const isSurplus = difference > 0.01;

  // Check if today already has a recorded closing
  const existingTodayClosing = cashClosings.find(c => c.date === todayStr);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!hasEnteredActual) return;

    recordCashClosing({
      openingCash,
      customerCashCollected: todayCashCollected,
      otherCashIncome: 0,
      cashExpenses: todayCashExpenses,
      actualClosingCash: actualCash,
      notes
    });

    if (existingTodayClosing) {
      alert("Today's cash closing updated successfully. Only this latest closing is considered in the system!\n(آج کی آخری کیش کلوزنگ کامیابی سے اپڈیٹ ہوگئی۔ صرف یہ آخری کلوزنگ ہی ریکارڈ میں شمار ہوگی)");
    } else {
      alert("Cash closing submitted and recorded for today!\n(آج کی کیش کلوزنگ کامیابی سے محفوظ ہوگئی)");
    }

    if (onClosingSubmitted) {
      onClosingSubmitted();
    }
  };

  return (
    <div className="space-y-3.5 pb-20">
      
      {/* 1. Header Card with Formula Explanation */}
      <div className="rounded-2xl bg-[#0A2540] text-white p-4 sm:p-5 shadow-md">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 bg-white/95 rounded-xl p-1 shadow-sm flex items-center justify-center shrink-0">
              <img 
                src="/aab_e_baraan_logo.png" 
                alt="Aab-e-Baraan Logo" 
                className="w-full h-full object-contain" 
              />
            </div>
            <div>
              <h2 className="text-sm sm:text-base font-bold tracking-tight">
                Daily Cash Closing Drawer
              </h2>
              <p className="text-[11px] text-[#00A896] font-urdu font-medium mt-0.5">
                روزانہ کیش گنتی اور حساب بندش
              </p>
            </div>
          </div>

          <div className="px-2.5 py-1 rounded-lg bg-[#0F3B66] text-[#E8F4F8] text-xs font-semibold">
            {todayStr}
          </div>
        </div>

        <p className="text-xs text-[#E8F4F8]/80 mt-3 pt-2 border-t border-[#0F3B66]">
          Formula: Expected = Opening (Rs. 0) + Cash Collected - Cash Expenses (Pay from Sale). Owner Investment is not deducted.
        </p>
      </div>

      {/* Notice if already closed today */}
      {existingTodayClosing && (
        <div className="rounded-xl bg-amber-50 border border-amber-300 p-3.5 flex items-start gap-3 shadow-xs">
          <div className="p-1 rounded-lg bg-amber-200/80 text-amber-900 shrink-0">
            <Lock className="w-4 h-4" />
          </div>
          <div className="text-xs text-amber-950 space-y-0.5">
            <p className="font-bold">
              Today's Closing Already Recorded (آج کی کلوزنگ پہلے سے محفوظ ہے)
            </p>
            <p className="text-[11px] text-amber-900 leading-relaxed">
              Previously closed at Rs. {existingTodayClosing.actualClosingCash.toLocaleString()} by {existingTodayClosing.closedBy}.
              If further transactions took place and you submit again, this latest closing will automatically overwrite and update today's final record.
            </p>
          </div>
        </div>
      )}

      {/* 2. The Cash Breakdown Ledger Card */}
      <div className="rounded-2xl bg-white border border-[#CBD5E1]/70 p-4 sm:p-5 shadow-sm space-y-3">
        <h3 className="text-sm font-bold text-[#0A2540]">
          Cash Calculation (حساب کی تفصیل)
        </h3>

        <div className="space-y-2.5 text-xs">
          
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-[#0F172A]">
              <Lock className="w-4 h-4 text-[#0A2540]" />
              <span>Opening Drawer Cash (صبح کا کیش)</span>
            </div>
            <span className="font-bold text-[#0A2540]">
              Rs. {openingCash.toLocaleString()}
            </span>
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-[#0F172A]">
              <PlusCircle className="w-4 h-4 text-[#10B981]" />
              <span>+ Cash Collections (گاہکوں سے نقد)</span>
            </div>
            <span className="font-bold text-[#10B981]">
              + Rs. {todayCashCollected.toLocaleString()}
            </span>
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-[#0F172A]">
              <MinusCircle className="w-4 h-4 text-[#EF4444]" />
              <span>- Cash Expenses (روزمرہ نقد خرچ)</span>
            </div>
            <span className="font-bold text-[#EF4444]">
              - Rs. {todayCashExpenses.toLocaleString()}
            </span>
          </div>

          <div className="pt-2 border-t border-[#E2E8F0] flex items-center justify-between">
            <div>
              <p className="text-xs font-bold text-[#0A2540]">Expected Drawer Cash</p>
              <p className="text-[11px] text-[#475569] font-urdu">حساب کے مطابق کیش ہونا چاہیے</p>
            </div>
            <span className="text-base sm:text-lg font-bold text-[#0A2540]">
              Rs. {expectedClosing.toLocaleString()}
            </span>
          </div>

        </div>
      </div>

      {/* 3. Counted Cash Entry & Difference Indicator */}
      <div className="rounded-2xl bg-white border border-[#CBD5E1]/70 p-4 sm:p-5 shadow-sm space-y-3.5">
        <h3 className="text-sm font-bold text-[#0A2540]">
          Physical Cash Count (گن کر لکھا گیا کیش)
        </h3>

        <form onSubmit={handleSubmit} className="space-y-3">

          {existingTodayClosing && (
            <div className="p-3 rounded-2xl bg-amber-50 border border-amber-300 flex items-start gap-2.5 text-xs">
              <Info className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
              <div>
                <p className="font-bold text-[#0A2540]">
                  Notice: Closing already recorded for today (محفوظ شدہ کیش: Rs. {existingTodayClosing.actualClosingCash.toLocaleString()})
                </p>
                <p className="text-[11px] text-amber-900 font-urdu mt-0.5">
                  اگر دن میں مزید ٹرانزیکشن ہوئی ہیں اور آپ دوبارہ کلوزنگ کریں گے تو صرف یہ آخری کلوزنگ ہی معتبر اور شمار ہوگی۔
                </p>
              </div>
            </div>
          )}
          
          {/* Actual Cash Input */}
          <div>
            <label className="block text-xs font-semibold text-[#0F172A] mb-1">
              Actual Cash in Hand (دراز میں موجود کل رقم)*
            </label>
            <div className="relative">
              <input
                type="number"
                step="any"
                required
                placeholder="Enter physical notes counted"
                value={actualCashText}
                onChange={e => setActualCashText(e.target.value)}
                className="w-full bg-white border border-[#CBD5E1] rounded-xl px-3 py-2.5 text-sm text-[#0F172A] focus:outline-none focus:border-[#0A2540] pr-28"
              />
              <button
                type="button"
                onClick={() => setActualCashText(expectedClosing.toString())}
                className="absolute right-2 top-2 px-2 py-1 rounded-lg bg-[#E8F4F8] hover:bg-[#d8edf4] text-[#028090] text-[11px] font-bold"
              >
                Matches Expected
              </button>
            </div>
          </div>

          {/* Difference Banner */}
          {hasEnteredActual && (
            <div className={`p-3 rounded-xl border flex items-center justify-between text-xs ${
              isBalanced 
                ? 'bg-[#D1FAE5] border-[#10B981]/40 text-[#065F46]'
                : isShortage
                ? 'bg-[#FEE2E2] border-[#EF4444]/40 text-[#991B1B]'
                : 'bg-[#FEF3C7] border-[#F59E0B]/40 text-[#92400E]'
            }`}>
              <div className="flex items-center gap-2.5">
                {isBalanced && <CheckCircle2 className="w-5 h-5 text-[#10B981] shrink-0" />}
                {isShortage && <AlertTriangle className="w-5 h-5 text-[#EF4444] shrink-0" />}
                {isSurplus && <Info className="w-5 h-5 text-[#F59E0B] shrink-0" />}

                <div>
                  <p className="font-bold text-xs">
                    {isBalanced && "Balanced! Cash drawer matches 100%"}
                    {isShortage && "Shortage (کیش میں کمی ہے!)"}
                    {isSurplus && "Surplus (کیش میں زیادتی ہے)"}
                  </p>
                  <p className="text-[11px] opacity-80 font-urdu">
                    {isBalanced && "حساب بالکل برابر ہے"}
                    {isShortage && "Check if any expense or refund was unrecorded"}
                    {isSurplus && "Check if any payment was recorded incorrectly"}
                  </p>
                </div>
              </div>

              <span className="text-sm font-bold whitespace-nowrap">
                {isBalanced ? "Rs. 0" : `Rs. ${Math.round(difference)}`}
              </span>
            </div>
          )}

          {/* Closing Notes */}
          <div>
            <label className="block text-xs font-semibold text-[#0F172A] mb-1">
              Closing Notes / Reason for Difference (نوٹس)
            </label>
            <input
              type="text"
              value={notes}
              onChange={e => setNotes(e.target.value)}
              placeholder="e.g. Shift 1 closed smoothly / shortage adjusted"
              className="w-full bg-white border border-[#CBD5E1] rounded-xl px-3 py-2 text-xs text-[#0F172A] focus:outline-none focus:border-[#0A2540]"
            />
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            disabled={!hasEnteredActual}
            className={`w-full py-3 rounded-xl font-bold text-sm flex items-center justify-center gap-2 transition-all ${
              hasEnteredActual
                ? 'bg-[#0A2540] hover:bg-[#07192C] text-white shadow-md active:scale-[0.99]'
                : 'bg-slate-300 text-slate-500 cursor-not-allowed'
            }`}
          >
            <Verified className="w-4 h-4 text-white" />
            <span>
              {existingTodayClosing 
                ? "Update Today's Closing (آخری کلوزنگ اپڈیٹ کریں)" 
                : "Submit Cash Closing & Lock Day"}
            </span>
          </button>

        </form>
      </div>

      {/* 4. Past Closing Records */}
      <div className="space-y-2.5">
        <div className="flex items-center justify-between px-1">
          <div>
            <h3 className="text-xs font-bold text-[#0A2540] uppercase tracking-wider">
              Past Closing Records
            </h3>
            <p className="text-[11px] text-[#475569] font-urdu">گزشتہ دنوں کی بندش</p>
          </div>
          <span className="text-[11px] text-slate-500 font-semibold">{cashClosings.length} Total</span>
        </div>

        <div className="space-y-2">
          {cashClosings.map(c => (
            <div
              key={c.id}
              className="bg-white border border-[#CBD5E1]/70 rounded-xl p-3 shadow-xs flex items-center justify-between text-xs"
            >
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-bold text-[#0A2540]">{c.date}</span>
                  <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                    c.difference === 0 
                      ? 'bg-[#D1FAE5] text-[#065F46]'
                      : c.difference < 0 
                      ? 'bg-[#FEE2E2] text-[#991B1B]'
                      : 'bg-[#FEF3C7] text-[#92400E]'
                  }`}>
                    {c.difference === 0 ? 'Balanced' : c.difference < 0 ? `Short Rs. ${Math.abs(c.difference)}` : `Surplus Rs. ${c.difference}`}
                  </span>
                </div>
                <p className="text-[11px] text-slate-500 mt-0.5">
                  Closed: <strong>Rs. {c.actualClosingCash.toLocaleString()}</strong> • By: {c.closedBy}
                </p>
                {c.notes && <p className="text-[10px] text-slate-400 italic mt-0.5">{c.notes}</p>}
              </div>

              <span className="text-xs font-bold text-[#0A2540]">
                Rs. {c.actualClosingCash.toLocaleString()}
              </span>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
};
