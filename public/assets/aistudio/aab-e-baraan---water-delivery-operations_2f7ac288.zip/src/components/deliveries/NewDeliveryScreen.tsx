import React, { useState, useEffect } from 'react';
import { useWaterApp } from '../../context/WaterAppContext';
import { 
  Calendar, 
  User, 
  MapPin, 
  Plus, 
  Trash2, 
  CheckCircle2, 
  AlertCircle,
  Truck,
  Droplet,
  Tag,
  X
} from 'lucide-react';
import { Customer, DeliveryItem, BottleSize } from '../../types';
import { NumericInput } from '../common/NumericInput';

interface NewDeliveryScreenProps {
  preSelectedCustomer?: Customer | null;
  onDeliverySaved: () => void;
  onCancel: () => void;
}

// Helper to format short clean bottle size labels (e.g. 19 L, 12.5 L, 6 L, 1.5 L, 500 ML)
export const formatShortBottleSizeName = (name: string): string => {
  if (!name) return '';
  const lower = name.toLowerCase();
  if (lower.includes('19') && (lower.includes('lit') || lower.includes('l'))) return '19 L';
  if (lower.includes('12.5') || lower.includes('12l')) return '12.5 L';
  if (lower.includes('6') && (lower.includes('lit') || lower.includes('l'))) return '6 L';
  if (lower.includes('1.5')) return '1.5 L';
  if (lower.includes('500') || lower.includes('500ml')) return '500 ML';
  return name.replace(/Bottle|Litre|Pack|Carton of \d+|\(|\)/gi, '').trim() || name;
};

export const NewDeliveryScreen: React.FC<NewDeliveryScreenProps> = ({
  preSelectedCustomer,
  onDeliverySaved,
  onCancel
}) => {
  const { 
    customers, 
    bottleSizes, 
    customerRates, 
    setCustomerPrice,
    createDelivery, 
    currentUser 
  } = useWaterApp();

  const todayStr = new Date().toISOString().split('T')[0];
  const [deliveryDate, setDeliveryDate] = useState(todayStr);

  const [selectedCustomerId, setSelectedCustomerId] = useState<string>(preSelectedCustomer?.id || '');
  const [items, setItems] = useState<DeliveryItem[]>([]);
  const [deliveryCharges, setDeliveryCharges] = useState(0);
  const [paymentCollected, setPaymentCollected] = useState<number>(0);
  const [paymentMethod, setPaymentMethod] = useState<string>('Cash');
  const [notes, setNotes] = useState('');

  // Missing Rate Modal State (Requirement 3)
  const [pendingRateModal, setPendingRateModal] = useState<{
    bottleSize: BottleSize;
    enteredRate: number;
  } | null>(null);

  const selectedCustomer = customers.find(c => c.id === selectedCustomerId);

  // Helper to get agreed rate for a bottle size for selected customer
  const getAgreedRate = (customerId: string, bottleSizeId: string): number => {
    if (!customerId) return 0;
    const customRate = customerRates.find(
      r => r.customerId === customerId && r.bottleSizeId === bottleSizeId && r.isAssigned
    );
    if (customRate && customRate.customPrice > 0) {
      return customRate.customPrice;
    }
    return 0; // Requirement 2.6: Initially 0 if undefined
  };

  // Update existing item rates when customer changes, but DO NOT auto-select 19L (user selects manually)
  useEffect(() => {
    if (selectedCustomerId && items.length > 0) {
      // Recalculate existing items for new customer
      setItems(prev => prev.map(item => {
        const rate = getAgreedRate(selectedCustomerId, item.bottleSizeId);
        return {
          ...item,
          unitPrice: rate,
          lineTotal: rate * item.quantity
        };
      }));
    }
  }, [selectedCustomerId]);

  const subtotal = items.reduce((sum, i) => sum + i.lineTotal, 0);
  const grandTotal = subtotal + deliveryCharges;

  // Auto-sync payment collected with grand total when grand total changes
  useEffect(() => {
    setPaymentCollected(grandTotal);
  }, [grandTotal]);

  // Requirement 5: Bottle Size Selection - prevent duplicate selections
  const handleSelectBottleSize = (size: BottleSize) => {
    if (!selectedCustomerId) {
      alert("Please select a customer first (پہلے گاہک منتخب کریں)");
      return;
    }

    // Check if already in items
    const existingIndex = items.findIndex(i => i.bottleSizeId === size.id);
    if (existingIndex >= 0) {
      // Requirement 5.3: If user needs more bottles of same size, increase quantity instead of duplicate
      setItems(prev => prev.map((item, idx) => {
        if (idx === existingIndex) {
          const newQty = item.quantity + 1;
          return {
            ...item,
            quantity: newQty,
            lineTotal: item.unitPrice * newQty
          };
        }
        return item;
      }));
      return;
    }

    // Check rate for this bottle size
    const rate = getAgreedRate(selectedCustomerId, size.id);
    if (rate <= 0) {
      // Prompt user to enter rate (Requirement 3.2)
      setPendingRateModal({
        bottleSize: size,
        enteredRate: size.defaultRefillPrice || 120
      });
      return;
    }

    // Add unique bottle item
    setItems(prev => [
      ...prev,
      {
        bottleSizeId: size.id,
        bottleName: size.name,
        quantity: 1,
        unitPrice: rate,
        emptyCollected: size.isReturnableBottle ? 1 : 0,
        lineTotal: rate
      }
    ]);
  };

  // Confirm and save rate from modal (Requirement 3.4)
  const handleConfirmRate = () => {
    if (!pendingRateModal || !selectedCustomerId) return;
    if (pendingRateModal.enteredRate <= 0) {
      alert("Rate must be greater than 0");
      return;
    }

    const { bottleSize, enteredRate } = pendingRateModal;
    // Save to customer custom rates for future deliveries
    setCustomerPrice(selectedCustomerId, bottleSize.id, enteredRate, deliveryDate);

    // If item already exists, update its unitPrice; otherwise add it
    setItems(prev => {
      const existingIdx = prev.findIndex(i => i.bottleSizeId === bottleSize.id);
      if (existingIdx >= 0) {
        return prev.map((item, idx) => idx === existingIdx ? {
          ...item,
          unitPrice: enteredRate,
          lineTotal: enteredRate * item.quantity
        } : item);
      } else {
        return [
          ...prev,
          {
            bottleSizeId: bottleSize.id,
            bottleName: bottleSize.name,
            quantity: 1,
            unitPrice: enteredRate,
            emptyCollected: bottleSize.isReturnableBottle ? 1 : 0,
            lineTotal: enteredRate
          }
        ];
      }
    });

    setPendingRateModal(null);
  };

  const handleUpdateItem = (index: number, qty: number, emptyCol: number) => {
    setItems(prev => prev.map((item, idx) => {
      if (idx === index) {
        const q = Math.max(0, qty);
        return {
          ...item,
          quantity: q,
          emptyCollected: Math.max(0, emptyCol),
          lineTotal: item.unitPrice * q
        };
      }
      return item;
    }));
  };

  const handleRemoveItem = (index: number) => {
    if (items.length > 1) {
      setItems(prev => prev.filter((_, idx) => idx !== index));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedCustomerId) {
      alert("Please select a customer.");
      return;
    }

    if (items.length === 0) {
      alert("Please add at least one bottle size for delivery.");
      return;
    }

    // Only deliver items with quantity > 0 (or empty bottles collected)
    const activeItems = items.filter(i => i.quantity > 0 || (i.emptyCollected && i.emptyCollected > 0));
    if (activeItems.length === 0) {
      alert("Please enter a quantity greater than 0 for at least one bottle size. (کم از کم ایک بوتل کی تعداد 1 یا زیادہ ہونی چاہیے)");
      return;
    }

    // Check if any active item has rate 0 or undefined
    const missingRateItem = activeItems.find(i => i.quantity > 0 && (!i.unitPrice || i.unitPrice <= 0));
    if (missingRateItem) {
      const def = bottleSizes.find(b => b.id === missingRateItem.bottleSizeId);
      if (def) {
        setPendingRateModal({
          bottleSize: def,
          enteredRate: def.defaultRefillPrice || 120
        });
      }
      alert(`Customer bottle rate for "${missingRateItem.bottleName}" is Rs. 0 or undefined. Please set and confirm the rate before dispatch.`);
      return;
    }

    // Validate that payment received does not exceed total bill
    const activeSubtotal = activeItems.reduce((acc, it) => acc + it.lineTotal, 0);
    const calculatedTotal = activeSubtotal + (Number(deliveryCharges) || 0);
    if (paymentCollected > calculatedTotal) {
      alert(`Paid amount (Rs. ${paymentCollected}) cannot exceed the total bill amount (Rs. ${calculatedTotal}). Please adjust the paid amount first. (ادا شدہ رقم کل بل Rs. ${calculatedTotal} سے زیادہ نہیں ہو سکتی، پہلے ادائیگی کی رقم درست کریں)`);
      return;
    }

    // Requirement 7: Automatically identify supervisor through currentUser
    const staffName = currentUser.name;

    const res = createDelivery({
      customerId: selectedCustomerId,
      items: activeItems,
      assignedStaffName: staffName,
      deliveryCharges,
      paymentCollected,
      paymentMethod,
      notes
    });

    if (res.success) {
      onDeliverySaved();
    } else {
      alert(res.error || "Failed to create delivery");
    }
  };

  return (
    <div className="space-y-3.5 pb-24 text-xs">
      
      {/* Date Header */}
      <div className="bg-white border border-[#CBD5E1]/70 rounded-2xl p-3 shadow-xs flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Calendar className="w-4 h-4 text-[#0A2540]" />
          <div>
            <p className="font-bold text-[#0A2540] text-xs">Delivery Date (تاریخ ترسیل)</p>
            <p className="text-[10px] text-slate-400">Dispatch record date</p>
          </div>
        </div>

        <input
          type="date"
          value={deliveryDate}
          onChange={e => setDeliveryDate(e.target.value)}
          className="bg-[#F0F7FB] border border-[#CBD5E1] rounded-lg px-2.5 py-1 text-xs font-bold text-[#0A2540]"
        />
      </div>

      {/* Step 1: Customer Selection (Requirement 9: Reduced font size & clean fit) */}
      <div className="bg-white border border-[#CBD5E1]/70 rounded-2xl p-3.5 shadow-xs space-y-2">
        <div className="flex items-center justify-between">
          <p className="font-bold text-[#0A2540] text-xs flex items-center gap-1.5">
            <User className="w-3.5 h-3.5 text-[#028090]" />
            <span>Select Customer (گاہک منتخب کریں)*</span>
          </p>
          {selectedCustomer && (
            <span className="text-[10px] font-bold text-[#10B981]">
              Empty Held: {selectedCustomer.emptyBottlesOwed} Pcs
            </span>
          )}
        </div>

        {/* Compact dropdown with smaller font size to fit mobile screens */}
        <select
          value={selectedCustomerId}
          onChange={e => setSelectedCustomerId(e.target.value)}
          className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-2.5 py-1.5 text-[10px] font-medium text-[#0F172A] focus:outline-none focus:border-[#0A2540] leading-tight"
        >
          <option value="" className="text-[10px]">-- Choose Customer ({customers.length} available) --</option>
          {customers.map(c => (
            <option key={c.id} value={c.id} className="text-[10px] py-0.5">
              {c.name} • {c.area || 'General'} (Bal: Rs.{c.currentBalance})
            </option>
          ))}
        </select>

        {selectedCustomer && (
          <div className="p-2.5 rounded-xl bg-[#E8F4F8] text-[11px] text-[#0A2540] flex items-center justify-between">
            <span className="truncate max-w-[200px]">{selectedCustomer.address} ({selectedCustomer.area})</span>
            <span className="whitespace-nowrap">
              Due: <strong className={selectedCustomer.currentBalance > 0 ? "text-[#EF4444]" : "text-[#10B981]"}>
                Rs. {selectedCustomer.currentBalance.toLocaleString()}
              </strong>
            </span>
          </div>
        )}
      </div>

      {/* Step 2: Bottle Line Items (Requirement 5 & 6: No overflow for 1.5 L & 500 ML, No Duplicates) */}
      <div className="bg-white border border-[#CBD5E1]/70 rounded-2xl p-3.5 shadow-xs space-y-3">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <div>
            <p className="font-bold text-[#0A2540] text-xs">Bottle Sizes & Quantities</p>
            <p className="text-[10px] text-slate-400">ایک بوتل سائز صرف ایک بار منتخب ہو سکتا ہے</p>
          </div>

          {/* Bottle Size Selector Pills (Requirement 6: short labels, text stays within designated area) */}
          <div className="flex items-center gap-1.5 flex-wrap">
            {bottleSizes.map(bs => {
              const isAlreadyAdded = items.some(i => i.bottleSizeId === bs.id);
              const shortLabel = formatShortBottleSizeName(bs.name);
              return (
                <button
                  key={bs.id}
                  type="button"
                  onClick={() => handleSelectBottleSize(bs)}
                  className={`px-2 py-1 rounded-lg text-[10px] font-bold transition-all flex items-center gap-1 ${
                    isAlreadyAdded 
                      ? 'bg-slate-100 text-slate-500 border border-slate-200 hover:bg-slate-200' 
                      : 'bg-[#E8F4F8] hover:bg-[#d5ebf3] text-[#0A2540] border border-[#CBD5E1]/50'
                  }`}
                  title={isAlreadyAdded ? `${shortLabel} already added. Click to increase quantity.` : `Add ${shortLabel}`}
                >
                  <Plus className="w-2.5 h-2.5" />
                  <span>{shortLabel}</span>
                  {isAlreadyAdded && <span className="text-[9px] text-slate-400 font-normal">(+1)</span>}
                </button>
              );
            })}
          </div>
        </div>

        {/* Bottle Items List */}
        <div className="space-y-2">
          {items.length === 0 ? (
            <div className="p-4 rounded-xl border border-dashed border-slate-300 text-center text-slate-400 text-xs">
              Select customer and click a bottle size above to add.
            </div>
          ) : (
            items.map((item, idx) => (
              <div
                key={item.bottleSizeId}
                className="p-2.5 rounded-xl bg-[#F0F7FB] border border-[#CBD5E1]/60 flex items-center justify-between gap-2 flex-wrap sm:flex-nowrap"
              >
                {/* Bottle Name (Requirement 6: compact display avoiding overflow) */}
                <div className="min-w-[100px] flex-1">
                  <p className="font-bold text-[#0A2540] text-xs leading-snug truncate">
                    {item.bottleName}
                  </p>
                  <div className="flex items-center gap-1.5 mt-0.5">
                    <span className="text-[10px] text-slate-500">
                      Rate: <strong className={item.unitPrice > 0 ? "text-[#0A2540]" : "text-amber-600 font-bold"}>
                        {item.unitPrice > 0 ? `Rs. ${item.unitPrice}` : 'Rs. 0 (Not Set)'}
                      </strong>
                    </span>
                    {item.unitPrice <= 0 && (
                      <button
                        type="button"
                        onClick={() => {
                          const def = bottleSizes.find(b => b.id === item.bottleSizeId);
                          if (def) {
                            setPendingRateModal({
                              bottleSize: def,
                              enteredRate: def.defaultRefillPrice || 120
                            });
                          }
                        }}
                        className="text-[9px] text-[#028090] font-bold underline"
                      >
                        Set Rate
                      </button>
                    )}
                  </div>
                </div>

                {/* Numeric Inputs: Qty & Empties (Requirement 8) */}
                <div className="flex items-center gap-2">
                  <div>
                    <span className="text-[9px] text-slate-500 block">Full Qty</span>
                    <NumericInput
                      value={item.quantity}
                      onChange={val => handleUpdateItem(idx, Math.max(0, val), item.emptyCollected)}
                      placeholder="0"
                      className="w-14 bg-white border border-[#CBD5E1] rounded-lg px-2 py-1 text-center font-bold text-xs text-[#0A2540]"
                    />
                  </div>

                  <div>
                    <span className="text-[9px] text-slate-500 block">Empties In</span>
                    <NumericInput
                      value={item.emptyCollected}
                      onChange={val => handleUpdateItem(idx, item.quantity, Math.max(0, val))}
                      placeholder="0"
                      className="w-14 bg-white border border-[#CBD5E1] rounded-lg px-2 py-1 text-center font-bold text-xs text-[#10B981]"
                    />
                  </div>

                  <div className="text-right min-w-[60px]">
                    <span className="text-[9px] text-slate-400 block">Line Total</span>
                    <strong className="text-xs text-[#0A2540] whitespace-nowrap">Rs. {item.lineTotal}</strong>
                  </div>

                  {items.length > 1 && (
                    <button
                      type="button"
                      onClick={() => handleRemoveItem(idx)}
                      className="text-slate-400 hover:text-rose-500 p-1"
                      title="Remove Item"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>
            ))
          )}
        </div>

        {/* Delivery Charges (Requirement 8: NumericInput) */}
        <div className="pt-2 border-t border-[#E2E8F0] flex items-center justify-between">
          <span className="text-[#334155] font-semibold text-xs">Delivery Charges:</span>
          <div className="flex items-center gap-1">
            <span className="text-slate-400 text-xs">Rs.</span>
            <NumericInput
              value={deliveryCharges}
              onChange={val => setDeliveryCharges(val)}
              placeholder="0"
              className="w-20 bg-white border border-[#CBD5E1] rounded-lg px-2 py-1 text-right font-bold text-xs text-[#0A2540]"
            />
          </div>
        </div>

        {/* Grand Total */}
        <div className="pt-2 border-t border-[#E2E8F0] flex items-center justify-between text-sm">
          <span className="font-bold text-[#0A2540]">Grand Total:</span>
          <strong className="text-base font-black text-[#0A2540]">
            Rs. {grandTotal.toLocaleString()}
          </strong>
        </div>
      </div>

      {/* Step 3: Payment & Dispatch (Requirement 7: Remove manual rider assignment) */}
      <div className="bg-white border border-[#CBD5E1]/70 rounded-2xl p-3.5 shadow-xs space-y-3">
        <p className="font-bold text-[#0A2540] text-xs">Payment & Dispatch Verification</p>

        <div className="grid grid-cols-2 gap-2">
          {/* Payment Collected (Requirement 8: NumericInput) */}
          <div>
            <label className="block text-[10px] font-bold text-slate-600 mb-1">
              Payment Collected Now (وصول رقم)
            </label>
            <NumericInput
              value={paymentCollected}
              onChange={val => setPaymentCollected(val)}
              placeholder="0"
              className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-3 py-2 font-black text-xs text-[#10B981]"
            />
          </div>

          <div>
            <label className="block text-[10px] font-bold text-slate-600 mb-1">
              Payment Method
            </label>
            <select
              value={paymentMethod}
              onChange={e => setPaymentMethod(e.target.value)}
              className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-2.5 py-2 text-xs text-[#0A2540] font-semibold"
            >
              <option value="Cash">Cash (نقد)</option>
              <option value="JazzCash">JazzCash</option>
              <option value="Easypaisa">Easypaisa</option>
              <option value="Bank">Bank Transfer</option>
              <option value="Unpaid">Unpaid / On Account</option>
            </select>
          </div>
        </div>

        <div>
          <label className="block text-[10px] font-bold text-slate-600 mb-1">
            Delivery Notes (اختیاری)
          </label>
          <input
            type="text"
            value={notes}
            onChange={e => setNotes(e.target.value)}
            placeholder="e.g. Delivered 2nd floor / Left at reception"
            className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-3 py-2 text-xs text-[#0F172A]"
          />
        </div>
      </div>

      {/* Buttons */}
      <div className="flex items-center gap-2 pt-2">
        <button
          type="button"
          onClick={onCancel}
          className="flex-1 py-3 rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold text-xs"
        >
          Cancel
        </button>
        <button
          type="button"
          onClick={handleSubmit}
          className="flex-2 py-3 rounded-xl bg-[#0A2540] hover:bg-[#07192C] text-white font-bold text-xs flex items-center justify-center gap-2 shadow-md transition-all"
        >
          <CheckCircle2 className="w-4 h-4 text-[#00A896]" />
          <span>Save & Dispatch Delivery</span>
        </button>
      </div>

      {/* ========================================================================= */}
      {/* REQUIREMENT 3: AUTOMATIC RATE CONFIRMATION MODAL */}
      {/* ========================================================================= */}
      {pendingRateModal && (
        <div className="fixed inset-0 z-60 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl w-full max-w-sm p-5 shadow-2xl space-y-3.5 animate-in fade-in zoom-in-95">
            <div className="flex items-start justify-between border-b pb-2">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-xl bg-amber-50 text-amber-700">
                  <Tag className="w-5 h-5 text-amber-600" />
                </div>
                <div>
                  <h3 className="font-black text-sm text-[#0A2540]">Set Agreed Bottle Rate</h3>
                  <p className="text-[10px] text-slate-500">ریٹ طے کریں اور محفوظ کریں</p>
                </div>
              </div>
              <button 
                onClick={() => setPendingRateModal(null)} 
                className="p-1 rounded-full bg-slate-100 text-slate-500"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-2.5 rounded-xl bg-amber-50/70 border border-amber-200 text-amber-900 text-[11px] space-y-1">
              <p className="font-bold">
                ⚠️ Rate not defined for &quot;{pendingRateModal.bottleSize.name}&quot;!
              </p>
              <p className="text-[10px] text-amber-800 leading-relaxed">
                The agreed rate for customer <strong>{selectedCustomer?.name}</strong> is currently Rs. 0 or undefined. Please confirm the rate. It will be saved for this and future deliveries.
              </p>
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">
                Agreed Rate for {pendingRateModal.bottleSize.name} (Rs.) *
              </label>
              <NumericInput
                value={pendingRateModal.enteredRate}
                onChange={val => setPendingRateModal({ ...pendingRateModal, enteredRate: val })}
                placeholder="e.g. 120"
                className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-3 py-2 text-sm font-black text-[#0A2540] text-center"
              />
            </div>

            <div className="flex items-center gap-2 pt-2">
              <button
                type="button"
                onClick={() => setPendingRateModal(null)}
                className="flex-1 py-2.5 rounded-xl bg-slate-200 text-slate-700 font-bold text-xs"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmRate}
                className="flex-1 py-2.5 rounded-xl bg-[#0A2540] hover:bg-[#028090] text-white font-bold text-xs transition-colors shadow-xs"
              >
                Confirm Rate
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
