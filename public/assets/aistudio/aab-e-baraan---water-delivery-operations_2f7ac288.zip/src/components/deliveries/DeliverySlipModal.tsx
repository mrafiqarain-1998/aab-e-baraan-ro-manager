import React, { useRef, useState } from 'react';
import jsPDF from 'jspdf';
import { toJpeg } from 'html-to-image';
import { 
  X, 
  Download, 
  Printer, 
  MessageCircle, 
  Share2, 
  CheckCircle2, 
  AlertCircle,
  FileText,
  Loader2
} from 'lucide-react';
import { Delivery } from '../../types';
import { useWaterApp } from '../../context/WaterAppContext';

interface DeliverySlipModalProps {
  delivery: Delivery;
  onClose: () => void;
}

export const DeliverySlipModal: React.FC<DeliverySlipModalProps> = ({
  delivery,
  onClose
}) => {
  const { businessProfile, customers } = useWaterApp();
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false);
  const slipRef = useRef<HTMLDivElement>(null);

  const customer = customers.find(c => c.id === delivery.customerId);
  const cleanPhone = (delivery.customerPhone || customer?.phone || '').replace(/[^0-9]/g, '');
  const deliveryOutstanding = Math.max(0, delivery.totalAmount - (delivery.paymentCollected || 0));
  const contactPhone = businessProfile.phone || businessProfile.whatsapp || '0300-8472910';
  const supervisor = delivery.staffName || delivery.createdBy || 'Plant Supervisor';

  // Helper to capture slip DOM as a high-resolution PDF document
  const generatePdfBlob = async (): Promise<{
    pdf: jsPDF;
    fileName: string;
    blob: Blob;
    file: File;
  } | null> => {
    if (!slipRef.current) return null;

    // html-to-image uses native SVG foreignObject / canvas rendering.
    // skipFonts: true prevents SecurityError when reading external Google Fonts rules.
    const imgData = await toJpeg(slipRef.current, {
      quality: 0.95,
      pixelRatio: 2,
      backgroundColor: '#ffffff',
      cacheBust: true,
      skipFonts: true,
      fontEmbedCSS: ''
    });

    const img = new Image();
    img.src = imgData;
    await new Promise((resolve) => {
      img.onload = resolve;
    });

    // Custom format based on slip aspect ratio to never cut off bottom motto
    const pdfWidth = 148; // mm (standard A5 width)
    const pdfHeight = (img.height * pdfWidth) / img.width;
    const pageHeight = Math.max(210, pdfHeight + 10);

    const pdf = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: [pdfWidth, pageHeight]
    });

    pdf.addImage(imgData, 'JPEG', 0, 5, pdfWidth, pdfHeight);
    const fileName = `Aab-e-Baraan-Slip-${delivery.deliveryNumber}.pdf`;
    const blob = pdf.output('blob');
    const file = new File([blob], fileName, { type: 'application/pdf' });
    return { pdf, fileName, blob, file };
  };

  // 1. Generate & Download PDF
  const handleDownloadPdf = async () => {
    setIsGeneratingPdf(true);
    try {
      const result = await generatePdfBlob();
      if (result) {
        result.pdf.save(result.fileName);
      }
    } catch (err) {
      console.error('Error generating PDF:', err);
      window.print();
    } finally {
      setIsGeneratingPdf(false);
    }
  };

  // 2. Share PDF on WhatsApp (downloads PDF & opens WhatsApp with formatted summary)
  const handleWhatsAppShare = async () => {
    setIsGeneratingPdf(true);
    const textMsg = `*AAB-E-BARAAN MINERAL WATER PLANT*\n*Delivery Invoice & Slip*\n---------------------------\n*Slip #:* ${delivery.deliveryNumber}\n*Date:* ${delivery.date}\n*Customer:* ${delivery.customerName}\n*Total Amount:* Rs. ${delivery.totalAmount}\n*Paid Amount:* Rs. ${delivery.paymentCollected}\n*Balance Due:* Rs. ${deliveryOutstanding}\n*Empties Collected:* ${delivery.totalEmptyCollected}\n---------------------------\n_Your official PDF slip has been downloaded._\nHelpline: ${contactPhone}`;

    const waUrl = cleanPhone 
      ? `https://wa.me/${cleanPhone}?text=${encodeURIComponent(textMsg)}`
      : `https://wa.me/?text=${encodeURIComponent(textMsg)}`;

    try {
      const result = await generatePdfBlob();
      if (result) {
        // Always trigger download of the PDF so the user has the physical document
        result.pdf.save(result.fileName);

        // Optionally try native Web Share API with the file (e.g., on Android/iOS mobile browsers)
        if (typeof navigator !== 'undefined' && navigator.canShare && navigator.canShare({ files: [result.file] })) {
          try {
            await navigator.share({
              files: [result.file],
              title: `Delivery Slip #${delivery.deliveryNumber}`,
              text: `Aab-e-Baraan Delivery Slip #${delivery.deliveryNumber} for ${delivery.customerName}.`
            });
            // If native share sheet completed successfully, return without opening external link
            return;
          } catch (shareErr: any) {
            // Note: NotAllowedError occurs when the browser determines user gesture expired during async rendering.
            // AbortError occurs when the user dismisses the share sheet. Both are normal browser behaviors.
            // In either case, we smoothly fall back to opening WhatsApp directly below.
          }
        }
      }

      // Open WhatsApp web or app with prefilled message
      window.open(waUrl, '_blank');
    } catch (err) {
      console.warn('WhatsApp share fallback triggered:', err);
      window.open(waUrl, '_blank');
    } finally {
      setIsGeneratingPdf(false);
    }
  };

  // 3. Print Slip (Isolated printable document without modal overlay)
  const handlePrint = () => {
    if (!slipRef.current) return;
    try {
      const printFrame = document.createElement('iframe');
      printFrame.setAttribute('style', 'position:fixed;width:0;height:0;top:-1000px;left:-1000px;border:none;');
      document.body.appendChild(printFrame);

      const frameDoc = printFrame.contentWindow?.document || printFrame.contentDocument;
      if (frameDoc) {
        frameDoc.open();
        frameDoc.write(`
          <!DOCTYPE html>
          <html>
            <head>
              <title>Delivery Slip #${delivery.deliveryNumber}</title>
              <style>
                @page { size: A5 portrait; margin: 8mm; }
                body { margin: 0; padding: 4px; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; color: #1e293b; background: #fff; }
                * { box-sizing: border-box; }
                table { width: 100%; border-collapse: collapse; font-size: 11px; }
                th, td { border: 1px solid #cbd5e1; padding: 4px 6px; }
                th { background-color: #0a2540; color: #fff; }
                .text-right { text-align: right; }
                .text-center { text-align: center; }
                .font-bold { font-weight: bold; }
                .font-black { font-weight: 900; }
                .flex { display: flex; }
                .justify-between { justify-content: space-between; }
                .grid { display: grid; }
                .grid-cols-2 { grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 6px; }
              </style>
            </head>
            <body>
              ${slipRef.current.innerHTML}
            </body>
          </html>
        `);
        frameDoc.close();

        setTimeout(() => {
          try {
            printFrame.contentWindow?.focus();
            printFrame.contentWindow?.print();
          } catch {
            window.print();
          } finally {
            setTimeout(() => {
              if (document.body.contains(printFrame)) {
                document.body.removeChild(printFrame);
              }
            }, 1500);
          }
        }, 300);
        return;
      }
    } catch {
      // Fallback
    }
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-3 overflow-y-auto">
      <div className="bg-white rounded-3xl w-full max-w-md shadow-2xl overflow-hidden flex flex-col my-auto max-h-[95vh]">
        
        {/* Top Control Bar */}
        <div className="p-3 bg-[#0A2540] text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <FileText className="w-4 h-4 text-[#00A896]" />
            <span className="font-bold text-xs">PDF Slip Preview (بل کا پریویو)</span>
          </div>

          <button
            onClick={onClose}
            className="py-1 px-3 rounded-full bg-white/15 hover:bg-white/25 text-white text-xs font-bold flex items-center gap-1 transition-colors"
            title="Close Slip"
          >
            <X className="w-4 h-4" />
            <span>Close (بند کریں)</span>
          </button>
        </div>

        {/* Action Buttons Toolbar */}
        <div className="p-2.5 bg-slate-100 border-b border-slate-200 flex items-center gap-2 flex-wrap">
          <button
            type="button"
            disabled={isGeneratingPdf}
            onClick={handleDownloadPdf}
            className="flex-1 min-w-[95px] py-2 px-2.5 rounded-xl bg-[#0A2540] hover:bg-[#07192C] text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-xs transition-transform active:scale-95 disabled:opacity-50"
          >
            {isGeneratingPdf ? (
              <Loader2 className="w-3.5 h-3.5 animate-spin" />
            ) : (
              <Download className="w-3.5 h-3.5 text-[#00A896]" />
            )}
            <span>PDF Slip</span>
          </button>

          <button
            type="button"
            disabled={isGeneratingPdf}
            onClick={handleWhatsAppShare}
            className="flex-1 min-w-[95px] py-2 px-2.5 rounded-xl bg-[#25D366] hover:bg-[#20bd5a] text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-xs transition-transform active:scale-95 disabled:opacity-50"
          >
            <MessageCircle className="w-3.5 h-3.5" />
            <span>WhatsApp</span>
          </button>

          <button
            type="button"
            onClick={handlePrint}
            className="py-2 px-3 rounded-xl bg-white border border-slate-300 hover:bg-slate-50 text-slate-700 font-bold text-xs flex items-center gap-1 shadow-xs"
            title="Print Slip"
          >
            <Printer className="w-3.5 h-3.5 text-slate-600" />
            <span>Print</span>
          </button>

          <button
            type="button"
            onClick={onClose}
            className="py-2 px-3 rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold text-xs flex items-center gap-1 shadow-xs"
            title="Close Window"
          >
            <X className="w-3.5 h-3.5 text-slate-600" />
            <span>Close</span>
          </button>
        </div>

        {/* Scrollable Printable Slip Container */}
        <div className="overflow-y-auto p-4 flex-1 bg-slate-50">
          
          {/* THE ACTUAL PRINTABLE / EXPORTABLE SLIP CANVAS */}
          <div
            ref={slipRef}
            className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm relative overflow-hidden font-sans text-slate-800 text-xs"
            style={{ minHeight: '480px' }}
          >
            {/* Watermark Logo in Background */}
            <div 
              className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-[0.04] z-0"
              style={{
                backgroundImage: 'url(/aab_e_baraan_logo.png)',
                backgroundPosition: 'center',
                backgroundRepeat: 'no-repeat',
                backgroundSize: '240px'
              }}
            />

            <div className="relative z-10 space-y-3">
              {/* Slip Header with Logo */}
              <div className="text-center pb-3 border-b-2 border-[#0A2540]/20 space-y-1">
                <img
                  src="/aab_e_baraan_logo.png"
                  alt="Aab-e-Baraan Logo"
                  className="h-14 mx-auto object-contain"
                />
                <h2 className="text-sm font-black tracking-wider text-[#0A2540] uppercase">
                  {businessProfile.businessName}
                </h2>
                <p className="text-[11px] text-[#00A896] font-bold tracking-wide">
                  Purified Drinking Water
                </p>
                <p className="text-[10px] text-slate-500 font-urdu">
                  آب باران منرل واٹر پلانٹ - قدرتی پاکیزگی
                </p>
              </div>

              {/* Delivery Metadata Grid */}
              <div className="grid grid-cols-2 gap-2 p-2.5 rounded-xl bg-slate-50 border border-slate-100 text-[10px]">
                <div>
                  <span className="text-slate-400 block font-medium">Slip / Delivery No:</span>
                  <strong className="text-xs text-[#0A2540]">{delivery.deliveryNumber}</strong>
                </div>
                <div className="text-right">
                  <span className="text-slate-400 block font-medium">Date & Time:</span>
                  <strong className="text-[#0A2540]">
                    {delivery.date} {new Date(delivery.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </strong>
                </div>

                <div>
                  <span className="text-slate-400 block font-medium">Customer Name:</span>
                  <strong className="text-[#0A2540] text-[11px]">{delivery.customerName}</strong>
                </div>
                <div className="text-right">
                  <span className="text-slate-400 block font-medium">Phone:</span>
                  <strong className="text-slate-700">{delivery.customerPhone}</strong>
                </div>

                <div className="col-span-2 pt-1 border-t border-slate-200/60 flex justify-between items-center">
                  <span className="text-slate-500">Address / Area:</span>
                  <span className="font-semibold text-slate-800">{delivery.customerAddress}</span>
                </div>
                <div className="col-span-2 flex justify-between items-center">
                  <span className="text-slate-500">Supervisor / Dispatcher:</span>
                  <span className="font-semibold text-[#00A896]">{supervisor}</span>
                </div>
              </div>

              {/* Items Breakdown Table */}
              <div className="border border-slate-200 rounded-xl overflow-hidden">
                <table className="w-full text-[10px] text-left">
                  <thead className="bg-[#0A2540] text-white">
                    <tr>
                      <th className="py-1.5 px-2 font-bold">Item / Size</th>
                      <th className="py-1.5 px-2 text-center font-bold">Qty</th>
                      <th className="py-1.5 px-2 text-right font-bold">Rate</th>
                      <th className="py-1.5 px-2 text-right font-bold">Total</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {delivery.items.map((it, idx) => (
                      <tr key={idx} className={idx % 2 === 0 ? 'bg-white' : 'bg-slate-50/50'}>
                        <td className="py-1.5 px-2 font-semibold text-slate-800">
                          {it.bottleName}
                        </td>
                        <td className="py-1.5 px-2 text-center font-bold text-[#0A2540]">
                          {it.quantity}
                        </td>
                        <td className="py-1.5 px-2 text-right text-slate-600">
                          Rs. {it.unitPrice}
                        </td>
                        <td className="py-1.5 px-2 text-right font-bold text-slate-900">
                          Rs. {it.lineTotal}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Financial Calculation Summary */}
              <div className="space-y-1 text-[11px] pt-1">
                <div className="flex justify-between text-slate-600">
                  <span>Subtotal (بل رقم):</span>
                  <span>Rs. {delivery.subtotal}</span>
                </div>
                {delivery.deliveryCharges > 0 && (
                  <div className="flex justify-between text-slate-600">
                    <span>Delivery Charges (کرایہ):</span>
                    <span>Rs. {delivery.deliveryCharges}</span>
                  </div>
                )}
                <div className="flex justify-between text-xs font-black text-[#0A2540] pt-1 border-t border-slate-200">
                  <span>Total Bill Amount (کل بل):</span>
                  <span className="text-sm text-[#00A896]">Rs. {delivery.totalAmount}</span>
                </div>

                <div className="flex justify-between text-slate-700 font-bold pt-1 border-t border-dashed border-slate-200">
                  <span className="text-emerald-700">Payment Received (وصول شدہ):</span>
                  <span className="text-emerald-700 font-black">Rs. {delivery.paymentCollected}</span>
                </div>

                <div className="flex justify-between text-slate-700 font-bold">
                  <span>This Delivery Outstanding:</span>
                  <span className={deliveryOutstanding > 0 ? "text-red-600 font-black" : "text-emerald-700"}>
                    Rs. {deliveryOutstanding}
                  </span>
                </div>

                {customer && (
                  <div className="p-2 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 flex justify-between font-bold text-[10px] mt-1">
                    <span>Total Outstanding Balance (گاہک کا کل بقیہ):</span>
                    <span className="text-red-700 text-xs">Rs. {customer.currentBalance.toLocaleString()}</span>
                  </div>
                )}
              </div>

              {/* Empty Bottles Status */}
              <div className="p-2.5 rounded-xl bg-[#F0F7FB] border border-[#CBD5E1]/60 flex items-center justify-between text-[10px]">
                <div>
                  <span className="text-slate-500 block">Empty Bottles Returned:</span>
                  <strong className="text-xs text-[#0A2540]">{delivery.totalEmptyCollected} Pcs</strong>
                </div>
                <div className="text-right">
                  <span className="text-slate-500 block">Total Empties Held by Customer:</span>
                  <strong className="text-xs text-[#00A896]">
                    {customer ? customer.emptyBottlesOwed : 0} Pcs
                  </strong>
                </div>
              </div>

              {/* System Generated Slip Notice */}
              <div className="pt-3 pb-1 text-center border-t border-dashed border-slate-300">
                <p className="text-[9.5px] font-semibold text-slate-700">
                  This is a system generated slip — signature is not required.
                </p>
                <p className="text-[9px] text-slate-500 font-urdu mt-0.5">
                  (یہ کمپیوٹرائزڈ سلپ ہے، دستخط کی ضرورت نہیں ہے)
                </p>
              </div>

              {/* Plant Motto */}
              <div className="text-center pt-2 text-[8px] text-slate-400">
                Thank you for choosing Aab-e-Baraan Purified Drinking Water.
              </div>
            </div>
          </div>

        </div>

        {/* Modal Bottom Footer */}
        <div className="p-3 bg-white border-t border-slate-100 flex items-center justify-between">
          <span className="text-[10px] text-slate-400">
            Aab-e-Baraan Digital Slip System
          </span>
          <button
            onClick={onClose}
            className="py-1.5 px-4 rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold text-xs"
          >
            Close
          </button>
        </div>

      </div>
    </div>
  );
};
