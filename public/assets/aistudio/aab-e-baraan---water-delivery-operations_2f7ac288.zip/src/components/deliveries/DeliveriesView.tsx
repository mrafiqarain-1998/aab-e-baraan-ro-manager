import React, { useState } from 'react';
import { useWaterApp } from '../../context/WaterAppContext';
import { 
  Truck, 
  Plus, 
  Search, 
  MapPin, 
  Calendar,
  X,
  MessageCircle,
  Trash2,
  AlertTriangle,
  Pencil,
  CreditCard,
  CheckCircle2,
  Clock,
  DollarSign,
  FileText
} from 'lucide-react';
import { Delivery, DeliveryItem, Payment } from '../../types';
import { NumericInput } from '../common/NumericInput';
import { DeliverySlipModal } from './DeliverySlipModal';

interface DeliveriesViewProps {
  onNavigateToNewDelivery: () => void;
  isNewDeliveryOpen?: boolean;
  onCloseNewDelivery?: () => void;
}

type DateFilter = 'TODAY' | 'YESTERDAY' | 'LAST_7_DAYS' | 'LAST_30_DAYS' | 'ALL';

export const DeliveriesView: React.FC<DeliveriesViewProps> = ({
  onNavigateToNewDelivery
}) => {
  const { 
    deliveries, 
    payments,
    bottleSizes,
    businessProfile,
    currentUser,
    deleteDelivery,
    updateDelivery,
    payForDelivery
  } = useWaterApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedFilter, setSelectedFilter] = useState<DateFilter>('TODAY');
  const [selectedDelivery, setSelectedDelivery] = useState<Delivery | null>(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [slipDelivery, setSlipDelivery] = useState<Delivery | null>(null);

  // Requirement 11: Dedicated Payment Modal State
  const [paymentDelivery, setPaymentDelivery] = useState<Delivery | null>(null);
  const [payAmount, setPayAmount] = useState<number>(0);
  const [payMethod, setPayMethod] = useState<Payment['paymentMethod']>('CASH');
  const [payTxnRef, setPayTxnRef] = useState('');
  const [payNotes, setPayNotes] = useState('');
  const [payDate, setPayDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [paySubmitting, setPaySubmitting] = useState(false);

  // Requirement 10: Admin Edit Delivery Modal State
  const [editingDelivery, setEditingDelivery] = useState<Delivery | null>(null);
  const [editDate, setEditDate] = useState('');
  const [editItems, setEditItems] = useState<DeliveryItem[]>([]);
  const [editCharges, setEditCharges] = useState(0);
  const [editPaymentCollected, setEditPaymentCollected] = useState(0);
  const [editPaymentMethod, setEditPaymentMethod] = useState('Cash');
  const [editNotes, setEditNotes] = useState('');

  const todayStr = new Date().toISOString().split('T')[0];
  const yesterdayStr = new Date(Date.now() - 86400000).toISOString().split('T')[0];
  const last7Str = new Date(Date.now() - 6 * 86400000).toISOString().split('T')[0];
  const last30Str = new Date(Date.now() - 29 * 86400000).toISOString().split('T')[0];

  // Filter deliveries
  const filteredDeliveries = deliveries.filter(del => {
    const matchesSearch = 
      del.customerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      del.deliveryNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      del.customerPhone.replace(/[^0-9]/g, '').includes(searchQuery.replace(/[^0-9]/g, '')) ||
      del.customerArea.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesDate = 
      selectedFilter === 'ALL' ||
      (selectedFilter === 'TODAY' && del.date === todayStr) ||
      (selectedFilter === 'YESTERDAY' && del.date === yesterdayStr) ||
      (selectedFilter === 'LAST_7_DAYS' && del.date >= last7Str) ||
      (selectedFilter === 'LAST_30_DAYS' && del.date >= last30Str);

    return matchesSearch && matchesDate;
  });

  const totalFull = filteredDeliveries.reduce((sum, d) => sum + d.totalFullDelivered, 0);
  const totalEmpties = filteredDeliveries.reduce((sum, d) => sum + d.totalEmptyCollected, 0);
  const totalRevenue = filteredDeliveries.reduce((sum, d) => sum + d.totalAmount, 0);

  const isAdmin = currentUser.role === 'ADMIN';

  const handleDeleteCurrentDelivery = () => {
    if (!selectedDelivery) return;
    const res = deleteDelivery(selectedDelivery.id);
    if (res.success) {
      setShowDeleteConfirm(false);
      setSelectedDelivery(null);
    } else {
      alert(res.error || "Failed to delete delivery.");
    }
  };

  // Open dedicated payment modal for unpaid or partial credit delivery
  const handleOpenPaymentModal = (del: Delivery, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    const remaining = Math.max(0, del.totalAmount - del.paymentCollected);
    setPaymentDelivery(del);
    setPayAmount(remaining);
    setPayMethod('CASH');
    setPayTxnRef('');
    setPayNotes('');
    setPayDate(new Date().toISOString().split('T')[0]);
  };

  const handleRecordPayment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!paymentDelivery || paySubmitting) return;

    if (payAmount <= 0) {
      alert("Payment amount must be greater than 0");
      return;
    }

    setPaySubmitting(true);
    const res = payForDelivery({
      deliveryId: paymentDelivery.id,
      amount: payAmount,
      paymentMethod: payMethod,
      transactionRef: payTxnRef,
      notes: payNotes,
      date: payDate
    });

    setPaySubmitting(false);

    if (res.success) {
      // Refresh selected delivery if it is open
      if (selectedDelivery && selectedDelivery.id === paymentDelivery.id) {
        setSelectedDelivery({
          ...selectedDelivery,
          paymentCollected: selectedDelivery.paymentCollected + Math.min(payAmount, selectedDelivery.totalAmount - selectedDelivery.paymentCollected)
        });
      }
      setPaymentDelivery(null);
    } else {
      alert(res.error || "Failed to record payment");
    }
  };

  // Open Admin Edit Delivery modal
  const handleOpenEditDelivery = (del: Delivery) => {
    setEditingDelivery(del);
    setEditDate(del.date);
    setEditItems(JSON.parse(JSON.stringify(del.items)));
    setEditCharges(del.deliveryCharges || 0);
    setEditPaymentCollected(del.paymentCollected);
    setEditPaymentMethod(del.paymentMethod);
    setEditNotes(del.notes || '');
  };

  const handleSaveEditedDelivery = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingDelivery) return;

    // Filter items with quantity > 0 (or empties collected)
    const validItems = editItems.filter(i => i.quantity > 0 || (i.emptyCollected && i.emptyCollected > 0));
    if (validItems.length === 0) {
      alert("Delivery must have at least 1 item with quantity greater than 0. (کم از کم ایک بوتل کی تعداد 1 یا زیادہ ہونی چاہیے)");
      return;
    }

    const newSubtotal = validItems.reduce((acc, item) => acc + item.lineTotal, 0);
    const calculatedGrandTotal = newSubtotal + (Number(editCharges) || 0);

    if (editPaymentCollected > calculatedGrandTotal) {
      alert(`Paid amount (Rs. ${editPaymentCollected}) cannot exceed the total bill amount (Rs. ${calculatedGrandTotal}). Please adjust the paid amount first. (ادا شدہ رقم کل بل Rs. ${calculatedGrandTotal} سے زیادہ نہیں ہو سکتی، پہلے ادائیگی کی رقم درست کریں)`);
      return;
    }

    const res = updateDelivery(editingDelivery.id, {
      items: validItems,
      deliveryCharges: editCharges,
      paymentCollected: editPaymentCollected,
      paymentMethod: editPaymentMethod,
      notes: editNotes,
      date: editDate
    });

    if (res.success) {
      const freshDel: Delivery = {
        ...editingDelivery,
        items: validItems,
        deliveryCharges: Number(editCharges) || 0,
        subtotal: newSubtotal,
        totalAmount: calculatedGrandTotal,
        totalFullDelivered: validItems.reduce((acc, it) => acc + it.quantity, 0),
        totalEmptyCollected: validItems.reduce((acc, it) => acc + (it.emptyCollected || 0), 0),
        paymentCollected: Number(editPaymentCollected) || 0,
        paymentMethod: editPaymentMethod,
        notes: editNotes,
        date: editDate,
        lastEditedAt: Date.now(),
        lastEditedBy: currentUser.name
      };

      setSelectedDelivery(freshDel);
      if (slipDelivery && slipDelivery.id === editingDelivery.id) {
        setSlipDelivery(freshDel);
      }
      setEditingDelivery(null);
    } else {
      alert(res.error || "Failed to update delivery");
    }
  };

  return (
    <div className="space-y-3.5 pb-24 text-xs">
      
      {/* Date Filter Chips */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar text-xs">
        {[
          { id: 'TODAY' as DateFilter, label: 'Today', urdu: 'آج' },
          { id: 'YESTERDAY' as DateFilter, label: 'Yesterday', urdu: 'کل' },
          { id: 'LAST_7_DAYS' as DateFilter, label: 'Last 7 Days', urdu: '7 دن' },
          { id: 'LAST_30_DAYS' as DateFilter, label: 'Last 30 Days', urdu: '30 دن' },
          { id: 'ALL' as DateFilter, label: 'All Records', urdu: 'تمام' },
        ].map(filter => (
          <button
            key={filter.id}
            onClick={() => setSelectedFilter(filter.id)}
            className={`px-3 py-1.5 rounded-full font-bold whitespace-nowrap transition-all ${
              selectedFilter === filter.id
                ? 'bg-[#0A2540] text-white shadow-xs'
                : 'bg-white text-[#334155] border border-[#CBD5E1] hover:bg-[#F0F7FB]'
            }`}
          >
            <span>{filter.label}</span>
            <span className="text-[10px] ml-1 opacity-80 font-urdu">{filter.urdu}</span>
          </button>
        ))}
      </div>

      {/* Summary Card */}
      <div className="bg-white border border-[#CBD5E1]/70 rounded-2xl p-4 shadow-xs">
        <div className="flex items-center justify-between pb-2 border-b border-[#E2E8F0]">
          <div>
            <h3 className="text-xs font-bold text-[#0A2540]">
              Delivery Summary ({selectedFilter === 'TODAY' ? 'Today' : selectedFilter.toLowerCase()})
            </h3>
            <p className="text-[11px] text-[#475569] font-urdu">کل ترسیل و ریکوری کا خلاصہ</p>
          </div>
          <span className="text-xs font-bold text-[#0A2540]">
            {filteredDeliveries.length} Deliveries
          </span>
        </div>

        <div className="grid grid-cols-3 gap-2 mt-2.5 text-xs text-center">
          <div className="p-2 rounded-xl bg-[#F0F7FB]">
            <span className="text-[10px] text-[#475569] block">Delivered</span>
            <strong className="text-sm font-black text-[#0A2540]">{totalFull} Bottles</strong>
          </div>
          <div className="p-2 rounded-xl bg-[#D1FAE5]/60">
            <span className="text-[10px] text-[#065F46] block">Empties Returned</span>
            <strong className="text-sm font-black text-[#10B981]">{totalEmpties}</strong>
          </div>
          <div className="p-2 rounded-xl bg-[#FEF3C7]/60">
            <span className="text-[10px] text-[#92400E] block">Total Amount</span>
            <strong className="text-sm font-black text-[#D97706]">Rs. {totalRevenue.toLocaleString()}</strong>
          </div>
        </div>
      </div>

      {/* Search Bar */}
      <div className="relative">
        <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
        <input
          type="text"
          placeholder="Search deliveries by customer, area, phone..."
          value={searchQuery}
          onChange={e => setSearchQuery(e.target.value)}
          className="w-full pl-9 pr-3 py-2 bg-white border border-[#CBD5E1] rounded-xl text-xs text-[#0F172A] placeholder-slate-400 focus:outline-none focus:border-[#0A2540]"
        />
      </div>

      {/* Deliveries List Cards */}
      <div className="space-y-2">
        {filteredDeliveries.length === 0 ? (
          <div className="bg-white border border-[#CBD5E1]/70 rounded-2xl p-8 text-center text-xs text-[#475569]">
            <Truck className="w-8 h-8 text-slate-300 mx-auto mb-2" />
            <p className="font-semibold text-slate-600">No deliveries found for this period.</p>
            <p className="text-[11px] text-slate-400 mt-1">Tap below to dispatch a new delivery.</p>
          </div>
        ) : (
          filteredDeliveries.map(del => {
            const isUnpaidOrCredit = del.totalAmount > del.paymentCollected;
            const remainingDue = Math.max(0, del.totalAmount - del.paymentCollected);

            return (
              <div
                key={del.id}
                onClick={() => setSelectedDelivery(del)}
                className="bg-white border border-[#CBD5E1]/70 rounded-2xl p-3.5 shadow-xs space-y-2.5 cursor-pointer hover:border-[#0A2540]/40 transition-colors"
              >
                <div className="flex items-start justify-between">
                  <div>
                    <div className="flex items-center gap-1.5">
                      <span className="font-bold text-xs sm:text-sm text-[#0A2540]">{del.customerName}</span>
                      <span className="text-[10px] text-slate-400 font-mono">({del.deliveryNumber})</span>
                    </div>
                    <p className="text-[11px] text-[#475569] flex items-center gap-1 mt-0.5">
                      <MapPin className="w-3 h-3 text-[#00A896]" />
                      <span>{del.customerArea} - {del.customerAddress}</span>
                    </p>
                  </div>

                  <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                    del.status === 'DELIVERED' 
                      ? 'bg-[#D1FAE5] text-[#065F46]'
                      : 'bg-[#FEF3C7] text-[#92400E]'
                  }`}>
                    {del.status}
                  </span>
                </div>

                {/* Items & Payment Info */}
                <div className="pt-2 border-t border-[#E2E8F0] flex items-center justify-between text-xs">
                  <div className="text-[11px] text-[#334155]">
                    <span>{del.items.map(i => `${i.quantity}x ${i.bottleName}`).join(', ')}</span>
                    <span className="text-[#10B981] font-bold ml-2">↩ {del.totalEmptyCollected}</span>
                  </div>

                  <div className="text-right">
                    <span className="text-xs font-black text-[#0A2540]">
                      Rs. {del.totalAmount.toLocaleString()}
                    </span>
                    <p className={`text-[10px] font-bold ${
                      !isUnpaidOrCredit ? 'text-[#10B981]' : del.paymentCollected > 0 ? 'text-amber-600' : 'text-[#EF4444]'
                    }`}>
                      {!isUnpaidOrCredit ? 'Paid (نقد)' : `Due: Rs. ${remainingDue.toLocaleString()}`}
                    </p>
                  </div>
                </div>

                {/* Footer with Staff and REQUIREMENT 11: Dedicated Payment Button */}
                <div className="pt-1.5 border-t border-slate-100 flex items-center justify-between text-xs">
                  <span className="text-[10px] text-slate-400">
                    Staff: <strong>{del.staffName}</strong> • {del.time}
                  </span>

                  <div className="flex items-center gap-2">
                    {/* Dedicated Compact Payment Button for Unpaid/Credit Deliveries */}
                    {isUnpaidOrCredit && (
                      <button
                        onClick={e => handleOpenPaymentModal(del, e)}
                        className="p-1.5 rounded-lg bg-[#10B981] hover:bg-[#059669] text-white shadow-xs transition-all flex items-center justify-center active:scale-95"
                        title="Record Payment (ادائیگی وصولی)"
                      >
                        <CreditCard className="w-3.5 h-3.5" />
                      </button>
                    )}

                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setSlipDelivery(del);
                      }}
                      className="text-[10px] text-[#00A896] hover:text-[#0A2540] font-bold flex items-center gap-1 transition-colors px-1.5 py-0.5 rounded-md hover:bg-[#E8F4F8]"
                      title="Preview PDF Slip"
                    >
                      <FileText className="w-3 h-3" />
                      <span>Slip (PDF) →</span>
                    </button>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Floating Action Button */}
      <button
        onClick={onNavigateToNewDelivery}
        className="fixed bottom-18 right-4 sm:right-auto sm:left-1/2 sm:translate-x-44 z-30 px-4 py-3 rounded-full bg-[#0A2540] hover:bg-[#07192C] text-white font-bold text-xs sm:text-sm shadow-xl flex items-center gap-2 active:scale-95 transition-all"
      >
        <Plus className="w-5 h-5 stroke-[2.5]" />
        <span>New Delivery (نئی ڈیلیوری)</span>
      </button>

      {/* ========================================================================= */}
      {/* DELIVERY DETAILS & RECEIPT MODAL */}
      {/* ========================================================================= */}
      {selectedDelivery && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl w-full max-w-sm p-5 shadow-2xl space-y-3 font-sans text-xs max-h-[90vh] overflow-y-auto">
            
            {/* Logo Header */}
            <div className="text-center pt-1 pb-2 border-b border-slate-100">
              <img 
                src="/aab_e_baraan_logo.png" 
                alt="Aab-e-Baraan" 
                className="h-16 mx-auto object-contain mb-1" 
              />
              <h3 className="text-sm font-bold text-[#0A2540]">{businessProfile.businessName}</h3>
              <p className="text-[11px] text-[#00A896] font-urdu font-bold">ڈیلیوری انوائس و رسید</p>
            </div>

            <div className="flex items-center justify-between pb-1">
              <div>
                <span className="text-[10px] text-slate-400 font-mono">Invoice #: {selectedDelivery.deliveryNumber}</span>
                {selectedDelivery.lastEditedAt && (
                  <p className="text-[9px] text-amber-700 font-semibold">
                    Edited by {selectedDelivery.lastEditedBy || 'Admin'} on {new Date(selectedDelivery.lastEditedAt).toLocaleDateString()}
                  </p>
                )}
              </div>
              
              <div className="flex items-center gap-1.5">
                {/* REQUIREMENT 10: Admin Edit Delivery Button */}
                {isAdmin && (
                  <button
                    onClick={() => handleOpenEditDelivery(selectedDelivery)}
                    className="py-1 px-2.5 rounded-xl bg-[#0A2540] hover:bg-[#028090] text-white font-bold text-[11px] flex items-center gap-1 shadow-xs transition-colors"
                    title="Edit Delivery (صرف ایڈمن)"
                  >
                    <Pencil className="w-3 h-3" />
                    <span>Edit</span>
                  </button>
                )}
                <button
                  onClick={() => {
                    setSelectedDelivery(null);
                    setShowDeleteConfirm(false);
                  }}
                  className="p-1 rounded-full bg-slate-100 text-slate-500 hover:bg-slate-200"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Delivery Overview */}
            <div className="space-y-1 bg-[#F0F7FB] p-2.5 rounded-xl text-[11px]">
              <div className="flex justify-between">
                <span className="text-slate-500">Customer:</span>
                <strong className="text-[#0A2540]">{selectedDelivery.customerName}</strong>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Area / Address:</span>
                <span className="text-right text-slate-700">{selectedDelivery.customerArea} - {selectedDelivery.customerAddress}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Phone:</span>
                <a href={`tel:${selectedDelivery.customerPhone.replace(/[^0-9+]/g, '')}`} className="text-[#028090] font-bold">
                  {selectedDelivery.customerPhone.replace(/[^0-9+]/g, '')}
                </a>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Rider / Date:</span>
                <span>{selectedDelivery.staffName} • {selectedDelivery.date} ({selectedDelivery.time})</span>
              </div>
            </div>

            {/* Delivered Items Table */}
            <div>
              <p className="font-bold text-[#0A2540] text-xs mb-1">Delivered Bottles:</p>
              <table className="w-full text-left text-xs bg-slate-50 rounded-xl overflow-hidden">
                <thead>
                  <tr className="border-b border-slate-200 text-slate-500 text-[10px]">
                    <th className="p-2 font-semibold">Item</th>
                    <th className="p-2 text-center font-semibold">Qty</th>
                    <th className="p-2 text-center font-semibold">Rate</th>
                    <th className="p-2 text-right font-semibold">Total</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {selectedDelivery.items.map((item, i) => (
                    <tr key={i}>
                      <td className="p-2 font-medium">{item.bottleName}</td>
                      <td className="p-2 text-center font-bold">{item.quantity}</td>
                      <td className="p-2 text-center">Rs. {item.unitPrice}</td>
                      <td className="p-2 text-right font-bold text-[#0A2540]">Rs. {item.lineTotal}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Financial Summary */}
            <div className="p-2.5 rounded-xl bg-white border border-[#CBD5E1] space-y-1 text-xs">
              <div className="flex justify-between font-bold text-[#0A2540]">
                <span>Total Amount:</span>
                <span>Rs. {selectedDelivery.totalAmount.toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-[#10B981] font-semibold">
                <span>Payment Collected ({selectedDelivery.paymentMethod}):</span>
                <span>Rs. {selectedDelivery.paymentCollected.toLocaleString()}</span>
              </div>
              {selectedDelivery.totalAmount > selectedDelivery.paymentCollected && (
                <div className="flex justify-between text-[#EF4444] font-bold">
                  <span>Balance Due (Ledger):</span>
                  <span>Rs. {(selectedDelivery.totalAmount - selectedDelivery.paymentCollected).toLocaleString()}</span>
                </div>
              )}
              <div className="flex justify-between text-slate-500 text-[11px] pt-1 border-t border-slate-100">
                <span>Empty Bottles Returned:</span>
                <strong className="text-[#10B981]">{selectedDelivery.totalEmptyCollected} Bottles</strong>
              </div>
            </div>

            {/* Installment Payments History (Date-wise breakdown of credit delivery payments) */}
            {(() => {
              const deliveryPayments = payments.filter(p => p.deliveryId === selectedDelivery.id);
              if (deliveryPayments.length === 0) return null;
              return (
                <div className="p-2.5 rounded-xl bg-emerald-50/70 border border-emerald-200/80 space-y-1.5 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-[#065F46] text-[11px] flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                      <span>Payment History (تاریخ وار وصولیاں):</span>
                    </span>
                    <span className="text-[10px] text-emerald-700 font-bold">
                      {deliveryPayments.length} Payment{deliveryPayments.length > 1 ? 's' : ''}
                    </span>
                  </div>
                  <div className="space-y-1 max-h-36 overflow-y-auto">
                    {deliveryPayments.map((p, idx) => (
                      <div key={p.id || idx} className="p-1.5 rounded-lg bg-white border border-emerald-200 flex items-center justify-between text-[11px]">
                        <div>
                          <span className="font-bold text-[#0A2540]">{p.date}</span>
                          <span className="text-[10px] text-slate-500 ml-1.5">({p.paymentMethod})</span>
                          {p.transactionRef && <span className="text-[9px] text-slate-400 block">{p.transactionRef}</span>}
                        </div>
                        <strong className="text-emerald-700 font-black">
                          Rs. {p.amount.toLocaleString()}
                        </strong>
                      </div>
                    ))}
                  </div>
                </div>
              );
            })()}

            {/* REQUIREMENT 11: Button inside modal if unpaid */}
            {selectedDelivery.totalAmount > selectedDelivery.paymentCollected && (
              <button
                onClick={() => handleOpenPaymentModal(selectedDelivery)}
                className="w-full py-2 px-3 rounded-xl bg-[#10B981] hover:bg-[#059669] text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-sm transition-colors"
              >
                <CreditCard className="w-4 h-4" />
                <span>Receive Payment for this Delivery (وصولی درج کریں)</span>
              </button>
            )}

            {/* Action Buttons: PDF Preview & Share & Close */}
            <div className="flex items-center gap-2 pt-1">
              <button
                type="button"
                onClick={() => setSlipDelivery(selectedDelivery)}
                className="flex-1 py-2.5 rounded-xl bg-[#0A2540] hover:bg-[#07192C] text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-xs transition-colors"
              >
                <FileText className="w-4 h-4 text-[#00A896]" />
                <span>PDF Slip Preview & Share</span>
              </button>

              <button
                onClick={() => {
                  setSelectedDelivery(null);
                  setShowDeleteConfirm(false);
                }}
                className="py-2.5 px-4 rounded-xl bg-slate-200 text-slate-700 font-bold text-xs"
              >
                Close
              </button>
            </div>

            {/* ADMIN DELETE */}
            {isAdmin && (
              <div className="pt-2 border-t border-red-100">
                {!showDeleteConfirm ? (
                  <button
                    onClick={() => setShowDeleteConfirm(true)}
                    className="w-full py-2 px-3 rounded-xl bg-red-50 hover:bg-red-100 text-red-700 font-bold text-xs flex items-center justify-center gap-2 border border-red-200 transition-colors"
                  >
                    <Trash2 className="w-3.5 h-3.5 text-red-600" />
                    <span>Delete Delivery (صرف ایڈمن)</span>
                  </button>
                ) : (
                  <div className="p-3 rounded-2xl bg-red-50 border border-red-300 space-y-2 text-center animate-in fade-in">
                    <AlertTriangle className="w-6 h-6 text-red-600 mx-auto" />
                    <p className="font-bold text-red-800 text-xs">
                      Delete Delivery #{selectedDelivery.deliveryNumber}?
                    </p>
                    <p className="text-[11px] text-red-700">
                      Customer debt and empty bottle balance will be automatically reversed.
                    </p>
                    <div className="flex items-center gap-2 pt-1">
                      <button
                        onClick={() => setShowDeleteConfirm(false)}
                        className="flex-1 py-1.5 rounded-xl bg-slate-200 text-slate-700 font-bold text-[11px]"
                      >
                        Cancel
                      </button>
                      <button
                        onClick={handleDeleteCurrentDelivery}
                        className="flex-1 py-1.5 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold text-[11px]"
                      >
                        Yes, Delete
                      </button>
                    </div>
                  </div>
                )}
              </div>
            )}

          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* REQUIREMENT 11: DEDICATED PAYMENT MODAL FOR CREDIT DELIVERIES */}
      {/* ========================================================================= */}
      {paymentDelivery && (
        <div className="fixed inset-0 z-60 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl w-full max-w-sm p-5 shadow-2xl space-y-3.5 animate-in fade-in">
            <div className="flex items-center justify-between border-b pb-2">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-xl bg-emerald-50 text-emerald-700">
                  <CreditCard className="w-5 h-5 text-emerald-600" />
                </div>
                <div>
                  <h3 className="font-black text-sm text-[#0A2540]">Record Delivery Payment</h3>
                  <p className="text-[10px] text-slate-500">ادائیگی وصولی درج کریں</p>
                </div>
              </div>
              <button 
                onClick={() => setPaymentDelivery(null)}
                className="p-1 rounded-full bg-slate-100 text-slate-500 hover:bg-slate-200"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-2.5 rounded-xl bg-[#F0F7FB] border border-[#CBD5E1]/60 text-xs space-y-1">
              <div className="flex justify-between">
                <span className="text-slate-500">Customer:</span>
                <strong className="text-[#0A2540]">{paymentDelivery.customerName}</strong>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Delivery #:</span>
                <span className="font-mono font-bold text-slate-700">{paymentDelivery.deliveryNumber}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Total Invoice:</span>
                <span>Rs. {paymentDelivery.totalAmount.toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Already Paid:</span>
                <span className="text-emerald-700 font-bold">Rs. {paymentDelivery.paymentCollected.toLocaleString()}</span>
              </div>
              <div className="flex justify-between pt-1 border-t border-slate-200 font-bold text-red-600">
                <span>Remaining Due:</span>
                <span>Rs. {(paymentDelivery.totalAmount - paymentDelivery.paymentCollected).toLocaleString()}</span>
              </div>
            </div>

            <form onSubmit={handleRecordPayment} className="space-y-3">
              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">
                  Payment Amount (وصول شدہ رقم) *
                </label>
                <NumericInput
                  value={payAmount}
                  onChange={val => setPayAmount(val)}
                  placeholder="0"
                  className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-3 py-2 text-sm font-black text-[#10B981] text-center"
                />
                <div className="flex justify-between text-[10px] text-slate-400 mt-1">
                  <span>Allows partial or full payment</span>
                  <button 
                    type="button"
                    onClick={() => setPayAmount(paymentDelivery.totalAmount - paymentDelivery.paymentCollected)}
                    className="text-[#028090] font-bold underline"
                  >
                    Full Balance
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">
                  Payment Date (تاریخ ادائیگی) *
                </label>
                <input
                  type="date"
                  value={payDate}
                  onChange={e => setPayDate(e.target.value)}
                  className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-2.5 py-1.5 text-xs font-semibold text-[#0A2540]"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">
                  Payment Method
                </label>
                <select
                  value={payMethod}
                  onChange={e => setPayMethod(e.target.value as Payment['paymentMethod'])}
                  className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-2.5 py-2 text-xs font-semibold text-[#0A2540]"
                >
                  <option value="CASH">Cash (نقد)</option>
                  <option value="JAZZCASH">JazzCash</option>
                  <option value="EASYPAISA">Easypaisa</option>
                  <option value="BANK_TRANSFER">Bank Transfer</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">
                  Transaction Reference (اختیاری)
                </label>
                <input
                  type="text"
                  value={payTxnRef}
                  onChange={e => setPayTxnRef(e.target.value)}
                  placeholder="e.g. TID / Receipt / Bank slip #"
                  className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-3 py-2 text-xs text-[#0F172A]"
                />
              </div>

              <div className="flex items-center gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setPaymentDelivery(null)}
                  className="flex-1 py-2.5 rounded-xl bg-slate-200 text-slate-700 font-bold text-xs"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={paySubmitting}
                  className="flex-1 py-2.5 rounded-xl bg-[#10B981] hover:bg-[#059669] text-white font-bold text-xs transition-colors shadow-xs"
                >
                  {paySubmitting ? 'Saving...' : 'Confirm Payment'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* REQUIREMENT 10: ADMIN EDIT DELIVERY MODAL */}
      {/* ========================================================================= */}
      {editingDelivery && (
        <div className="fixed inset-0 z-60 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5">
          <div className="bg-white rounded-3xl w-full max-w-md p-5 shadow-2xl space-y-3.5 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b pb-2">
              <div>
                <h3 className="font-bold text-sm text-[#0A2540]">Edit Delivery Record (صرف ایڈمن)</h3>
                <p className="text-[10px] text-slate-500">{editingDelivery.deliveryNumber} • {editingDelivery.customerName}</p>
              </div>
              <button 
                onClick={() => setEditingDelivery(null)}
                className="p-1 rounded-full bg-slate-100 text-slate-500 hover:bg-slate-200"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveEditedDelivery} className="space-y-3">
              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">Delivery Date</label>
                <input
                  type="date"
                  value={editDate}
                  onChange={e => setEditDate(e.target.value)}
                  className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-3 py-2 text-xs font-semibold text-[#0A2540]"
                />
              </div>

              {/* Items editing */}
              <div className="space-y-2">
                <label className="block text-[11px] font-bold text-slate-600">Delivered Items & Quantities</label>
                {editItems.map((item, idx) => (
                  <div key={idx} className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1.5">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-xs text-[#0A2540]">{item.bottleName}</span>
                      <span className="text-xs font-bold text-slate-600">Total: Rs. {item.lineTotal}</span>
                    </div>
                    <div className="grid grid-cols-3 gap-2">
                      <div>
                        <span className="text-[9px] text-slate-500 block">Full Delivered</span>
                        <NumericInput
                          value={item.quantity}
                          onChange={val => {
                            const newQty = Math.max(0, val);
                            setEditItems(prev => prev.map((it, i) => i === idx ? {
                              ...it,
                              quantity: newQty,
                              lineTotal: it.unitPrice * newQty
                            } : it));
                          }}
                          placeholder="0"
                          className="w-full bg-white border border-slate-300 rounded-lg p-1 text-center font-bold text-xs"
                        />
                      </div>
                      <div>
                        <span className="text-[9px] text-slate-500 block">Unit Rate</span>
                        <NumericInput
                          value={item.unitPrice}
                          onChange={val => {
                            setEditItems(prev => prev.map((it, i) => i === idx ? {
                              ...it,
                              unitPrice: val,
                              lineTotal: val * it.quantity
                            } : it));
                          }}
                          placeholder="Rate"
                          className="w-full bg-white border border-slate-300 rounded-lg p-1 text-center font-bold text-xs"
                        />
                      </div>
                      <div>
                        <span className="text-[9px] text-slate-500 block">Empties In</span>
                        <NumericInput
                          value={item.emptyCollected}
                          onChange={val => {
                            setEditItems(prev => prev.map((it, i) => i === idx ? {
                              ...it,
                              emptyCollected: Math.max(0, val)
                            } : it));
                          }}
                          placeholder="0"
                          className="w-full bg-white border border-slate-300 rounded-lg p-1 text-center font-bold text-xs text-emerald-600"
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Delivery Charges */}
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-600">Delivery Charges (Rs.):</span>
                <NumericInput
                  value={editCharges}
                  onChange={val => setEditCharges(val)}
                  placeholder="0"
                  className="w-24 bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-2 py-1 text-right font-bold text-xs"
                />
              </div>

              {/* Payment Collected & Method */}
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 mb-1">Payment Collected</label>
                  <NumericInput
                    value={editPaymentCollected}
                    onChange={val => setEditPaymentCollected(val)}
                    placeholder="0"
                    className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-3 py-2 text-xs font-black text-emerald-700"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 mb-1">Payment Method</label>
                  <select
                    value={editPaymentMethod}
                    onChange={e => setEditPaymentMethod(e.target.value)}
                    className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-2 py-2 text-xs font-semibold"
                  >
                    <option value="Cash">Cash</option>
                    <option value="JazzCash">JazzCash</option>
                    <option value="Easypaisa">Easypaisa</option>
                    <option value="Bank">Bank</option>
                    <option value="Unpaid">Unpaid</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">Notes</label>
                <input
                  type="text"
                  value={editNotes}
                  onChange={e => setEditNotes(e.target.value)}
                  className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-3 py-2 text-xs"
                />
              </div>

              <div className="p-2.5 rounded-xl bg-amber-50 border border-amber-200 text-[10px] text-amber-900 leading-relaxed">
                Saving will automatically recalculate customer outstanding balance, bottle inventory, and account ledger.
              </div>

              <div className="flex items-center gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setEditingDelivery(null)}
                  className="flex-1 py-2.5 rounded-xl bg-slate-200 text-slate-700 font-bold text-xs"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-[#0A2540] hover:bg-[#028090] text-white font-bold text-xs shadow-xs transition-colors"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* PDF SLIP PREVIEW & SHARE MODAL */}
      {slipDelivery && (
        <DeliverySlipModal
          delivery={slipDelivery}
          onClose={() => setSlipDelivery(null)}
        />
      )}

    </div>
  );
};
