import React, { useState } from 'react';
import { useWaterApp } from '../../context/WaterAppContext';
import { 
  BarChart3, 
  TrendingUp, 
  Download, 
  RotateCcw, 
  Users, 
  Truck, 
  Share2,
  Calendar,
  Layers,
  DollarSign
} from 'lucide-react';

export const ReportsView: React.FC = () => {
  const { 
    deliveries, 
    payments, 
    expenses, 
    customers, 
    bottleInventory, 
    businessProfile 
  } = useWaterApp();

  const [dateRange, setDateRange] = useState<'TODAY' | 'MONTH' | 'ALL'>('ALL');

  const todayStr = new Date().toISOString().split('T')[0];
  const currentMonthStr = todayStr.slice(0, 7);

  // Filter datasets
  const filteredDeliveries = deliveries.filter(d => {
    if (dateRange === 'TODAY') return d.date === todayStr;
    if (dateRange === 'MONTH') return d.date.startsWith(currentMonthStr);
    return true;
  });

  const filteredPayments = payments.filter(p => {
    if (dateRange === 'TODAY') return p.date === todayStr;
    if (dateRange === 'MONTH') return p.date.startsWith(currentMonthStr);
    return true;
  });

  const filteredExpenses = expenses.filter(e => {
    if (dateRange === 'TODAY') return e.date === todayStr;
    if (dateRange === 'MONTH') return e.date.startsWith(currentMonthStr);
    return true;
  });

  // Financial Calculations
  const totalSalesRevenue = filteredDeliveries.reduce((sum, d) => sum + d.totalAmount, 0);
  const totalCollections = filteredPayments.reduce((sum, p) => sum + p.amount, 0);
  const totalOpexExpenses = filteredExpenses
    .filter(e => e.expenseType === 'OPEX')
    .reduce((sum, e) => sum + e.amount, 0);

  const totalBottlesDelivered = filteredDeliveries.reduce((sum, d) => sum + d.totalFullDelivered, 0);
  const totalEmptiesReturned = filteredDeliveries.reduce((sum, d) => sum + d.totalEmptyCollected, 0);
  const recoveryRate = totalBottlesDelivered > 0 
    ? ((totalEmptiesReturned / totalBottlesDelivered) * 100).toFixed(1) 
    : '100.0';

  const totalMarketDebt = customers.reduce((sum, c) => sum + (c.currentBalance > 0 ? c.currentBalance : 0), 0);
  const netProfit = totalSalesRevenue - totalOpexExpenses;

  // Export CSV
  const handleExportCSV = () => {
    const rows = [
      ["Date", "Delivery Number", "Customer Name", "Area", "Bottles Delivered", "Empties Collected", "Amount (Rs.)", "Payment Collected", "Method"],
      ...filteredDeliveries.map(d => [
        d.date,
        d.deliveryNumber,
        d.customerName,
        d.customerArea,
        d.totalFullDelivered,
        d.totalEmptyCollected,
        d.totalAmount,
        d.paymentCollected,
        d.paymentMethod
      ])
    ];

    const csvContent = "data:text/csv;charset=utf-8," + rows.map(e => e.join(",")).join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `aab_e_baraan_report_${dateRange.toLowerCase()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-3.5 pb-24 text-xs">
      
      {/* 1. Header with Period Switcher */}
      <div className="bg-white border border-[#CBD5E1]/70 rounded-2xl p-4 shadow-xs space-y-3">
        {/* Official Brand Logo on Reports */}
        <div className="flex items-center gap-3 pb-2 border-b border-slate-100">
          <img 
            src="/aab_e_baraan_logo.png" 
            alt="Aab-e-Baraan" 
            className="h-12 object-contain" 
          />
          <div>
            <h2 className="text-sm font-bold text-[#0A2540]">
              {businessProfile.businessName}
            </h2>
            <p className="text-[11px] text-[#00A896] font-urdu font-semibold">
              پلانٹ سیلز و منافع سمری رپورٹ
            </p>
          </div>
        </div>

        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-xs font-bold text-[#0A2540]">
              Operational & P&L Reports
            </h3>
            <p className="text-[10px] text-[#475569]">
              سیلز، اخراجات، خالی بوتلیں اور خالص منافع کا خلاصہ
            </p>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={handleExportCSV}
              className="p-1.5 rounded-lg bg-[#E8F4F8] text-[#0A2540] font-bold text-[11px] flex items-center gap-1"
              title="Download CSV"
            >
              <Download className="w-3.5 h-3.5" />
              <span>CSV</span>
            </button>
          </div>
        </div>

        {/* Filter Chips */}
        <div className="flex items-center gap-1.5">
          {(['TODAY', 'MONTH', 'ALL'] as const).map(r => (
            <button
              key={r}
              onClick={() => setDateRange(r)}
              className={`flex-1 py-1.5 rounded-xl font-bold text-[11px] transition-all ${
                dateRange === r ? 'bg-[#0A2540] text-white shadow-xs' : 'bg-[#F0F7FB] text-slate-700'
              }`}
            >
              {r === 'TODAY' ? 'Today (آج)' : r === 'MONTH' ? 'This Month (ماہانہ)' : 'All Records (تمام)'}
            </button>
          ))}
        </div>
      </div>

      {/* 2. Primary KPI Metric Cards (2x2) */}
      <div className="grid grid-cols-2 gap-2.5">
        <div className="bg-white border border-[#CBD5E1]/70 rounded-2xl p-3.5 shadow-xs">
          <span className="text-[10px] text-slate-400 block font-semibold">Total Sales Revenue</span>
          <strong className="text-base sm:text-lg font-black text-[#0A2540] block mt-1">
            Rs. {totalSalesRevenue.toLocaleString()}
          </strong>
          <span className="text-[10px] text-[#00A896] font-bold">
            {filteredDeliveries.length} Deliveries Dispatched
          </span>
        </div>

        <div className="bg-white border border-[#CBD5E1]/70 rounded-2xl p-3.5 shadow-xs">
          <span className="text-[10px] text-slate-400 block font-semibold">Total Collections</span>
          <strong className="text-base sm:text-lg font-black text-[#10B981] block mt-1">
            Rs. {totalCollections.toLocaleString()}
          </strong>
          <span className="text-[10px] text-[#059669] font-bold">
            {filteredPayments.length} Receipts
          </span>
        </div>

        <div className="bg-white border border-[#CBD5E1]/70 rounded-2xl p-3.5 shadow-xs">
          <span className="text-[10px] text-slate-400 block font-semibold">Plant Expenses (OPEX)</span>
          <strong className="text-base sm:text-lg font-black text-[#EF4444] block mt-1">
            Rs. {totalOpexExpenses.toLocaleString()}
          </strong>
          <span className="text-[10px] text-[#B91C1C] font-bold">
            Daily Operational Outflow
          </span>
        </div>

        <div className="bg-white border border-[#CBD5E1]/70 rounded-2xl p-3.5 shadow-xs">
          <span className="text-[10px] text-slate-400 block font-semibold">Net Operating Margin</span>
          <strong className={`text-base sm:text-lg font-black block mt-1 ${
            netProfit >= 0 ? 'text-[#028090]' : 'text-[#EF4444]'
          }`}>
            Rs. {netProfit.toLocaleString()}
          </strong>
          <span className="text-[10px] text-slate-500 font-bold">
            Accrual Profit
          </span>
        </div>
      </div>

      {/* 3. Operational Indicators */}
      <div className="bg-white border border-[#CBD5E1]/70 rounded-2xl p-4 shadow-xs space-y-3">
        <h3 className="font-bold text-xs text-[#0A2540]">
          Fleet & Market Health Indicators
        </h3>

        <div className="space-y-2">
          {/* Recovery rate bar */}
          <div className="p-3 rounded-xl bg-[#F0F7FB] space-y-1.5">
            <div className="flex justify-between items-center text-xs">
              <span className="font-semibold text-slate-700">Empty Bottle Recovery Rate:</span>
              <strong className="text-sm font-black text-[#00A896]">{recoveryRate}%</strong>
            </div>

            <div className="w-full bg-[#E2E8F0] rounded-full h-2 overflow-hidden">
              <div 
                className="bg-[#00A896] h-full rounded-full transition-all"
                style={{ width: `${Math.min(100, parseFloat(recoveryRate))}%` }}
              />
            </div>

            <div className="flex justify-between text-[10px] text-slate-500">
              <span>Delivered: <strong>{totalBottlesDelivered}</strong></span>
              <span>Empties Returned: <strong>{totalEmptiesReturned}</strong></span>
            </div>
          </div>

          {/* Market Receivables */}
          <div className="p-3 rounded-xl bg-[#FEE2E2]/60 flex items-center justify-between">
            <div>
              <span className="text-[10px] text-[#991B1B] font-bold block">Market Udhaar (بقایا جات)</span>
              <span className="text-xs text-slate-600">Total customer balance across routes</span>
            </div>

            <strong className="text-base font-black text-[#EF4444]">
              Rs. {totalMarketDebt.toLocaleString()}
            </strong>
          </div>
        </div>
      </div>

    </div>
  );
};
