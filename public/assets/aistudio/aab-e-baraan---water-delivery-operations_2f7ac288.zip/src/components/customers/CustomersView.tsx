import React, { useState } from 'react';
import { useWaterApp } from '../../context/WaterAppContext';
import { 
  Search, 
  Plus, 
  Phone, 
  MapPin, 
  MessageCircle, 
  FileText, 
  X, 
  Trash2,
  Calendar,
  Pencil,
  History,
  Contact,
  CheckCircle2,
  Clock,
  ArrowRight,
  TrendingUp,
  AlertCircle
} from 'lucide-react';
import { Customer, CustomerType, PaymentCycle, CustomerRate, RateHistoryEntry, Delivery } from '../../types';
import { NumericInput } from '../common/NumericInput';
import { DeliverySlipModal } from '../deliveries/DeliverySlipModal';

interface CustomersViewProps {
  onCustomerSelect?: (customer: Customer) => void;
  onNavigateToNewDelivery?: (customer: Customer) => void;
  onNavigateToReceivePayment?: (customer: Customer) => void;
}

// Clean phone format helper: removes '-' and spaces, preserving digits and optional leading '+'
export const cleanPhoneDisplay = (phone: string | undefined): string => {
  if (!phone) return '';
  return phone.replace(/[^0-9+]/g, '');
};

export const CustomersView: React.FC<CustomersViewProps> = ({
  onCustomerSelect,
  onNavigateToNewDelivery,
  onNavigateToReceivePayment
}) => {
  const { 
    customers, 
    addCustomer, 
    updateCustomer,
    customerRates, 
    setCustomerPrice, 
    ledgerEntries, 
    deliveries,
    bottleSizes,
    businessProfile,
    deleteCustomer,
    currentUser,
    customerAllocations
  } = useWaterApp();

  const [searchTerm, setSearchTerm] = useState('');
  const [typeFilter, setTypeFilter] = useState<string>('ALL');
  const [showAddModal, setShowAddModal] = useState(false);
  const [selectedCustomerForDetail, setSelectedCustomerForDetail] = useState<Customer | null>(null);
  const [showDeleteCustomerConfirm, setShowDeleteCustomerConfirm] = useState(false);
  const [showRateModal, setShowRateModal] = useState(false);
  
  // Rate history modal
  const [selectedRateForHistory, setSelectedRateForHistory] = useState<CustomerRate | null>(null);

  // Edit Customer Modal state
  const [editingCustomer, setEditingCustomer] = useState<Customer | null>(null);
  const [slipDelivery, setSlipDelivery] = useState<Delivery | null>(null);

  // New Customer Form State
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [hasWhatsapp, setHasWhatsapp] = useState(true);
  const [address, setAddress] = useState('');
  const [area, setArea] = useState('');
  const [type, setType] = useState<CustomerType>('HOME');
  const [cycle, setCycle] = useState<PaymentCycle>('PAY_ON_DELIVERY');
  const [openingBalance, setOpeningBalance] = useState(0);
  const [securityDeposit, setSecurityDeposit] = useState(0);

  // Rate input section state inside customer detail
  const [rateSizeId, setRateSizeId] = useState<string>('');
  const [customRateInput, setCustomRateInput] = useState<number>(0);
  const [rateEffectiveDate, setRateEffectiveDate] = useState<string>(() => new Date().toISOString().split('T')[0]);
  const [rateSaveSuccess, setRateSaveSuccess] = useState(false);

  // Contact Picker API integration (Web Contacts API on mobile + Clipboard & Prompt fallback)
  const handlePickContactForNew = async () => {
    // 1. Try native Web Contacts API if supported (Chrome on Android)
    if (typeof navigator !== 'undefined' && 'contacts' in navigator && 'ContactsManager' in window) {
      try {
        const props = ['name', 'tel'];
        const contacts = await (navigator as any).contacts.select(props, { multiple: false });
        if (contacts && contacts.length > 0) {
          const c = contacts[0];
          if (c.name && c.name[0] && !name) {
            setName(c.name[0]);
          }
          if (c.tel && c.tel.length > 0) {
            setPhone(cleanPhoneDisplay(c.tel[0]));
          }
          return;
        }
      } catch (err) {
        console.log('Contact picker dismissed:', err);
      }
    }

    // 2. Try Clipboard read if available
    if (typeof navigator !== 'undefined' && navigator.clipboard && navigator.clipboard.readText) {
      try {
        const clip = await navigator.clipboard.readText();
        const cleaned = cleanPhoneDisplay(clip);
        if (cleaned && cleaned.length >= 7) {
          setPhone(cleaned);
          alert(`Phone number pasted from clipboard (کلپ بورڈ سے نمبر لگ گیا): ${cleaned}`);
          return;
        }
      } catch {
        // Clipboard restricted
      }
    }

    // 3. Clean prompt fallback
    const inputNum = window.prompt("Enter or paste contact phone number (فون نمبر درج یا پیسٹ کریں):", phone || "0300");
    if (inputNum) {
      setPhone(cleanPhoneDisplay(inputNum));
    }
  };

  const handlePickContactForEdit = async () => {
    if (!editingCustomer) return;

    // 1. Try native Web Contacts API if supported
    if (typeof navigator !== 'undefined' && 'contacts' in navigator && 'ContactsManager' in window) {
      try {
        const props = ['name', 'tel'];
        const contacts = await (navigator as any).contacts.select(props, { multiple: false });
        if (contacts && contacts.length > 0) {
          const c = contacts[0];
          setEditingCustomer({
            ...editingCustomer,
            name: c.name && c.name[0] ? c.name[0] : editingCustomer.name,
            phone: c.tel && c.tel.length > 0 ? cleanPhoneDisplay(c.tel[0]) : editingCustomer.phone
          });
          return;
        }
      } catch (err) {
        console.log('Contact picker dismissed:', err);
      }
    }

    // 2. Try Clipboard read
    if (typeof navigator !== 'undefined' && navigator.clipboard && navigator.clipboard.readText) {
      try {
        const clip = await navigator.clipboard.readText();
        const cleaned = cleanPhoneDisplay(clip);
        if (cleaned && cleaned.length >= 7) {
          setEditingCustomer({
            ...editingCustomer,
            phone: cleaned
          });
          alert(`Phone number pasted from clipboard: ${cleaned}`);
          return;
        }
      } catch {
        // Clipboard restricted
      }
    }

    // 3. Fallback prompt
    const inputNum = window.prompt("Enter or paste phone number (فون نمبر درج یا پیسٹ کریں):", editingCustomer.phone || "0300");
    if (inputNum) {
      setEditingCustomer({
        ...editingCustomer,
        phone: cleanPhoneDisplay(inputNum)
      });
    }
  };

  const handleAddCustomer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !phone.trim()) return;

    const cleaned = cleanPhoneDisplay(phone);
    addCustomer({
      name: name.trim(),
      phone: cleaned,
      whatsapp: hasWhatsapp ? cleaned : '',
      hasWhatsapp,
      address: address.trim(),
      area: area.trim() || 'General',
      type,
      paymentCycle: cycle,
      registrationDate: new Date().toISOString().split('T')[0],
      openingBalance,
      creditLimit: 5000,
      bottleDeposit: securityDeposit,
      securityDeposit,
      notes: '',
      active: true,
      createdBy: currentUser.name
    });

    setShowAddModal(false);
    setName('');
    setPhone('');
    setHasWhatsapp(true);
    setAddress('');
    setArea('');
    setOpeningBalance(0);
    setSecurityDeposit(0);
  };

  const handleSaveEditedCustomer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingCustomer) return;

    const cleaned = cleanPhoneDisplay(editingCustomer.phone);
    const updated: Customer = {
      ...editingCustomer,
      name: editingCustomer.name.trim(),
      phone: cleaned,
      whatsapp: editingCustomer.hasWhatsapp ? cleaned : cleanPhoneDisplay(editingCustomer.whatsapp),
      address: editingCustomer.address.trim(),
      area: editingCustomer.area.trim() || 'General'
    };

    updateCustomer(updated);
    setSelectedCustomerForDetail(updated);
    setEditingCustomer(null);
  };

  // Keep detail modal synced when customers list updates
  const activeDetailCust = selectedCustomerForDetail 
    ? customers.find(c => c.id === selectedCustomerForDetail.id) || selectedCustomerForDetail
    : null;

  // Active customer rates
  const currentCustRates = activeDetailCust
    ? customerRates.filter(r => r.customerId === activeDetailCust.id)
    : [];

  const handleSaveRate = () => {
    if (!activeDetailCust || !rateSizeId) return;
    setCustomerPrice(activeDetailCust.id, rateSizeId, customRateInput, rateEffectiveDate);
    setRateSaveSuccess(true);
    setShowRateModal(false);
    setTimeout(() => setRateSaveSuccess(false), 2500);
  };

  const filteredCustomers = customers.filter(c => {
    const matchesSearch = 
      c.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      c.customerCode.toLowerCase().includes(searchTerm.toLowerCase()) ||
      cleanPhoneDisplay(c.phone).includes(searchTerm.replace(/[^0-9+]/g, '')) ||
      c.area.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesType = typeFilter === 'ALL' || c.type === typeFilter;
    return matchesSearch && matchesType;
  });

  return (
    <div className="space-y-3.5 pb-24 text-xs">
      
      {/* Search and Customer Type Filter */}
      <div className="space-y-2">
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Search code, name, phone, area..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3 py-2 bg-white border border-[#CBD5E1] rounded-xl text-xs text-[#0F172A] focus:outline-none focus:border-[#0A2540]"
          />
        </div>

        {/* Filter Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar">
          {(['ALL', 'HOME', 'OFFICE', 'RESTAURANT', 'SHOP'] as const).map(t => (
            <button
              key={t}
              onClick={() => setTypeFilter(t)}
              className={`px-3 py-1.5 rounded-full font-bold whitespace-nowrap text-[11px] transition-all ${
                typeFilter === t
                  ? 'bg-[#0A2540] text-white shadow-sm'
                  : 'bg-white text-slate-700 border border-[#CBD5E1]'
              }`}
            >
              {t === 'ALL' ? 'All Customers (سب)' : t}
            </button>
          ))}
        </div>
      </div>

      {/* Customer Count Header */}
      <div className="flex items-center justify-between px-1 text-[11px] text-slate-500 font-semibold">
        <span>Showing {filteredCustomers.length} Customers</span>
        <button
          onClick={() => setShowAddModal(true)}
          className="text-[#028090] font-bold flex items-center gap-1 hover:underline"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Add Customer (نیا گاہک)</span>
        </button>
      </div>

      {/* Customers List Cards */}
      <div className="space-y-2">
        {filteredCustomers.length === 0 ? (
          <div className="bg-white rounded-2xl p-8 text-center border border-dashed border-slate-300 text-slate-500">
            <p className="font-bold text-sm text-slate-700">No Customers Found</p>
            <p className="text-[11px] mt-1">Tap &quot;Add Customer&quot; above to register your first delivery account.</p>
          </div>
        ) : (
          filteredCustomers.map(cust => (
            <div
              key={cust.id}
              className="bg-white rounded-2xl p-3.5 border border-[#CBD5E1]/80 shadow-xs space-y-2.5 transition-all hover:border-[#028090]"
            >
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-mono font-bold px-1.5 py-0.5 rounded-md bg-[#E8F4F8] text-[#0A2540]">
                      {cust.customerCode}
                    </span>
                    <span className="text-[10px] font-semibold text-slate-500 uppercase">
                      {cust.type}
                    </span>
                    {cust.hasWhatsapp && (
                      <span className="inline-flex items-center text-[10px] text-emerald-700 bg-emerald-50 px-1.5 py-0.2 rounded font-medium">
                        <MessageCircle className="w-2.5 h-2.5 mr-0.5 inline text-emerald-600" /> WhatsApp
                      </span>
                    )}
                  </div>
                  <h4 
                    onClick={() => {
                      setSelectedCustomerForDetail(cust);
                      setRateSizeId(bottleSizes[0]?.id || '');
                    }}
                    className="font-bold text-sm text-[#0A2540] hover:text-[#028090] cursor-pointer mt-0.5"
                  >
                    {cust.name}
                  </h4>
                  <p className="text-[11px] text-slate-500 flex items-center gap-1 mt-0.5">
                    <Phone className="w-3 h-3 text-slate-400" />
                    <span>{cleanPhoneDisplay(cust.phone)}</span>
                    <span className="mx-1">•</span>
                    <MapPin className="w-3 h-3 text-slate-400" />
                    <span className="truncate max-w-[150px]">{cust.area || cust.address}</span>
                  </p>
                </div>

                <div className="text-right">
                  <span className="text-[10px] text-slate-500 block">Balance Due</span>
                  <span className={`text-xs font-black ${
                    cust.currentBalance > 0 ? 'text-[#EF4444]' : 'text-[#10B981]'
                  }`}>
                    Rs. {cust.currentBalance.toLocaleString()}
                  </span>
                  <div className="text-[10px] text-slate-500 mt-0.5">
                    <span>Bottles: </span>
                    <strong className="text-[#0A2540]">{cust.emptyBottlesOwed}</strong>
                  </div>
                </div>
              </div>

              {/* Action Buttons Row */}
              <div className="flex items-center justify-between pt-1 border-t border-slate-100">
                <button
                  onClick={() => {
                    setSelectedCustomerForDetail(cust);
                    setRateSizeId(bottleSizes[0]?.id || '');
                  }}
                  className="py-1 px-2.5 rounded-lg bg-[#F0F7FB] text-[#0A2540] text-[11px] font-bold flex items-center gap-1 hover:bg-[#E8F4F8]"
                >
                  <FileText className="w-3 h-3 text-[#028090]" />
                  <span>Details & Ledger</span>
                </button>

                <div className="flex items-center gap-1.5">
                  {onNavigateToNewDelivery && (
                    <button
                      onClick={() => onNavigateToNewDelivery(cust)}
                      className="py-1 px-2.5 rounded-lg bg-[#0A2540] text-white text-[11px] font-bold"
                    >
                      Delivery
                    </button>
                  )}

                  {onNavigateToReceivePayment && (
                    <button
                      onClick={() => onNavigateToReceivePayment(cust)}
                      className="py-1 px-2.5 rounded-lg bg-[#10B981] text-white text-[11px] font-bold"
                    >
                      Payment
                    </button>
                  )}

                  {cust.hasWhatsapp && (
                    <a
                      href={`https://wa.me/${cleanPhoneDisplay(cust.whatsapp || cust.phone)}?text=${encodeURIComponent(
                        `Assalam-o-Alaikum ${cust.name}, this is from ${businessProfile.businessName}. Your outstanding water delivery balance is Rs. ${cust.currentBalance}. Kindly clear at earliest convenience. Thank you.`
                      )}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="p-1.5 rounded-lg bg-[#D1FAE5] text-[#065F46] hover:bg-[#A7F3D0]"
                      title="Send WhatsApp Reminder"
                    >
                      <MessageCircle className="w-3.5 h-3.5" />
                    </a>
                  )}

                  <a
                    href={`tel:${cleanPhoneDisplay(cust.phone)}`}
                    className="p-1.5 rounded-lg bg-slate-100 text-slate-700 hover:bg-slate-200"
                    title="Call"
                  >
                    <Phone className="w-3.5 h-3.5" />
                  </a>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* ========================================================================= */}
      {/* CUSTOMER DETAIL MODAL (With Edit Button, Agreed Rates, and Ledger directly after) */}
      {/* ========================================================================= */}
      {activeDetailCust && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5">
          <div className="bg-white rounded-3xl w-full max-w-lg p-5 shadow-2xl space-y-4 max-h-[92vh] overflow-y-auto">
            
            {/* Modal Header */}
            <div className="flex items-start justify-between border-b border-slate-100 pb-3">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-[#E8F4F8] text-[#0A2540]">
                    {activeDetailCust.customerCode}
                  </span>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-100 text-slate-700 uppercase">
                    {activeDetailCust.type}
                  </span>
                  {activeDetailCust.hasWhatsapp && (
                    <span className="inline-flex items-center text-[10px] text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full font-medium">
                      <MessageCircle className="w-2.5 h-2.5 mr-1 text-emerald-600" /> WhatsApp
                    </span>
                  )}
                </div>
                <h3 className="text-base font-black text-[#0A2540] mt-1">
                  {activeDetailCust.name}
                </h3>
                <p className="text-slate-500 text-[11px] mt-0.5">
                  Phone: <strong>{cleanPhoneDisplay(activeDetailCust.phone)}</strong> • {activeDetailCust.area || activeDetailCust.address}
                </p>
                {activeDetailCust.lastEditedAt && (
                  <p className="text-[10px] text-slate-400 mt-0.5">
                    Last edited by {activeDetailCust.lastEditedBy || 'Admin'} on {new Date(activeDetailCust.lastEditedAt).toLocaleDateString()}
                  </p>
                )}
              </div>

              <div className="flex items-center gap-1.5">
                {/* REQUIREMENT 1.1: Edit Customer Button for Admin */}
                {currentUser.role === 'ADMIN' && (
                  <button
                    onClick={() => setEditingCustomer(activeDetailCust)}
                    className="py-1 px-2.5 rounded-xl bg-[#0A2540] hover:bg-[#028090] text-white text-[11px] font-bold flex items-center gap-1 shadow-xs transition-colors"
                    title="Edit Customer Information (صرف ایڈمن)"
                  >
                    <Pencil className="w-3 h-3" />
                    <span>Edit</span>
                  </button>
                )}
                <button
                  onClick={() => {
                    setSelectedCustomerForDetail(null);
                    setShowDeleteCustomerConfirm(false);
                  }}
                  className="p-1 rounded-full bg-slate-100 text-slate-500 hover:bg-slate-200"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Financial Summary Cards */}
            <div className="grid grid-cols-3 gap-2 text-center">
              <div className="p-2.5 rounded-xl bg-[#F0F7FB]">
                <span className="text-[10px] text-slate-500 block">Balance Due</span>
                <strong className={`text-xs sm:text-sm font-black ${
                  activeDetailCust.currentBalance > 0 ? "text-[#EF4444]" : "text-[#10B981]"
                }`}>
                  Rs. {activeDetailCust.currentBalance.toLocaleString()}
                </strong>
              </div>
              <div className="p-2.5 rounded-xl bg-[#F0F7FB]">
                <span className="text-[10px] text-slate-500 block">Total Empties Held</span>
                <strong className="text-xs sm:text-sm font-black text-[#0A2540]">
                  {activeDetailCust.emptyBottlesOwed} Pcs
                </strong>
              </div>
              <div className="p-2.5 rounded-xl bg-[#F0F7FB]">
                <span className="text-[10px] text-slate-500 block">Security Deposit</span>
                <strong className="text-xs sm:text-sm font-black text-[#10B981]">
                  Rs. {activeDetailCust.securityDeposit.toLocaleString()}
                </strong>
              </div>
            </div>

            {/* Size-wise Held Bottles (Only Multiple-Time Returnable Bottles) */}
            <div className="p-3 rounded-2xl bg-amber-50/80 border border-amber-200/80 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-bold text-[#0A2540] text-xs flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-amber-600" />
                  <span>Held Bottles By Size:</span>
                </span>
                <span className="text-[10px] font-bold text-amber-900 bg-amber-100 px-2.5 py-0.5 rounded-full border border-amber-200">
                  Total Held: {activeDetailCust.emptyBottlesOwed} Pcs
                </span>
              </div>
              <div className="grid grid-cols-2 gap-2 pt-0.5">
                {bottleSizes
                  .filter(bs => bs.usageType === 'MULTIPLE_TIME' || bs.isReturnableBottle)
                  .map(bs => {
                    const alloc = customerAllocations.find(a => a.customerId === activeDetailCust.id && a.bottleSizeId === bs.id);
                    const held = alloc ? alloc.emptyHeld : 0;
                    return (
                      <div key={bs.id} className="p-2 rounded-xl bg-white border border-amber-200 flex items-center justify-between shadow-2xs">
                        <span className="font-bold text-[11px] text-[#0A2540]">{bs.name}</span>
                        <span className={`font-black text-xs ${held > 0 ? 'text-[#EF4444]' : 'text-slate-500'}`}>
                          {held} Pcs
                        </span>
                      </div>
                    );
                  })}
              </div>
            </div>

            {/* ============================================================== */}
            {/* SECTION 2: AGREED CUSTOM BOTTLE RATES (Requirement 2 & Refinement) */}
            {/* ============================================================== */}
            <div className="p-3.5 rounded-2xl bg-[#F0F7FB] border border-[#CBD5E1]/70 space-y-3">
              <div className="flex items-center justify-between flex-wrap gap-2">
                <div>
                  <h4 className="font-bold text-[#0A2540] text-xs flex items-center gap-1.5">
                    <span>Agreed Custom Rates (طے شدہ بوتل ریٹ)</span>
                  </h4>
                  <p className="text-[10px] text-slate-500">
                    Set agreed rates per bottle size. Applied automatically in deliveries.
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  {rateSaveSuccess && (
                    <span className="text-[10px] text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full font-bold animate-in fade-in">
                      Rate Saved ✓
                    </span>
                  )}
                  {/* Dedicated button to open Agreed Customer Rate modal */}
                  <button
                    onClick={() => {
                      const firstSize = bottleSizes[0];
                      const existingRate = firstSize ? currentCustRates.find(r => r.bottleSizeId === firstSize.id) : null;
                      setRateSizeId(firstSize?.id || '');
                      setCustomRateInput(existingRate ? existingRate.customPrice : 0);
                      setRateEffectiveDate(new Date().toISOString().split('T')[0]);
                      setShowRateModal(true);
                    }}
                    className="py-1.5 px-3 rounded-xl bg-[#0A2540] hover:bg-[#028090] text-white font-bold text-xs flex items-center gap-1.5 transition-colors shadow-xs"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Set Agreed Rate (طے شدہ ریٹ شامل کریں)</span>
                  </button>
                </div>
              </div>

              {/* Requirement 2.1: List of agreed rates below input section */}
              <div className="space-y-1.5">
                <span className="text-[11px] font-bold text-slate-700 block">Current Agreed Rates Table:</span>
                <div className="border border-[#CBD5E1] rounded-xl overflow-x-auto bg-white">
                  <table className="w-full min-w-[460px] text-left text-[11px]">
                    <thead className="bg-slate-100 text-slate-600 font-bold">
                      <tr>
                        <th className="p-2">Bottle Size</th>
                        <th className="p-2 text-right">Agreed Rate</th>
                        <th className="p-2">Effective From</th>
                        <th className="p-2 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {bottleSizes.map(bs => {
                        const rateRec = currentCustRates.find(r => r.bottleSizeId === bs.id);
                        const price = rateRec ? rateRec.customPrice : 0;
                        const hasRate = rateRec && rateRec.isAssigned && price > 0;
                        const effDate = rateRec?.appliedDate || 'Not set';

                        return (
                          <tr key={bs.id} className="hover:bg-slate-50/80">
                            <td className="p-2 font-bold text-[#0A2540]">
                              {bs.name}
                            </td>
                            <td className="p-2 text-right">
                              {hasRate ? (
                                <span className="font-black text-[#0A2540] text-xs">
                                  Rs. {price}
                                </span>
                              ) : (
                                <span className="text-amber-700 font-semibold bg-amber-50 px-1.5 py-0.5 rounded text-[10px]">
                                  Rs. 0 (Not Set)
                                </span>
                              )}
                            </td>
                            <td className="p-2 text-[10px] text-slate-500">
                              {effDate}
                            </td>
                            <td className="p-2 text-right space-x-1 whitespace-nowrap">
                              <button
                                onClick={() => {
                                  setRateSizeId(bs.id);
                                  setCustomRateInput(price);
                                  setRateEffectiveDate(rateRec?.appliedDate || new Date().toISOString().split('T')[0]);
                                  setShowRateModal(true);
                                }}
                                className="px-2.5 py-1 rounded-lg bg-slate-100 text-[#0A2540] hover:bg-slate-200 font-bold text-[10px]"
                                title="Change Rate"
                              >
                                Edit (تبدیل کریں)
                              </button>
                              {rateRec && rateRec.rateHistory && rateRec.rateHistory.length > 0 && (
                                <button
                                  onClick={() => setSelectedRateForHistory(rateRec)}
                                  className="px-2 py-1 rounded-lg bg-[#E8F4F8] text-[#028090] hover:bg-[#D5EBF3] font-bold text-[10px] inline-flex items-center gap-0.5"
                                  title="View Rate Change History"
                                >
                                  <History className="w-2.5 h-2.5" />
                                  <span>History ({rateRec.rateHistory.length})</span>
                                </button>
                              )}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>

            {/* ============================================================== */}
            {/* SECTION 4: CUSTOMER ACCOUNT LEDGER (Immediately after Agreed Rates) */}
            {/* ============================================================== */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <h4 className="font-bold text-[#0A2540] text-xs flex items-center gap-1.5">
                  <FileText className="w-3.5 h-3.5 text-[#028090]" />
                  <span>Customer Account Ledger (گاہک کھاتہ تفصیل)</span>
                </h4>
                <span className="text-[10px] text-slate-500">
                  Total Transactions: {ledgerEntries.filter(l => l.customerId === activeDetailCust.id).length}
                </span>
              </div>

              <div className="border border-[#CBD5E1] rounded-2xl overflow-x-auto overflow-y-auto max-h-60 bg-white">
                <table className="w-full min-w-[520px] text-left text-[11px]">
                  <thead className="bg-[#F0F7FB] text-slate-600 sticky top-0 font-bold z-10 border-b border-slate-200">
                    <tr>
                      <th className="p-2">Date / Type</th>
                      <th className="p-2">Description & Details</th>
                      <th className="p-2 text-right">Debit (+)</th>
                      <th className="p-2 text-right">Credit (-)</th>
                      <th className="p-2 text-right">Balance</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {ledgerEntries.filter(l => l.customerId === activeDetailCust.id).length === 0 ? (
                      <tr>
                        <td colSpan={5} className="p-4 text-center text-slate-400">
                          No ledger transactions recorded yet.
                        </td>
                      </tr>
                    ) : (
                      ledgerEntries.filter(l => l.customerId === activeDetailCust.id).map(entry => {
                        // Attempt to match with delivery for richer bottle-wise display
                        const matchedDelivery = deliveries.find(d => d.deliveryNumber === entry.referenceNumber);

                        return (
                          <tr key={entry.id} className="hover:bg-slate-50/70">
                            <td className="p-2 text-slate-500 whitespace-nowrap">
                              <span className="font-semibold text-slate-700 block">{entry.date}</span>
                              <span className={`text-[9px] font-bold px-1.5 py-0.2 rounded uppercase ${
                                entry.type === 'INVOICE' ? 'bg-amber-100 text-amber-800' :
                                entry.type === 'PAYMENT' ? 'bg-emerald-100 text-emerald-800' :
                                'bg-slate-100 text-slate-700'
                              }`}>
                                {entry.type}
                              </span>
                            </td>
                            <td className="p-2 text-[11px]">
                              <p className="font-medium text-[#0F172A]">{entry.description}</p>
                              {matchedDelivery && matchedDelivery.items && (
                                <p className="text-[10px] text-slate-500 mt-0.5">
                                  Bottles: {matchedDelivery.items.map(i => `${i.quantity}x ${i.bottleName} @ Rs.${i.unitPrice}`).join(', ')}
                                  {matchedDelivery.totalEmptyCollected > 0 && ` • Empties: ${matchedDelivery.totalEmptyCollected}`}
                                </p>
                              )}
                              <div className="flex items-center gap-2 mt-0.5">
                                <span className="text-[9px] font-mono text-slate-400">Ref: {entry.referenceNumber}</span>
                                {matchedDelivery && (
                                  <button
                                    type="button"
                                    onClick={() => setSlipDelivery(matchedDelivery)}
                                    className="px-1.5 py-0.5 rounded bg-[#0A2540] hover:bg-[#028090] text-white text-[9px] font-bold inline-flex items-center gap-1 shadow-2xs transition-colors"
                                    title="View & Share PDF Slip"
                                  >
                                    <FileText className="w-2.5 h-2.5 text-[#00A896]" />
                                    <span>PDF Slip</span>
                                  </button>
                                )}
                              </div>
                            </td>
                            <td className="p-2 text-right text-[#EF4444] font-bold whitespace-nowrap">
                              {entry.debitAmount ? `Rs. ${entry.debitAmount.toLocaleString()}` : '-'}
                            </td>
                            <td className="p-2 text-right text-[#10B981] font-bold whitespace-nowrap">
                              {entry.creditAmount ? `Rs. ${entry.creditAmount.toLocaleString()}` : '-'}
                            </td>
                            <td className="p-2 text-right font-black text-[#0A2540] whitespace-nowrap">
                              Rs. {entry.runningBalance.toLocaleString()}
                            </td>
                          </tr>
                        );
                      })
                    )}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Modal Footer Actions */}
            <div className="flex items-center justify-between pt-2 border-t border-slate-100">
              {currentUser.role === 'ADMIN' && (
                <div>
                  {!showDeleteCustomerConfirm ? (
                    <button
                      onClick={() => setShowDeleteCustomerConfirm(true)}
                      className="py-1.5 px-3 rounded-xl bg-red-50 hover:bg-red-100 text-red-700 font-bold text-[11px] flex items-center gap-1.5 border border-red-200 transition-colors"
                    >
                      <Trash2 className="w-3 h-3 text-red-600" />
                      <span>Delete Customer</span>
                    </button>
                  ) : (
                    <div className="p-2.5 rounded-xl bg-red-50 border border-red-300 space-y-1.5 text-left">
                      <p className="font-bold text-red-800 text-[11px]">
                        Delete customer &quot;{activeDetailCust.name}&quot;?
                      </p>
                      {(activeDetailCust.currentBalance > 0 || activeDetailCust.emptyBottlesOwed > 0) && (
                        <p className="text-[10px] text-amber-900 bg-amber-100 p-1 rounded font-semibold">
                          ⚠️ Warning: Unpaid Balance Rs. {activeDetailCust.currentBalance} or {activeDetailCust.emptyBottlesOwed} Empty Bottles!
                        </p>
                      )}
                      <div className="flex items-center gap-2 pt-1">
                        <button
                          onClick={() => setShowDeleteCustomerConfirm(false)}
                          className="py-1 px-2.5 rounded-lg bg-slate-200 text-slate-700 font-bold text-[10px]"
                        >
                          Cancel
                        </button>
                        <button
                          onClick={() => {
                            const res = deleteCustomer(activeDetailCust.id, true);
                            if (res.success) {
                              setShowDeleteCustomerConfirm(false);
                              setSelectedCustomerForDetail(null);
                            } else {
                              alert(res.error || "Failed to delete customer");
                            }
                          }}
                          className="py-1 px-2.5 rounded-lg bg-red-600 hover:bg-red-700 text-white font-bold text-[10px]"
                        >
                          Confirm Delete
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              )}

              <button
                onClick={() => {
                  setSelectedCustomerForDetail(null);
                  setShowDeleteCustomerConfirm(false);
                }}
                className="py-2 px-5 rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold text-xs"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* RATE HISTORY MODAL (Requirement 2.3) */}
      {/* ========================================================================= */}
      {selectedRateForHistory && (
        <div className="fixed inset-0 z-60 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5">
          <div className="bg-white rounded-3xl w-full max-w-md p-5 shadow-2xl space-y-3.5 max-h-[85vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b pb-2">
              <div>
                <h3 className="font-bold text-sm text-[#0A2540]">Rate Change History (ریٹ تاریخچہ)</h3>
                <p className="text-[11px] text-slate-500">{selectedRateForHistory.bottleSizeName}</p>
              </div>
              <button 
                onClick={() => setSelectedRateForHistory(null)}
                className="p-1 rounded-full bg-slate-100 text-slate-500 hover:bg-slate-200"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-2">
              {(!selectedRateForHistory.rateHistory || selectedRateForHistory.rateHistory.length === 0) ? (
                <p className="text-center text-slate-400 py-6 text-xs">No rate changes recorded yet.</p>
              ) : (
                selectedRateForHistory.rateHistory.map((h, idx) => (
                  <div key={h.id || idx} className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="text-[11px] font-bold text-[#0A2540]">
                        Rs. {h.previousRate ?? 0} → <strong className="text-emerald-700 text-xs">Rs. {h.newRate ?? h.rate}</strong>
                      </span>
                      <span className="text-[10px] text-slate-400">{h.appliedFromDate}</span>
                    </div>
                    <div className="text-[10px] text-slate-500 flex items-center justify-between">
                      <span>Effective Delivery Date: <strong>{h.effectiveDate || h.appliedFromDate}</strong></span>
                      <span>By: {h.updatedBy || 'Admin'}</span>
                    </div>
                  </div>
                ))
              )}
            </div>

            <div className="flex justify-end pt-2">
              <button
                onClick={() => setSelectedRateForHistory(null)}
                className="py-1.5 px-4 rounded-xl bg-slate-200 text-slate-700 font-bold text-xs"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* SET / EDIT AGREED RATE MODAL */}
      {/* ========================================================================= */}
      {showRateModal && activeDetailCust && (
        <div className="fixed inset-0 z-60 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl w-full max-w-sm p-5 shadow-2xl space-y-3.5 animate-in fade-in">
            <div className="flex items-center justify-between border-b pb-2">
              <div>
                <h3 className="font-black text-sm text-[#0A2540]">Agreed Bottle Rate (طے شدہ ریٹ)</h3>
                <p className="text-[10px] text-slate-500">{activeDetailCust.name} کے لیے ریٹ مقرر کریں</p>
              </div>
              <button
                onClick={() => setShowRateModal(false)}
                className="p-1 rounded-full bg-slate-100 text-slate-500 hover:bg-slate-200"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-2.5">
              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">Select Bottle Size (بوتل کا سائز) *</label>
                <select
                  value={rateSizeId || (bottleSizes[0]?.id ?? '')}
                  onChange={e => {
                    const sid = e.target.value;
                    setRateSizeId(sid);
                    const r = currentCustRates.find(cr => cr.bottleSizeId === sid);
                    setCustomRateInput(r ? r.customPrice : 0);
                  }}
                  className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-2.5 py-2 text-xs text-[#0A2540] font-semibold"
                >
                  {bottleSizes.map(bs => (
                    <option key={bs.id} value={bs.id}>{bs.name}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">Agreed Rate (طے شدہ ریٹ - روپے) *</label>
                <NumericInput
                  value={customRateInput}
                  onChange={val => setCustomRateInput(val)}
                  placeholder="0"
                  className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-3 py-2 font-black text-sm text-[#0A2540] text-center"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">Effective Date (نافذ العمل تاریخ) *</label>
                <input
                  type="date"
                  value={rateEffectiveDate}
                  onChange={e => setRateEffectiveDate(e.target.value)}
                  className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-2.5 py-2 text-xs text-[#0A2540] font-semibold"
                />
              </div>
            </div>

            <div className="flex items-center gap-2 pt-2 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setShowRateModal(false)}
                className="flex-1 py-2.5 rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold text-xs"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleSaveRate}
                className="flex-1 py-2.5 rounded-xl bg-[#0A2540] hover:bg-[#028090] text-white font-bold text-xs shadow-sm transition-colors"
              >
                Save Rate (محفوظ کریں)
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* EDIT CUSTOMER MODAL (Requirement 1.1 - Admin only) */}
      {/* ========================================================================= */}
      {editingCustomer && (
        <div className="fixed inset-0 z-60 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5">
          <div className="bg-white rounded-3xl w-full max-w-md p-5 shadow-2xl space-y-3.5 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b pb-2">
              <div>
                <h3 className="font-bold text-sm text-[#0A2540]">Edit Customer Information</h3>
                <p className="text-[10px] text-slate-500">{editingCustomer.customerCode} • Admin Permissions</p>
              </div>
              <button 
                onClick={() => setEditingCustomer(null)}
                className="p-1 rounded-full bg-slate-100 text-slate-500 hover:bg-slate-200"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveEditedCustomer} className="space-y-3">
              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">Customer / Shop Name *</label>
                <input
                  required
                  type="text"
                  value={editingCustomer.name}
                  onChange={e => setEditingCustomer({ ...editingCustomer, name: e.target.value })}
                  className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-3 py-2 text-xs text-[#0F172A] font-semibold"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  Mobile Number * (No &quot;-&quot; hyphens)
                </label>
                <div className="flex items-center gap-1.5">
                  <input
                    required
                    type="tel"
                    value={cleanPhoneDisplay(editingCustomer.phone)}
                    onChange={e => setEditingCustomer({ ...editingCustomer, phone: cleanPhoneDisplay(e.target.value) })}
                    placeholder="03001234567"
                    className="flex-1 bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-3 py-2 text-xs font-mono text-[#0F172A]"
                  />
                  <button
                    type="button"
                    onClick={handlePickContactForEdit}
                    className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-[#0A2540] border border-slate-300"
                    title="Select from Phone Contacts"
                  >
                    <Contact className="w-4 h-4 text-[#028090]" />
                  </button>
                </div>
              </div>

              {/* Requirement 1.4: WhatsApp Checkbox */}
              <div className="flex items-center gap-2 p-2 rounded-xl bg-emerald-50/60 border border-emerald-200">
                <input
                  type="checkbox"
                  id="editHasWhatsapp"
                  checked={editingCustomer.hasWhatsapp ?? true}
                  onChange={e => setEditingCustomer({ ...editingCustomer, hasWhatsapp: e.target.checked })}
                  className="w-4 h-4 text-[#028090] rounded accent-[#028090]"
                />
                <label htmlFor="editHasWhatsapp" className="text-[11px] font-bold text-emerald-900 cursor-pointer flex items-center gap-1">
                  <MessageCircle className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Has WhatsApp on this mobile number</span>
                </label>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 mb-1">Area / Route</label>
                  <input
                    type="text"
                    value={editingCustomer.area}
                    onChange={e => setEditingCustomer({ ...editingCustomer, area: e.target.value })}
                    className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-3 py-2 text-xs"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 mb-1">Customer Type</label>
                  <select
                    value={editingCustomer.type}
                    onChange={e => setEditingCustomer({ ...editingCustomer, type: e.target.value as CustomerType })}
                    className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-2 py-2 text-xs font-semibold"
                  >
                    <option value="HOME">Home (گھر)</option>
                    <option value="OFFICE">Office (دفتر)</option>
                    <option value="RESTAURANT">Restaurant (ہوٹل)</option>
                    <option value="SHOP">Shop (دکان)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">Street Address</label>
                <input
                  type="text"
                  value={editingCustomer.address}
                  onChange={e => setEditingCustomer({ ...editingCustomer, address: e.target.value })}
                  className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-3 py-2 text-xs"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 mb-1">Payment Cycle</label>
                  <select
                    value={editingCustomer.paymentCycle}
                    onChange={e => setEditingCustomer({ ...editingCustomer, paymentCycle: e.target.value as PaymentCycle })}
                    className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-2 py-2 text-xs font-semibold"
                  >
                    <option value="PAY_ON_DELIVERY">Pay On Delivery (COD)</option>
                    <option value="WEEKLY">Weekly (ہفتہ وار)</option>
                    <option value="BILL_TO_BILL">Bill to Bill</option>
                    <option value="MONTHLY">Monthly (ماہانہ)</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 mb-1">Security Deposit (Rs.)</label>
                  <NumericInput
                    value={editingCustomer.securityDeposit}
                    onChange={val => setEditingCustomer({ ...editingCustomer, securityDeposit: val })}
                    placeholder="0"
                    className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-3 py-2 text-xs font-bold"
                  />
                </div>
              </div>

              <div className="flex items-center gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setEditingCustomer(null)}
                  className="flex-1 py-2.5 rounded-xl bg-slate-200 text-slate-700 font-bold text-xs"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-[#0A2540] hover:bg-[#028090] text-white font-bold text-xs transition-colors shadow-xs"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* NEW CUSTOMER MODAL (With Contact Picker & WhatsApp Checkbox & NumericInput) */}
      {/* ========================================================================= */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl w-full max-w-md p-5 shadow-2xl space-y-3.5 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b pb-2">
              <div>
                <h3 className="font-bold text-sm text-[#0A2540]">Register New Customer (نیا گاہک)</h3>
                <p className="text-[10px] text-slate-500">All bottle rates initially start at Rs. 0</p>
              </div>
              <button onClick={() => setShowAddModal(false)} className="p-1 rounded-full bg-slate-100 text-slate-500">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleAddCustomer} className="space-y-3">
              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">Customer / Shop Name *</label>
                <input
                  required
                  type="text"
                  value={name}
                  onChange={e => setName(e.target.value)}
                  placeholder="e.g. Al-Madina Shinwari / Bilal Ahmed"
                  className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-3 py-2 text-xs font-semibold text-[#0F172A]"
                />
              </div>

              {/* Requirement 1.3 & 1.5: Contact Picker & Clean Phone (No "-") */}
              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  Mobile Number * (Format: Clean digits, e.g. 03001234567)
                </label>
                <div className="flex items-center gap-1.5">
                  <input
                    required
                    type="tel"
                    value={phone}
                    onChange={e => setPhone(cleanPhoneDisplay(e.target.value))}
                    placeholder="03001234567"
                    className="flex-1 bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-3 py-2 text-xs font-mono text-[#0F172A]"
                  />
                  <button
                    type="button"
                    onClick={handlePickContactForNew}
                    className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-[#0A2540] border border-slate-300 flex items-center gap-1 text-[11px] font-bold"
                    title="Select from Mobile Contacts"
                  >
                    <Contact className="w-4 h-4 text-[#028090]" />
                    <span className="hidden sm:inline">Contacts</span>
                  </button>
                </div>
              </div>

              {/* Requirement 1.4: WhatsApp Checkbox */}
              <div className="flex items-center gap-2 p-2 rounded-xl bg-emerald-50/70 border border-emerald-200">
                <input
                  type="checkbox"
                  id="addHasWhatsapp"
                  checked={hasWhatsapp}
                  onChange={e => setHasWhatsapp(e.target.checked)}
                  className="w-4 h-4 text-[#028090] rounded accent-[#028090]"
                />
                <label htmlFor="addHasWhatsapp" className="text-[11px] font-bold text-emerald-900 cursor-pointer flex items-center gap-1">
                  <MessageCircle className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Has WhatsApp on this number (اس نمبر پر واٹس ایپ ہے)</span>
                </label>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 mb-1">Area / Route</label>
                  <input
                    type="text"
                    value={area}
                    onChange={e => setArea(e.target.value)}
                    placeholder="e.g. Sector F-8 / Gulberg"
                    className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-3 py-2 text-xs"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 mb-1">Customer Type</label>
                  <select
                    value={type}
                    onChange={e => setType(e.target.value as CustomerType)}
                    className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-2 py-2 text-xs font-semibold"
                  >
                    <option value="HOME">Home (گھر)</option>
                    <option value="OFFICE">Office (دفتر)</option>
                    <option value="RESTAURANT">Restaurant (ہوٹل)</option>
                    <option value="SHOP">Shop (دکان)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">Street Address</label>
                <input
                  type="text"
                  value={address}
                  onChange={e => setAddress(e.target.value)}
                  placeholder="Street / House / Shop #"
                  className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-3 py-2 text-xs"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 mb-1">Payment Cycle</label>
                  <select
                    value={cycle}
                    onChange={e => setCycle(e.target.value as PaymentCycle)}
                    className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-2 py-2 text-xs font-semibold"
                  >
                    <option value="PAY_ON_DELIVERY">Pay On Delivery (COD)</option>
                    <option value="WEEKLY">Weekly (ہفتہ وار)</option>
                    <option value="BILL_TO_BILL">Bill to Bill</option>
                    <option value="MONTHLY">Monthly (ماہانہ)</option>
                  </select>
                </div>

                {/* Requirement 8: Numeric Inputs where 0 can be cleared */}
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 mb-1">Opening Debt (سابقہ ادھار)</label>
                  <NumericInput
                    value={openingBalance}
                    onChange={val => setOpeningBalance(val)}
                    placeholder="0"
                    className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-3 py-2 text-xs font-bold"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">Security Deposit (سیکیورٹی ڈپازٹ)</label>
                <NumericInput
                  value={securityDeposit}
                  onChange={val => setSecurityDeposit(val)}
                  placeholder="0"
                  className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-3 py-2 text-xs font-bold"
                />
              </div>

              <div className="flex items-center gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="flex-1 py-2.5 rounded-xl bg-slate-200 text-slate-700 font-bold text-xs"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-[#0A2540] hover:bg-[#028090] text-white font-bold text-xs transition-colors shadow-xs"
                >
                  Save Customer
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* PDF Slip Preview & Share Modal */}
      {slipDelivery && (
        <DeliverySlipModal
          delivery={slipDelivery}
          onClose={() => setSlipDelivery(null)}
        />
      )}

    </div>
  );
};
