import React, { useState } from 'react';
import { useWaterApp } from '../../context/WaterAppContext';
import { 
  TrendingUp, 
  Wallet, 
  CreditCard, 
  Receipt, 
  Calendar, 
  Droplets, 
  Truck, 
  Plus, 
  DollarSign, 
  Coins, 
  RotateCcw,
  Check,
  ChevronDown
} from 'lucide-react';
import { Delivery } from '../../types';

interface DashboardViewProps {
  onNavigateToNewDelivery: () => void;
  onNavigateToReceivePayment: () => void;
  onNavigateToExpenses: () => void;
  onNavigateToCashClosing: () => void;
  onNavigateToDeliveries: () => void;
}

type Period = 'TODAY' | 'YESTERDAY' | 'WEEKLY' | 'MONTHLY';

export const DashboardView: React.FC<DashboardViewProps> = ({
  onNavigateToNewDelivery,
  onNavigateToReceivePayment,
  onNavigateToExpenses,
  onNavigateToCashClosing,
  onNavigateToDeliveries
}) => {
  const { 
    currentUser, 
    deliveries, 
    payments, 
    expenses, 
    customers, 
    bottleInventory 
  } = useWaterApp();

  const [selectedPeriod, setSelectedPeriod] = useState<Period>('TODAY');
  const [showPeriodDropdown, setShowPeriodDropdown] = useState(false);

  const todayCal = new Date();
  const todayStr = todayCal.toISOString().split('T')[0];

  const yesterdayCal = new Date(Date.now() - 86400000);
  const yesterdayStr = yesterdayCal.toISOString().split('T')[0];

  const weekStartCal = new Date(Date.now() - 7 * 86400000);
  const weekStartStr = weekStartCal.toISOString().split('T')[0];

  const monthStartStr = `${todayCal.getFullYear()}-${String(todayCal.getMonth() + 1).padStart(2, '0')}-01`;

  // Period display strings
  const todayDisplay = todayCal.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
  const yesterdayDisplay = yesterdayCal.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
  const weekDisplay = `${weekStartCal.toLocaleDateString('en-GB', { day: '2-digit', month: 'short' })} — ${todayDisplay}`;
  const monthDisplay = `01 ${todayCal.toLocaleDateString('en-GB', { month: 'short' })} — ${todayDisplay}`;

  const dateRangeSubtitle = 
    selectedPeriod === 'TODAY' ? todayDisplay :
    selectedPeriod === 'YESTERDAY' ? yesterdayDisplay :
    selectedPeriod === 'WEEKLY' ? weekDisplay : monthDisplay;

  // Filter deliveries for period
  const periodDeliveries = deliveries.filter(d => {
    if (selectedPeriod === 'TODAY') return d.date === todayStr;
    if (selectedPeriod === 'YESTERDAY') return d.date === yesterdayStr;
    if (selectedPeriod === 'WEEKLY') return d.date >= weekStartStr;
    if (selectedPeriod === 'MONTHLY') return d.date >= monthStartStr;
    return true;
  });

  const periodPayments = payments.filter(p => {
    if (selectedPeriod === 'TODAY') return p.date === todayStr;
    if (selectedPeriod === 'YESTERDAY') return p.date === yesterdayStr;
    if (selectedPeriod === 'WEEKLY') return p.date >= weekStartStr;
    if (selectedPeriod === 'MONTHLY') return p.date >= monthStartStr;
    return true;
  });

  const periodExpenses = expenses.filter(e => {
    if (selectedPeriod === 'TODAY') return e.date === todayStr;
    if (selectedPeriod === 'YESTERDAY') return e.date === yesterdayStr;
    if (selectedPeriod === 'WEEKLY') return e.date >= weekStartStr;
    if (selectedPeriod === 'MONTHLY') return e.date >= monthStartStr;
    return true;
  });

  const periodSales = periodDeliveries.reduce((sum, d) => sum + d.totalAmount, 0);
  const periodCashCollected = periodPayments
    .filter(p => p.paymentMethod === 'CASH' || (p as any).paymentMethod === 'PAY_FROM_SALE')
    .reduce((sum, p) => sum + p.amount, 0);

  const totalOutstanding = customers.reduce((sum, c) => sum + (c.currentBalance > 0 ? c.currentBalance : 0), 0);
  const periodExpenseTotal = periodExpenses.reduce((sum, e) => sum + e.amount, 0);
  const periodNetProfit = periodSales - periodExpenseTotal;

  // Bottle breakdown
  const bottleBreakdown = periodDeliveries.reduce((acc, del) => {
    del.items.forEach(item => {
      const name = item.bottleName || "19L Refill";
      acc[name] = (acc[name] || 0) + item.quantity;
    });
    return acc;
  }, {} as Record<string, number>);

  const totalDeliveredPeriod = periodDeliveries.reduce((sum, d) => sum + d.totalFullDelivered, 0);

  return (
    <div className="space-y-4 pb-20">
      
      {/* 1. Hero Plant Status Banner */}
      <div className="relative rounded-2xl overflow-hidden bg-[#0A2540] text-white shadow-md">
        <div 
          className="absolute inset-0 bg-cover bg-center opacity-30"
          style={{ backgroundImage: "url('/water_hero_banner.jpg')" }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-[#0A2540]/80 to-[#07192C]/95" />

        <div className="relative z-10 p-4 sm:p-5 space-y-3">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-white/95 rounded-xl p-1 shadow-md flex items-center justify-center shrink-0">
                <img 
                  src="/aab_e_baraan_logo.png" 
                  alt="Aab-e-Baraan Logo" 
                  className="w-full h-full object-contain" 
                />
              </div>
              <div>
                <h1 className="text-base sm:text-lg font-bold tracking-tight">
                  Aab e Baraan RO Plant
                </h1>
                <p className="text-xs text-[#00A896] font-urdu font-semibold mt-0.5">
                  پلانٹ اسٹیٹس: فعال و جاری (Active Plant)
                </p>
              </div>
            </div>

            <div className="px-2.5 py-1 rounded-lg bg-[#10B981]/20 border border-[#10B981]/40 flex items-center gap-1.5 text-[10px] font-bold text-[#10B981]">
              <span className="w-2 h-2 rounded-full bg-[#10B981] animate-pulse" />
              <span>LIVE</span>
            </div>
          </div>

          <div className="pt-2 border-t border-white/10 flex items-center justify-between text-xs">
            <div>
              <span className="text-[#E8F4F8]/70 text-[11px] block">Logged In As</span>
              <strong className="text-white font-semibold">{currentUser.name}</strong>
            </div>

            <div className="text-right">
              <span className="text-[#E8F4F8]/70 text-[11px] block">Role</span>
              <strong className="text-[#02C39A] font-bold">{currentUser.role}</strong>
            </div>
          </div>
        </div>
      </div>

      {/* 2. Primary Financial Cards with Corner Period Filter Button */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-sm font-bold text-[#0A2540]">
              {selectedPeriod === 'TODAY' ? "Today" : selectedPeriod === 'YESTERDAY' ? "Yesterday" : selectedPeriod === 'WEEKLY' ? "Weekly" : "Monthly"}'s Business Summary
            </h2>
            <p className="text-[11px] text-[#334155] font-urdu">
              {selectedPeriod === 'TODAY' ? "آج" : selectedPeriod === 'YESTERDAY' ? "گزشتہ کل" : selectedPeriod === 'WEEKLY' ? "ہفتہ وار" : "ماہانہ"} کا ریکارڈ اور کارکردگی
            </p>
          </div>

          {/* Corner Period Selector Button */}
          <div className="relative text-right">
            <button
              onClick={() => setShowPeriodDropdown(!showPeriodDropdown)}
              className="px-2.5 py-1.5 rounded-xl bg-[#0A2540] text-white text-xs font-bold flex items-center gap-1.5 shadow-xs"
            >
              <Calendar className="w-3.5 h-3.5 text-[#E8F4F8]" />
              <span>
                {selectedPeriod === 'TODAY' ? "Today (آج)" :
                 selectedPeriod === 'YESTERDAY' ? "Yesterday (گزشتہ کل)" :
                 selectedPeriod === 'WEEKLY' ? "Weekly (ہفتہ وار)" : "Monthly (ماہانہ)"}
              </span>
              <ChevronDown className="w-3.5 h-3.5" />
            </button>

            {showPeriodDropdown && (
              <div 
                className="absolute right-0 mt-1.5 w-44 bg-white border border-[#CBD5E1] rounded-xl shadow-xl py-1 z-50 animate-in fade-in text-xs"
                onMouseLeave={() => setShowPeriodDropdown(false)}
              >
                {(['TODAY', 'YESTERDAY', 'WEEKLY', 'MONTHLY'] as Period[]).map(p => (
                  <button
                    key={p}
                    onClick={() => {
                      setSelectedPeriod(p);
                      setShowPeriodDropdown(false);
                    }}
                    className={`w-full px-3 py-2 text-left flex items-center justify-between hover:bg-[#F0F7FB] ${
                      selectedPeriod === p ? 'bg-[#E8F4F8] text-[#0A2540] font-bold' : 'text-[#0F172A]'
                    }`}
                  >
                    <span>{p === 'TODAY' ? 'Today' : p === 'YESTERDAY' ? 'Yesterday' : p === 'WEEKLY' ? 'Weekly' : 'Monthly'}</span>
                    <span className="text-[10px] text-[#028090] font-urdu">
                      {p === 'TODAY' ? 'آج' : p === 'YESTERDAY' ? 'گزشتہ کل' : p === 'WEEKLY' ? 'ہفتہ وار' : 'ماہانہ'}
                    </span>
                  </button>
                ))}
              </div>
            )}

            <p className="text-[10px] text-[#334155] font-semibold mt-1">
              {dateRangeSubtitle}
            </p>
          </div>
        </div>

        {/* 4 MetricStatCards in 2x2 grid */}
        <div className="grid grid-cols-2 gap-2.5">
          
          {/* Card 1: Total Sales */}
          <div className="bg-white border border-[#CBD5E1]/70 rounded-2xl p-3.5 shadow-xs">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs font-bold text-[#0A2540]">Total Sales</p>
                <p className="text-[10px] text-[#475569] font-urdu">کل سیلز / بل</p>
              </div>
              <div className="p-1.5 rounded-lg bg-[#00A896]/10 text-[#00A896]">
                <TrendingUp className="w-4 h-4" />
              </div>
            </div>
            <p className="text-base sm:text-lg font-black text-[#0A2540] mt-2">
              Rs. {periodSales.toLocaleString()}
            </p>
            <span className="inline-block mt-1 text-[10px] font-bold px-1.5 py-0.5 rounded bg-[#E8F4F8] text-[#0A2540]">
              {periodDeliveries.length} Orders
            </span>
          </div>

          {/* Card 2: Cash Collected */}
          <div className="bg-white border border-[#CBD5E1]/70 rounded-2xl p-3.5 shadow-xs">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs font-bold text-[#0A2540]">Cash Collected</p>
                <p className="text-[10px] text-[#475569] font-urdu">وصول شدہ کیش</p>
              </div>
              <div className="p-1.5 rounded-lg bg-[#10B981]/10 text-[#10B981]">
                <Wallet className="w-4 h-4" />
              </div>
            </div>
            <p className="text-base sm:text-lg font-black text-[#10B981] mt-2">
              Rs. {periodCashCollected.toLocaleString()}
            </p>
            <span className="inline-block mt-1 text-[10px] font-bold px-1.5 py-0.5 rounded bg-[#D1FAE5] text-[#065F46]">
              Naqd
            </span>
          </div>

          {/* Card 3: Total Outstanding */}
          <div className="bg-white border border-[#CBD5E1]/70 rounded-2xl p-3.5 shadow-xs">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs font-bold text-[#0A2540]">Total Outstanding</p>
                <p className="text-[10px] text-[#475569] font-urdu">مارکیٹ ادھار</p>
              </div>
              <div className="p-1.5 rounded-lg bg-[#F59E0B]/10 text-[#F59E0B]">
                <CreditCard className="w-4 h-4" />
              </div>
            </div>
            <p className="text-base sm:text-lg font-black text-[#D97706] mt-2">
              Rs. {totalOutstanding.toLocaleString()}
            </p>
            <span className="inline-block mt-1 text-[10px] font-bold px-1.5 py-0.5 rounded bg-[#FEF3C7] text-[#92400E]">
              Udhaar
            </span>
          </div>

          {/* Card 4: Expenses */}
          <div className="bg-white border border-[#CBD5E1]/70 rounded-2xl p-3.5 shadow-xs">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs font-bold text-[#0A2540]">Expenses</p>
                <p className="text-[10px] text-[#475569] font-urdu">اخراجات</p>
              </div>
              <div className="p-1.5 rounded-lg bg-[#EF4444]/10 text-[#EF4444]">
                <Receipt className="w-4 h-4" />
              </div>
            </div>
            <p className="text-base sm:text-lg font-black text-[#EF4444] mt-2">
              Rs. {periodExpenseTotal.toLocaleString()}
            </p>
            <span className="inline-block mt-1 text-[10px] font-bold px-1.5 py-0.5 rounded bg-[#F0F7FB] text-[#0F172A]">
              Net: Rs. {periodNetProfit.toLocaleString()}
            </span>
          </div>

        </div>
      </div>

      {/* 3. Delivered Bottles by Size Card */}
      <div className="bg-white border border-[#CBD5E1]/70 rounded-2xl p-4 shadow-xs space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-xs font-bold text-[#07192C]">
              Delivered Bottles by Size ({selectedPeriod === 'TODAY' ? 'Today' : selectedPeriod.toLowerCase()})
            </h3>
            <p className="text-[11px] text-[#334155] font-urdu">سائز کے حساب سے کل ترسیل</p>
          </div>

          <span className="px-2 py-1 rounded-md bg-[#E8F4F8] text-[#0A2540] text-[11px] font-bold">
            {totalDeliveredPeriod} Total Bottles
          </span>
        </div>

        {Object.keys(bottleBreakdown).length === 0 ? (
          <p className="text-xs text-[#475569] py-1">
            No bottles delivered in this period (اس دورانیہ میں ترسیل موجود نہیں)
          </p>
        ) : (
          <div className="space-y-1.5">
            {Object.entries(bottleBreakdown).map(([sizeName, qty]) => {
              const unit = sizeName.includes("500") ? "Packets (پیکٹ)" : "Bottles (بوتلیں)";
              return (
                <div
                  key={sizeName}
                  className="flex items-center justify-between p-2 rounded-xl bg-[#E8F4F8]/50 text-xs"
                >
                  <div className="flex items-center gap-2">
                    <div className="w-6 h-6 rounded-full bg-[#0A2540]/15 flex items-center justify-center text-[#0A2540]">
                      <Droplets className="w-3.5 h-3.5" />
                    </div>
                    <span className="font-bold text-[#07192C]">{sizeName}</span>
                  </div>

                  <span className="px-2.5 py-0.5 rounded-md bg-[#0A2540] text-white text-[11px] font-bold">
                    {qty} {unit}
                  </span>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* 4. Quick Action Grid (All 4 in ONE line) */}
      <div className="space-y-2">
        <div>
          <h3 className="text-xs font-bold text-[#0A2540]">
            Quick Actions (فوری ایکشن)
          </h3>
          <p className="text-[11px] text-[#334155] font-urdu">کم وقت میں اندراج کریں</p>
        </div>

        <div className="grid grid-cols-4 gap-1.5">
          
          <button
            onClick={onNavigateToNewDelivery}
            className="p-2 sm:p-2.5 rounded-xl bg-white border border-[#CBD5E1]/80 hover:bg-[#F0F7FB] flex flex-col items-center text-center shadow-xs transition-all active:scale-95"
          >
            <div className="w-8 h-8 rounded-lg bg-[#0A2540] text-white flex items-center justify-center mb-1">
              <Truck className="w-4 h-4" />
            </div>
            <span className="text-[10px] font-bold text-[#0A2540] leading-tight">New Delivery</span>
            <span className="text-[9px] text-[#475569] font-urdu">نئی ڈیلیوری</span>
          </button>

          <button
            onClick={onNavigateToReceivePayment}
            className="p-2 sm:p-2.5 rounded-xl bg-white border border-[#CBD5E1]/80 hover:bg-[#F0F7FB] flex flex-col items-center text-center shadow-xs transition-all active:scale-95"
          >
            <div className="w-8 h-8 rounded-lg bg-[#10B981] text-white flex items-center justify-center mb-1">
              <DollarSign className="w-4 h-4" />
            </div>
            <span className="text-[10px] font-bold text-[#10B981] leading-tight">Receive Cash</span>
            <span className="text-[9px] text-[#475569] font-urdu">پیمنٹ وصولی</span>
          </button>

          <button
            onClick={onNavigateToExpenses}
            className="p-2 sm:p-2.5 rounded-xl bg-white border border-[#CBD5E1]/80 hover:bg-[#F0F7FB] flex flex-col items-center text-center shadow-xs transition-all active:scale-95"
          >
            <div className="w-8 h-8 rounded-lg bg-[#EF4444] text-white flex items-center justify-center mb-1">
              <Receipt className="w-4 h-4" />
            </div>
            <span className="text-[10px] font-bold text-[#EF4444] leading-tight">Add Expense</span>
            <span className="text-[9px] text-[#475569] font-urdu">خرچ درج کریں</span>
          </button>

          <button
            onClick={onNavigateToCashClosing}
            className="p-2 sm:p-2.5 rounded-xl bg-white border border-[#CBD5E1]/80 hover:bg-[#F0F7FB] flex flex-col items-center text-center shadow-xs transition-all active:scale-95"
          >
            <div className="w-8 h-8 rounded-lg bg-[#028090] text-white flex items-center justify-center mb-1">
              <Coins className="w-4 h-4" />
            </div>
            <span className="text-[10px] font-bold text-[#028090] leading-tight">Cash Closing</span>
            <span className="text-[9px] text-[#475569] font-urdu">شام بندش</span>
          </button>

        </div>
      </div>

      {/* 5. Period Deliveries List */}
      <div className="space-y-2.5">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-xs font-bold text-[#0A2540]">
              {selectedPeriod === 'TODAY' ? "Today's Deliveries (آج کی ترسیلات)" : `${selectedPeriod.toLowerCase()} Deliveries (${periodDeliveries.length})`}
            </h3>
            <p className="text-[11px] text-[#334155] font-urdu">کے آرڈرز اور ترسیل</p>
          </div>
          <button
            onClick={onNavigateToDeliveries}
            className="text-[11px] text-[#028090] font-bold hover:underline"
          >
            View All ({deliveries.length})
          </button>
        </div>

        {periodDeliveries.length === 0 ? (
          <div className="bg-white border border-[#CBD5E1]/70 rounded-2xl p-6 text-center text-xs text-[#475569]">
            No deliveries recorded for this period. Tap 'New Delivery' to record.
          </div>
        ) : (
          <div className="space-y-2">
            {periodDeliveries.map(del => (
              <div
                key={del.id}
                className="bg-white border border-[#CBD5E1]/70 rounded-2xl p-3.5 shadow-xs space-y-2"
              >
                <div className="flex items-start justify-between">
                  <div>
                    <h4 className="text-xs font-bold text-[#0A2540]">{del.customerName}</h4>
                    <p className="text-[11px] text-[#475569]">{del.customerArea} • {del.time}</p>
                  </div>

                  <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                    del.status === 'DELIVERED' 
                      ? 'bg-[#D1FAE5] text-[#065F46]'
                      : 'bg-[#FEF3C7] text-[#92400E]'
                  }`}>
                    {del.status}
                  </span>
                </div>

                <div className="pt-2 border-t border-[#E2E8F0] flex items-center justify-between text-xs">
                  <span className="text-[#334155]">
                    {del.items.map(i => `${i.quantity}x ${i.bottleName}`).join(', ')} • ↩ {del.totalEmptyCollected}
                  </span>

                  <span className="font-bold text-[#0A2540]">
                    Rs. {del.totalAmount.toLocaleString()}
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

    </div>
  );
};
