import React, { useState } from 'react';
import { useWaterApp } from '../../context/WaterAppContext';
import { 
  UserCog, 
  ShieldCheck, 
  Plus, 
  Trash2, 
  Phone, 
  CheckCircle2, 
  X,
  User,
  Lock,
  Eye,
  EyeOff,
  Bell,
  AlertTriangle,
  Pencil
} from 'lucide-react';
import { UserRole, UserAccount } from '../../types';

export const UsersView: React.FC = () => {
  const { 
    userAccounts, 
    addUserAccount, 
    updateUserAccount,
    deleteUserAccount, 
    currentUser, 
    notifications,
    markNotificationAsRead,
    businessProfile 
  } = useWaterApp();

  const [showAddModal, setShowAddModal] = useState(false);
  const [name, setName] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [phone, setPhone] = useState('');
  const [role, setRole] = useState<UserRole>('INCHARGE');

  // Edit user state
  const [showEditModal, setShowEditModal] = useState(false);
  const [editingUser, setEditingUser] = useState<UserAccount | null>(null);
  const [editName, setEditName] = useState('');
  const [editUsername, setEditUsername] = useState('');
  const [editPassword, setEditPassword] = useState('');
  const [editShowPassword, setEditShowPassword] = useState(false);
  const [editPhone, setEditPhone] = useState('');
  const [editRole, setEditRole] = useState<UserRole>('INCHARGE');
  const [editActive, setEditActive] = useState(true);

  const passwordAlerts = notifications.filter(
    n => n.title.includes('Password Reset') && !n.isRead
  );

  const handleAddUser = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !username || !password) {
      alert("Name, Username, and Password are all required.");
      return;
    }

    addUserAccount({
      name: name.trim(),
      username: username.toLowerCase().trim(),
      password: password.trim(),
      phone: phone || '0300-0000000',
      role,
      active: true
    });

    setShowAddModal(false);
    setName('');
    setUsername('');
    setPassword('');
    setPhone('');
  };

  const openEditModal = (user: UserAccount) => {
    setEditingUser(user);
    setEditName(user.name);
    setEditUsername(user.username);
    setEditPassword(user.password || '');
    setEditPhone(user.phone || '');
    setEditRole(user.role);
    setEditActive(user.active !== false);
    setShowEditModal(true);
  };

  const handleSaveEditUser = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingUser) return;
    if (!editName.trim() || !editUsername.trim() || !editPassword.trim()) {
      alert("Name, Username, and Password are all required.");
      return;
    }

    updateUserAccount({
      ...editingUser,
      name: editName.trim(),
      username: editUsername.toLowerCase().trim(),
      password: editPassword.trim(),
      phone: editPhone || '0300-0000000',
      role: editRole,
      active: editActive
    });

    setShowEditModal(false);
    setEditingUser(null);
  };

  return (
    <div className="space-y-3.5 pb-24 text-xs">
      
      {/* 1. Header Card */}
      <div className="bg-white border border-[#CBD5E1]/70 rounded-2xl p-4 shadow-xs space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-sm font-bold text-[#0A2540]">
              Staff & User Management (عملہ لاگ ان)
            </h2>
            <p className="text-[11px] text-[#475569] font-urdu">
              پلانٹ سپروائزر، رائیڈر اور ایڈمن اکاؤنٹس
            </p>
          </div>

          <button
            onClick={() => setShowAddModal(true)}
            className="px-3 py-1.5 rounded-lg bg-[#0A2540] text-white text-[11px] font-bold flex items-center gap-1 shadow-xs"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Staff</span>
          </button>
        </div>

        {/* Current Active Session */}
        <div className="p-2.5 rounded-xl bg-[#E8F4F8] flex items-center justify-between">
          <div>
            <span className="text-[10px] text-slate-500 block">Logged In User:</span>
            <strong className="text-xs text-[#0A2540]">{currentUser.name}</strong>
          </div>

          <span className="px-2.5 py-0.5 rounded-full bg-[#00A896] text-[#07192C] text-[10px] font-bold">
            {currentUser.role}
          </span>
        </div>
      </div>

      {/* Password Reset Requests Alert Banner for Admin */}
      {passwordAlerts.length > 0 && (
        <div className="p-3 rounded-2xl bg-amber-50 border border-amber-300 space-y-2">
          <div className="flex items-center gap-2 text-amber-900 font-bold text-xs">
            <Bell className="w-4 h-4 text-amber-600 animate-bounce" />
            <span>Pending Password Reset Requests ({passwordAlerts.length})</span>
          </div>
          {passwordAlerts.map(alert => (
            <div key={alert.id} className="p-2 rounded-xl bg-white border border-amber-200 flex items-center justify-between text-[11px]">
              <div>
                <p className="font-bold text-[#0A2540]">{alert.title}</p>
                <p className="text-slate-600 text-[10px]">{alert.message}</p>
              </div>
              <button
                onClick={() => markNotificationAsRead(alert.id)}
                className="px-2 py-1 rounded-lg bg-amber-100 text-amber-800 text-[10px] font-bold"
              >
                Mark Resolved
              </button>
            </div>
          ))}
        </div>
      )}

      {/* 2. Staff Accounts List */}
      <div className="space-y-2">
        <h3 className="font-bold text-xs text-[#0A2540] uppercase tracking-wider px-1">
          Registered Accounts ({userAccounts.length})
        </h3>

        {userAccounts.map(user => (
          <div
            key={user.id}
            className="bg-white border border-[#CBD5E1]/70 rounded-2xl p-3.5 shadow-xs flex items-center justify-between"
          >
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-full bg-[#0A2540]/10 text-[#0A2540] font-black flex items-center justify-center text-xs">
                {user.name.charAt(0)}
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <h4 className="font-bold text-xs text-[#0A2540]">{user.name}</h4>
                  {user.active === false && (
                    <span className="text-[9px] bg-rose-100 text-rose-700 px-1.5 py-0.2 rounded font-semibold">
                      Inactive
                    </span>
                  )}
                </div>
                <p className="text-[10px] text-slate-400 font-mono">
                  @{user.username} • Password: <span className="text-slate-600 font-bold">{user.password || '***'}</span>
                </p>
                <p className="text-[10px] text-slate-500">Ph: {user.phone}</p>
              </div>
            </div>

            <div className="flex items-center gap-1.5">
              <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                user.role === 'ADMIN'
                  ? 'bg-[#F3E5F5] text-[#6A1B9A]'
                  : user.role === 'INCHARGE'
                  ? 'bg-[#E8F4F8] text-[#0A2540]'
                  : 'bg-slate-100 text-slate-600'
              }`}>
                {user.role}
              </span>

              {/* Admin Edit Button */}
              {currentUser.role === 'ADMIN' && (
                <button
                  onClick={() => openEditModal(user)}
                  className="text-slate-500 hover:text-[#0A2540] p-1.5 rounded-lg hover:bg-slate-100 transition-colors"
                  title="Edit User (یوزر ایڈٹ کریں)"
                >
                  <Pencil className="w-3.5 h-3.5" />
                </button>
              )}

              {user.id !== 'user_admin_01' && (
                <button
                  onClick={() => {
                    if (window.confirm(`Delete user account @${user.username}?`)) {
                      deleteUserAccount(user.id);
                    }
                  }}
                  className="text-slate-400 hover:text-rose-500 p-1.5 rounded-lg hover:bg-rose-50 transition-colors"
                  title="Remove User"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* 3. Role Permissions Guide */}
      <div className="bg-white border border-[#CBD5E1]/70 rounded-2xl p-4 shadow-xs space-y-2 text-xs">
        <h4 className="font-bold text-xs text-[#0A2540] flex items-center gap-1.5">
          <ShieldCheck className="w-4 h-4 text-[#00A896]" />
          <span>Role Permissions (اختیارات)</span>
        </h4>

        <div className="space-y-1.5 text-[11px] text-slate-600 pt-1">
          <p>• <strong>ADMIN:</strong> تمام ریکارڈ ڈیلیٹ کرنے کے حقوق، ریٹ سیٹنگ، نفع نقصان، ملازمین کے اکاؤنٹس ایڈٹ/شامل کرنا۔</p>
          <p>• <strong>INCHARGE / SUPERVISOR:</strong> ڈیلیوری اندراج، وصولی، خرچہ درج، روزانہ کلوزنگ (ڈیلیٹ حقوق نہیں)۔</p>
          <p>• <strong>VIEW_ONLY:</strong> صرف ریکارڈ دیکھنے کی اجازت۔</p>
        </div>
      </div>

      {/* ADD STAFF MODAL */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl w-full max-w-sm p-5 shadow-2xl space-y-3">
            <div className="flex items-center justify-between border-b pb-2">
              <h3 className="font-bold text-sm text-[#0A2540]">Add New Staff Account</h3>
              <button onClick={() => setShowAddModal(false)} className="p-1 rounded-full bg-slate-100 text-slate-500">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleAddUser} className="space-y-2.5">
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">Full Name *</label>
                <input
                  required
                  type="text"
                  value={name}
                  onChange={e => setName(e.target.value)}
                  placeholder="e.g. Tariq Mahmood"
                  className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-3 py-2 text-xs"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">Username *</label>
                <input
                  required
                  type="text"
                  value={username}
                  onChange={e => setUsername(e.target.value.toLowerCase().trim())}
                  placeholder="e.g. tariq_rider"
                  className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-3 py-2 text-xs font-mono"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">Password (پاس ورڈ) *</label>
                <div className="relative">
                  <input
                    required
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={e => setPassword(e.target.value)}
                    placeholder="Enter account password"
                    className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-3 py-2 pr-9 text-xs"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-400"
                  >
                    {showPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">Phone Number</label>
                <input
                  type="text"
                  value={phone}
                  onChange={e => setPhone(e.target.value)}
                  placeholder="0300-1234567"
                  className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-3 py-2 text-xs"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">Assign Role</label>
                <select
                  value={role}
                  onChange={e => setRole(e.target.value as UserRole)}
                  className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-2 py-2 text-xs"
                >
                  <option value="INCHARGE">Supervisor (سپروائزر)</option>
                  <option value="ADMIN">Admin</option>
                  <option value="VIEW_ONLY">View-Only (صرف نظارہ)</option>
                </select>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="flex-1 py-2 rounded-xl bg-slate-200 text-slate-700 font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 rounded-xl bg-[#0A2540] text-white font-bold"
                >
                  Save Account
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* EDIT STAFF MODAL */}
      {showEditModal && editingUser && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl w-full max-w-sm p-5 shadow-2xl space-y-3">
            <div className="flex items-center justify-between border-b pb-2">
              <div>
                <h3 className="font-bold text-sm text-[#0A2540]">Edit Staff Account</h3>
                <p className="text-[11px] text-slate-500 font-urdu">اکاؤنٹ کی تفصیلات تبدیل کریں</p>
              </div>
              <button onClick={() => setShowEditModal(false)} className="p-1 rounded-full bg-slate-100 text-slate-500">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveEditUser} className="space-y-2.5">
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">Full Name *</label>
                <input
                  required
                  type="text"
                  value={editName}
                  onChange={e => setEditName(e.target.value)}
                  className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-3 py-2 text-xs"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">Username *</label>
                <input
                  required
                  type="text"
                  value={editUsername}
                  onChange={e => setEditUsername(e.target.value.toLowerCase().trim())}
                  className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-3 py-2 text-xs font-mono"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">Password (پاس ورڈ) *</label>
                <div className="relative">
                  <input
                    required
                    type={editShowPassword ? 'text' : 'password'}
                    value={editPassword}
                    onChange={e => setEditPassword(e.target.value)}
                    className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-3 py-2 pr-9 text-xs"
                  />
                  <button
                    type="button"
                    onClick={() => setEditShowPassword(!editShowPassword)}
                    className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-400"
                  >
                    {editShowPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">Phone Number</label>
                <input
                  type="text"
                  value={editPhone}
                  onChange={e => setEditPhone(e.target.value)}
                  className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-3 py-2 text-xs"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">Role Permissions</label>
                <select
                  value={editRole}
                  onChange={e => setEditRole(e.target.value as UserRole)}
                  className="w-full bg-[#F0F7FB] border border-[#CBD5E1] rounded-xl px-2 py-2 text-xs"
                >
                  <option value="INCHARGE">Supervisor (سپروائزر)</option>
                  <option value="ADMIN">Admin</option>
                  <option value="VIEW_ONLY">View-Only (صرف نظارہ)</option>
                </select>
              </div>

              <div className="flex items-center gap-2 pt-1">
                <label className="flex items-center gap-2 text-xs text-slate-700 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={editActive}
                    onChange={e => setEditActive(e.target.checked)}
                    className="rounded border-slate-300 text-[#0A2540]"
                  />
                  <span>Account Active (فعال اکاؤنٹ)</span>
                </label>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowEditModal(false)}
                  className="flex-1 py-2 rounded-xl bg-slate-200 text-slate-700 font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 rounded-xl bg-[#0A2540] text-white font-bold"
                >
                  Update Account
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
