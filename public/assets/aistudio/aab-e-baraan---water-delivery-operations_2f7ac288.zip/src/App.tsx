import React, { useState } from 'react';
import { WaterAppProvider, useWaterApp } from './context/WaterAppContext';
import { Navbar } from './components/layout/Navbar';
import { MobileBottomNav, MainNavTab } from './components/layout/MobileBottomNav';

import { DashboardView } from './components/dashboard/DashboardView';
import { DeliveriesView } from './components/deliveries/DeliveriesView';
import { NewDeliveryScreen } from './components/deliveries/NewDeliveryScreen';
import { CustomersView } from './components/customers/CustomersView';
import { ReceivePaymentScreen } from './components/payments/ReceivePaymentScreen';
import { CashClosingView } from './components/cashclosing/CashClosingView';
import { InventoryView } from './components/inventory/InventoryView';
import { ExpensesView } from './components/expenses/ExpensesView';
import { ReportsView } from './components/reports/ReportsView';
import { UsersView } from './components/users/UsersView';
import { BackupView } from './components/backup/BackupView';
import { Customer } from './types';
import { AuthScreen } from './components/auth/AuthScreen';

export type AppScreen = 
  | 'DASHBOARD'
  | 'DELIVERIES'
  | 'CUSTOMERS'
  | 'STOCK'
  | 'EXPENSES'
  | 'NEW_DELIVERY'
  | 'RECEIVE_PAYMENT'
  | 'CASH_CLOSING'
  | 'REPORTS'
  | 'USER_MANAGEMENT'
  | 'BACKUP_RESTORE';

interface ScreenMeta {
  title: string;
  urduTitle: string;
  isSubScreen: boolean;
}

const SCREEN_METAS: Record<AppScreen, ScreenMeta> = {
  DASHBOARD: { title: 'Dashboard', urduTitle: 'ڈیش بورڈ', isSubScreen: false },
  DELIVERIES: { title: 'Deliveries', urduTitle: 'ترسیلات', isSubScreen: false },
  CUSTOMERS: { title: 'Customers', urduTitle: 'گاہک', isSubScreen: false },
  EXPENSES: { title: 'Expenses', urduTitle: 'اخراجات', isSubScreen: false },
  STOCK: { title: 'Stock & Cost', urduTitle: 'اسٹاک و لاگت', isSubScreen: false },
  NEW_DELIVERY: { title: 'New Delivery', urduTitle: 'نئی ڈیلیوری', isSubScreen: true },
  RECEIVE_PAYMENT: { title: 'Receive Payment', urduTitle: 'وصولی', isSubScreen: true },
  CASH_CLOSING: { title: 'Cash Closing', urduTitle: 'کیش بندش', isSubScreen: true },
  REPORTS: { title: 'Reports', urduTitle: 'رپورٹ', isSubScreen: true },
  USER_MANAGEMENT: { title: 'Staff Login Accounts', urduTitle: 'عملہ لاگ ان', isSubScreen: true },
  BACKUP_RESTORE: { title: 'Backup & Restore', urduTitle: 'بیک اپ اور بحالی', isSubScreen: true },
};

function MainApp() {
  const { isAuthenticated } = useWaterApp();
  const [currentScreen, setCurrentScreen] = useState<AppScreen>('DASHBOARD');
  const [screenStack, setScreenStack] = useState<AppScreen[]>(['DASHBOARD']);
  const [activeCustomerForAction, setActiveCustomerForAction] = useState<Customer | null>(null);

  if (!isAuthenticated) {
    return <AuthScreen />;
  }

  const navigateTo = (screen: AppScreen) => {
    if (currentScreen !== screen) {
      setScreenStack(prev => [...prev, screen]);
      setCurrentScreen(screen);
    }
  };

  const navigateBack = () => {
    if (screenStack.length > 1) {
      const nextStack = screenStack.slice(0, -1);
      setScreenStack(nextStack);
      setCurrentScreen(nextStack[nextStack.length - 1]);
    } else {
      setCurrentScreen('DASHBOARD');
      setScreenStack(['DASHBOARD']);
    }
  };

  const meta = SCREEN_METAS[currentScreen] || SCREEN_METAS.DASHBOARD;
  const isSubScreen = meta.isSubScreen;

  // Map main tab to AppScreen
  const handleTabSelect = (tab: MainNavTab) => {
    const screenMap: Record<MainNavTab, AppScreen> = {
      dashboard: 'DASHBOARD',
      deliveries: 'DELIVERIES',
      customers: 'CUSTOMERS',
      expenses: 'EXPENSES',
      stock: 'STOCK',
    };
    const target = screenMap[tab];
    setScreenStack([target]);
    setCurrentScreen(target);
  };

  // Convert current screen to active tab if on main tabs
  const currentTab: MainNavTab = 
    currentScreen === 'DELIVERIES' ? 'deliveries' :
    currentScreen === 'CUSTOMERS' ? 'customers' :
    currentScreen === 'EXPENSES' ? 'expenses' :
    currentScreen === 'STOCK' ? 'stock' : 'dashboard';

  return (
    <div className="min-h-screen bg-[#F0F7FB] text-[#0F172A] flex flex-col font-sans select-none antialiased">
      {/* Centered Mobile Container on Wide Screens */}
      <div className="w-full max-w-lg mx-auto min-h-screen flex flex-col bg-[#F0F7FB] shadow-xl relative overflow-hidden">
        
        {/* Watermark of Official Logo across all tabs */}
        <div 
          className="pointer-events-none absolute inset-0 flex items-center justify-center opacity-[0.06] z-0 overflow-hidden select-none"
          aria-hidden="true"
        >
          <img 
            src="/aab_e_baraan_logo.png" 
            alt="Aab-e-Baraan Watermark" 
            className="w-80 max-w-[85%] object-contain filter grayscale-[15%]"
          />
        </div>

        {/* Top App Bar (AabTopAppBar) */}
        <Navbar
          currentTitle={meta.title}
          currentUrduTitle={meta.urduTitle}
          isSubScreen={isSubScreen}
          onBack={navigateBack}
          onNavigateToReports={() => navigateTo('REPORTS')}
          onNavigateToStaff={() => navigateTo('USER_MANAGEMENT')}
          onNavigateToBackup={() => navigateTo('BACKUP_RESTORE')}
        />

        {/* Main Content Area */}
        <main className="flex-1 p-3.5 sm:p-4 overflow-y-auto relative z-10">
          {currentScreen === 'DASHBOARD' && (
            <DashboardView
              onNavigateToNewDelivery={() => {
                setActiveCustomerForAction(null);
                navigateTo('NEW_DELIVERY');
              }}
              onNavigateToReceivePayment={() => {
                setActiveCustomerForAction(null);
                navigateTo('RECEIVE_PAYMENT');
              }}
              onNavigateToExpenses={() => navigateTo('EXPENSES')}
              onNavigateToCashClosing={() => navigateTo('CASH_CLOSING')}
              onNavigateToDeliveries={() => navigateTo('DELIVERIES')}
            />
          )}

          {currentScreen === 'DELIVERIES' && (
            <DeliveriesView
              onNavigateToNewDelivery={() => {
                setActiveCustomerForAction(null);
                navigateTo('NEW_DELIVERY');
              }}
            />
          )}

          {currentScreen === 'CUSTOMERS' && (
            <CustomersView
              onCustomerSelect={(cust) => {
                setActiveCustomerForAction(cust);
              }}
              onNavigateToNewDelivery={(cust) => {
                setActiveCustomerForAction(cust);
                navigateTo('NEW_DELIVERY');
              }}
              onNavigateToReceivePayment={(cust) => {
                setActiveCustomerForAction(cust);
                navigateTo('RECEIVE_PAYMENT');
              }}
            />
          )}

          {currentScreen === 'EXPENSES' && (
            <ExpensesView />
          )}

          {currentScreen === 'STOCK' && (
            <InventoryView />
          )}

          {currentScreen === 'NEW_DELIVERY' && (
            <NewDeliveryScreen
              preSelectedCustomer={activeCustomerForAction}
              onDeliverySaved={navigateBack}
              onCancel={navigateBack}
            />
          )}

          {currentScreen === 'RECEIVE_PAYMENT' && (
            <ReceivePaymentScreen
              preSelectedCustomer={activeCustomerForAction}
              onPaymentCompleted={navigateBack}
              onCancel={navigateBack}
            />
          )}

          {currentScreen === 'CASH_CLOSING' && (
            <CashClosingView
              onClosingSubmitted={navigateBack}
            />
          )}

          {currentScreen === 'REPORTS' && (
            <ReportsView />
          )}

          {currentScreen === 'USER_MANAGEMENT' && (
            <UsersView />
          )}

          {currentScreen === 'BACKUP_RESTORE' && (
            <BackupView />
          )}
        </main>

        {/* Bottom Navigation Bar (Only on primary 5 tabs, hidden on sub-screens) */}
        {!isSubScreen && (
          <MobileBottomNav
            currentTab={currentTab}
            onTabSelect={handleTabSelect}
          />
        )}

      </div>
    </div>
  );
}

export default function App() {
  return (
    <WaterAppProvider>
      <MainApp />
    </WaterAppProvider>
  );
}
