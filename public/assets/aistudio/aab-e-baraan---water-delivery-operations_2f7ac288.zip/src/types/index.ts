export type CustomerType = 'HOME' | 'SHOP' | 'OFFICE' | 'RESTAURANT' | 'OTHER';

export type PaymentCycle = 
  | 'PAY_ON_DELIVERY' 
  | 'DAILY' 
  | 'WEEKLY' 
  | 'BILL_TO_BILL' 
  | 'MONTHLY' 
  | 'ADVANCE' 
  | 'CUSTOM';

export interface Customer {
  id: string;
  customerCode: string;
  name: string;
  phone: string;
  whatsapp: string;
  hasWhatsapp?: boolean;
  address: string;
  area: string;
  type: CustomerType;
  paymentCycle: PaymentCycle;
  registrationDate: string;
  paymentDueDate?: string;
  openingBalance: number;
  currentBalance: number; // Positive = customer owes business (Receivable)
  creditLimit: number;
  bottleDeposit: number;
  securityDeposit: number;
  emptyBottlesOwed: number; // Empty bottles currently in customer custody
  totalPurchases: number;
  notes: string;
  active: boolean;
  businessId: string;
  createdBy: string;
  lastEditedAt?: number;
  lastEditedBy?: string;
}

export type DeliveryUnit = 'PER_BOTTLE' | 'PER_PACKET';
export type BottleUsageType = 'MULTIPLE_TIME' | 'ONE_TIME' | 'CUSTOM';

export interface BottleSize {
  id: string;
  name: string;
  capacityLitres: number;
  packQuantity: number;
  defaultRefillPrice: number;
  bottleSalePrice: number;
  depositAmount: number;
  replacementPrice: number;
  active: boolean;
  refillCost: number;
  deliveryCost: number;
  deliveryUnit: DeliveryUnit;
  packetPackagingQty: number;
  isReturnableBottle: boolean;
  uom: string;
  openingStock: number;
  purchaseCost: number;
  latestPurchaseRate: number;
  usageType: BottleUsageType;
  customUsageType?: string;
  businessId: string;
}

export interface RateHistoryEntry {
  id: string;
  customerId: string;
  bottleSizeId: string;
  bottleSizeName: string;
  previousRate: number;
  newRate: number;
  rate: number;
  appliedFromDate: string;
  effectiveDate: string;
  updatedBy: string;
  timestamp: number;
}

export interface CustomerRate {
  id: string;
  customerId: string;
  bottleSizeId: string;
  bottleSizeName: string;
  customPrice: number;
  isAssigned: boolean;
  appliedDate: string;
  rateHistory: RateHistoryEntry[];
  businessId: string;
}

export type SecurityDepositTransactionType = 
  | 'INITIAL_DEPOSIT' 
  | 'ADDITIONAL_DEPOSIT' 
  | 'PARTIAL_REFUND' 
  | 'FULL_REFUND' 
  | 'ADJUSTMENT';

export interface SecurityDepositTransaction {
  id: string;
  customerId: string;
  customerName: string;
  amount: number;
  type: SecurityDepositTransactionType;
  date: string;
  paymentMethod: PaymentMethod;
  reference: string;
  notes: string;
  createdBy: string;
  timestamp: number;
  businessId: string;
}

export interface CustomerBottleAllocation {
  id: string;
  customerId: string;
  customerName: string;
  bottleSizeId: string;
  sizeName: string;
  totalIssued: number;
  emptyHeld: number;
  returnedCount: number;
  damagedCount: number;
  depositAmount: number;
  lastUpdated: string;
  businessId: string;
}

export type BottleMovementType = 
  | 'DELIVERY_OUT' 
  | 'RETURN_IN' 
  | 'PLANT_REFILL' 
  | 'PURCHASE_NEW' 
  | 'DAMAGED' 
  | 'CUSTOMER_DAMAGE' 
  | 'ADJUSTMENT';

export interface BottleInventory {
  id: string;
  bottleSizeId: string;
  sizeName: string;
  atPlantFull: number;     // Ready filled bottles in stock
  atPlantEmpty: number;    // Empty bottles awaiting refill
  withCustomers: number;   // Bottles currently at customer sites
  withStaff: number;       // Bottles currently on delivery bike/rickshaw/van
  damaged: number;         // Broken/damaged
  totalPurchased: number;
  totalIssuedOrSold: number;
  businessId: string;
}

export interface BottleMovement {
  id: string;
  date: string;
  bottleSizeId: string;
  sizeName: string;
  movementType: BottleMovementType;
  quantity: number;
  customerId?: string;
  customerName?: string;
  referenceType: string;
  referenceId: string;
  notes: string;
  createdBy: string;
  businessId: string;
  timestamp: number;
}

export interface BottlePurchaseRecord {
  id: string;
  date: string;
  bottleSizeId: string;
  sizeName: string;
  quantity: number;
  unitCost: number;
  totalCost: number;
  supplierName: string;
  invoiceOrBillNo: string;
  notes: string;
  recordedBy: string;
  timestamp: number;
}

export interface BottleRefillRecord {
  id: string;
  date: string;
  time: string;
  bottleSizeId: string;
  sizeName: string;
  quantityFilled: number;
  refillCostPerBottle: number;
  totalRefillCost: number;
  operatorName: string;
  notes: string;
  timestamp: number;
}

export type BottleTransactionType = 
  | 'CUSTOMER_ISSUE' 
  | 'PACKAGED_SALE' 
  | 'EMPTY_COLLECTED' 
  | 'DAMAGE_LOGGED';

export interface BottleIssueSaleRecord {
  id: string;
  date: string;
  time: string;
  customerId: string;
  customerName: string;
  bottleSizeId: string;
  bottleSizeName: string;
  quantity: number;
  transactionType: BottleTransactionType;
  unitSellingPrice: number;
  refillCost: number;
  deliveryCost: number;
  totalTransactionCost: number;
  revenue: number;
  profit: number;
  deliveryPerson: string;
  referenceDeliveryId: string;
  notes: string;
  timestamp: number;
}

export type MaterialCategory = 
  | 'Packing Material'
  | 'RO Plant Parts'
  | 'Vehicle Parts'
  | 'Bottle and Caps'
  | 'Tools'
  | 'Filter and Cartages'
  | 'Plumbing Items'
  | 'Electric Items'
  | 'General Items';

export type MaterialUOM = 
  | 'Piece'
  | 'Packet'
  | 'Carton'
  | 'Pair'
  | 'Liter'
  | 'Kg'
  | 'Gram'
  | 'Nos';

export type MaterialIssueTo = 
  | 'Issue to RO plant'
  | 'Issue For Production'
  | 'Issue to Driver'
  | 'Issue for Disposal';

export type MaterialUsageType = 
  | 'PRODUCTION_CONSUMABLE' 
  | 'MAINTENANCE_MATERIAL' 
  | 'CUSTOM' 
  | 'OTHER';

export type MaterialIssueCategory = 
  | 'PRODUCTION' 
  | 'MAINTENANCE' 
  | 'RO_PLANT' 
  | 'ADMIN' 
  | 'OTHER';

export type MaterialActionType = 'REFILL' | 'ISSUE' | 'ADJUSTMENT';

export interface FactoryMaterial {
  id: string;
  name: string;
  category: MaterialCategory;
  uom: MaterialUOM;
  purchaseRate: number;
  perPackQty: number;
  currentStock: number;
  openingStock: number;
  usageType?: MaterialUsageType;
  customUsageType?: string;
  defaultIssueCategory?: MaterialIssueCategory;
  issueTo?: MaterialIssueTo;
  active: boolean;
  supplierName: string;
  lastUpdated: number;
}

export interface MaterialTransaction {
  id: string;
  materialId: string;
  materialName: string;
  date: string;
  actionType: MaterialActionType;
  quantity: number;
  unitCost: number;
  totalCost: number;
  uom: string;
  issueCategory?: MaterialIssueCategory;
  supplierOrReceiver: string;
  invoiceNo: string;
  notes: string;
  balanceAfter: number;
  performedBy: string;
  timestamp: number;
}

export interface BottleCostingRecord {
  id: string;
  bottleSizeId: string;
  bottleSizeName: string;
  bottlePurchaseRate: number;
  packQty: number;
  labelSealPacketPrice: number;
  labelSealTotalPieces: number;
  labelSealPiecesUsedPerPack: number;
  labelSealCalculatedCost: number;
  cartonPolytheneCost: number;
  capCost: number;
  waterCost: number;
  labourCost: number;
  electricityCost: number;
  deliveryCost: number;
  totalCostPerPackOrBottle: number;
  salePrice: number;
  profitPerPackOrBottle: number;
  date: string;
  notes: string;
  updatedBy: string;
}

export type MonthlyCostCategory = 
  | 'RO_RENT' 
  | 'RO_MAINTENANCE' 
  | 'SALARIES' 
  | 'UTILITIES' 
  | 'VEHICLE_MAINTENANCE' 
  | 'OTHER';

export interface MonthlyRecurringExpense {
  id: string;
  category: MonthlyCostCategory;
  description: string;
  amount: number;
  month: string; // YYYY-MM
  date: string;
  notes: string;
  createdBy: string;
}

export type DeliveryStatus = 
  | 'PENDING' 
  | 'ASSIGNED' 
  | 'DELIVERED' 
  | 'PARTIALLY_DELIVERED' 
  | 'CANCELLED';

export interface DeliveryItem {
  bottleSizeId: string;
  bottleName: string;
  quantity: number;
  unitPrice: number;
  emptyCollected: number;
  lineTotal: number;
}

export interface Delivery {
  id: string;
  deliveryNumber: string;
  customerId: string;
  customerName: string;
  customerPhone: string;
  customerAddress: string;
  customerArea: string;
  date: string; // YYYY-MM-DD
  time: string;
  items: DeliveryItem[];
  totalFullDelivered: number;
  totalEmptyCollected: number;
  assignedStaffId: string;
  staffName: string;
  status: DeliveryStatus;
  deliveryCharges: number;
  subtotal: number;
  totalAmount: number;
  paymentCollected: number;
  paymentMethod: string; // Cash, JazzCash, Easypaisa, Unpaid
  notes: string;
  invoiceId: string;
  businessId: string;
  createdBy: string;
  createdAt: number;
  lastEditedAt?: number;
  lastEditedBy?: string;
}

export type InvoiceStatus = 'UNPAID' | 'PARTIALLY_PAID' | 'PAID';

export interface Invoice {
  id: string;
  invoiceNumber: string;
  customerId: string;
  customerName: string;
  deliveryId: string;
  date: string;
  dueDate: string;
  totalAmount: number;
  paidAmount: number;
  balanceDue: number;
  status: InvoiceStatus;
  itemsSummary: string;
  businessId: string;
  createdAt: number;
}

export type PaymentMethod = 
  | 'CASH' 
  | 'PAY_FROM_SALE'
  | 'INVESTMENT'
  | 'JAZZCASH' 
  | 'EASYPAISA' 
  | 'BANK_TRANSFER' 
  | 'ADVANCE_ADJUSTMENT';

export interface PaymentAllocation {
  invoiceId: string;
  invoiceNumber: string;
  allocatedAmount: number;
}

export interface Payment {
  id: string;
  receiptNumber: string;
  customerId: string;
  customerName: string;
  deliveryId?: string;
  amount: number;
  paymentMethod: PaymentMethod;
  allocations: PaymentAllocation[];
  advanceCredited: number;
  transactionRef: string;
  notes: string;
  date: string;
  receivedBy: string;
  receivedByRole: UserRole;
  isAcknowledged: boolean;
  acknowledgedBy: string;
  businessId: string;
  createdAt: number;
  lastEditedAt?: number;
  lastEditedBy?: string;
}

export interface LedgerEntry {
  id: string;
  customerId: string;
  date: string;
  type: 'INVOICE' | 'PAYMENT' | 'OPENING_BALANCE' | 'ADJUSTMENT' | 'SECURITY_DEPOSIT';
  referenceNumber: string;
  description: string;
  debitAmount: number;  // Increases customer debt
  creditAmount: number; // Decreases customer debt
  runningBalance: number;
  timestamp: number;
}

export type ExpenseType = 'OPEX' | 'CAPEX';

export interface ExpenseCategory {
  id: string;
  name: string;
  urduName: string;
  type: ExpenseType;
  iconName: string;
  isDefault: boolean;
  businessId: string;
}

export type PaymentSource = 'PAY_FROM_SALE' | 'INVESTMENT';

export interface Expense {
  id: string;
  voucherNumber: string;
  date: string;
  expenseType: ExpenseType;
  categoryId: string;
  categoryName: string;
  description: string;
  amount: number;
  paymentSource?: PaymentSource; // Pay from Sale (سیل سے ادائیگی) vs Investment (ذاتی سرمایہ)
  paymentMethod: PaymentMethod;  // Cash, Bank Transfer, JazzCash, Easypaisa
  payee: string;
  notes: string;
  enteredBy: string;
  enteredByRole: UserRole;
  isAcknowledged: boolean;
  acknowledgedBy: string;
  isApprovedByOwner: boolean;
  businessId: string;
  createdAt: number;
  lastEditedAt?: number;
  lastEditedBy?: string;
}

export interface CashClosing {
  id: string;
  date: string; // YYYY-MM-DD
  openingCash: number;
  customerCashCollected: number;
  otherCashIncome: number;
  cashExpenses: number;
  cashRefunds: number;
  expectedClosingCash: number;
  actualClosingCash: number;
  difference: number; // actual - expected
  denominationBreakdown?: Record<number, number>;
  notes: string;
  closedBy: string;
  isApprovedByOwner: boolean;
  businessId: string;
  closedAt: number;
}

export type UserRole = 'ADMIN' | 'INCHARGE' | 'VIEW_ONLY';

export interface UserProfile {
  id: string;
  username: string;
  name: string;
  email: string;
  phone: string;
  role: UserRole;
  businessId: string;
  active: boolean;
}

export interface UserAccount {
  id: string;
  username: string;
  password?: string;
  name: string;
  phone: string;
  role: UserRole;
  active: boolean;
  createdAt: number;
}

export interface PasswordResetRequest {
  id: string;
  username: string;
  fullName: string;
  role: UserRole;
  requestTime: string;
  reason: string;
  isResolved: boolean;
  resolvedAt?: string;
  resolvedBy?: string;
  newPasswordSet?: string;
}

export type NotificationSeverity = 'INFO' | 'SUCCESS' | 'WARNING' | 'ALERT';

export interface AppNotification {
  id: string;
  title: string;
  message: string;
  timeAgo: string;
  severity: NotificationSeverity;
  isRead: boolean;
  targetRole?: UserRole;
  timestamp: number;
}

export interface BusinessProfile {
  id: string;
  businessName: string;
  urduBusinessName: string;
  tagline: string;
  phone: string;
  whatsapp: string;
  address: string;
  city: string;
  currency: string;
  tdsTarget: string;
  phTarget: string;
  dailyCapacityLitres: number;
}
