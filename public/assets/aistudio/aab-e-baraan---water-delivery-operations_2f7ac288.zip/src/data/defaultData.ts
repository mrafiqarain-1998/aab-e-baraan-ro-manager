import { 
  Customer, 
  BottleSize, 
  BottleInventory, 
  FactoryMaterial, 
  ExpenseCategory, 
  Expense, 
  Delivery, 
  Invoice, 
  Payment, 
  BottleCostingRecord, 
  MonthlyRecurringExpense, 
  BusinessProfile,
  UserAccount,
  AppNotification,
  CustomerBottleAllocation,
  CustomerRate,
  LedgerEntry,
  CashClosing,
  PasswordResetRequest
} from '../types';

export const defaultBusinessProfile: BusinessProfile = {
  id: "aab_e_baraan_plant_01",
  businessName: "Aab-e-Baraan RO Water Plant",
  urduBusinessName: "آبِ باراں منرل واٹر پلانٹ",
  tagline: "Pure Mineral & Reverse Osmosis Drinking Water Service",
  phone: "+92 300 8472910",
  whatsapp: "923008472910",
  address: "Plot 42, Water Works Road, Industrial Area",
  city: "Lahore, Punjab, Pakistan",
  currency: "Rs.",
  tdsTarget: "120 - 145 PPM",
  phTarget: "7.2 - 7.6 pH",
  dailyCapacityLitres: 15000
};

export const defaultBottleSizes: BottleSize[] = [
  {
    id: "size_19l",
    name: "19 Litre Bottle",
    capacityLitres: 19.0,
    packQuantity: 1,
    defaultRefillPrice: 120.0,
    bottleSalePrice: 1200.0,
    depositAmount: 1000.0,
    replacementPrice: 800.0,
    active: true,
    refillCost: 35.0,
    deliveryCost: 20.0,
    deliveryUnit: "PER_BOTTLE",
    packetPackagingQty: 1,
    isReturnableBottle: true,
    uom: "Bottles",
    openingStock: 0,
    purchaseCost: 800.0,
    latestPurchaseRate: 800.0,
    usageType: "MULTIPLE_TIME",
    businessId: "aab_e_baraan_plant_01"
  },
  {
    id: "size_12l",
    name: "12.5 Litre Bottle",
    capacityLitres: 12.5,
    packQuantity: 1,
    defaultRefillPrice: 90.0,
    bottleSalePrice: 900.0,
    depositAmount: 800.0,
    replacementPrice: 650.0,
    active: true,
    refillCost: 25.0,
    deliveryCost: 15.0,
    deliveryUnit: "PER_BOTTLE",
    packetPackagingQty: 1,
    isReturnableBottle: true,
    uom: "Bottles",
    openingStock: 0,
    purchaseCost: 650.0,
    latestPurchaseRate: 650.0,
    usageType: "MULTIPLE_TIME",
    businessId: "aab_e_baraan_plant_01"
  },
  {
    id: "size_6l",
    name: "6 Litre Bottle (One-Time)",
    capacityLitres: 6.0,
    packQuantity: 1,
    defaultRefillPrice: 50.0,
    bottleSalePrice: 500.0,
    depositAmount: 0.0,
    replacementPrice: 0.0,
    active: true,
    refillCost: 15.0,
    deliveryCost: 12.0,
    deliveryUnit: "PER_BOTTLE",
    packetPackagingQty: 1,
    isReturnableBottle: false,
    uom: "Bottles",
    openingStock: 0,
    purchaseCost: 25.0,
    latestPurchaseRate: 25.0,
    usageType: "ONE_TIME",
    businessId: "aab_e_baraan_plant_01"
  },
  {
    id: "size_1_5l",
    name: "1.5L Pack (Carton of 6)",
    capacityLitres: 9.0,
    packQuantity: 6,
    defaultRefillPrice: 360.0,
    bottleSalePrice: 360.0,
    depositAmount: 0.0,
    replacementPrice: 0.0,
    active: true,
    refillCost: 120.0,
    deliveryCost: 40.0,
    deliveryUnit: "PER_PACKET",
    packetPackagingQty: 6,
    isReturnableBottle: false,
    uom: "Cartons",
    openingStock: 0,
    purchaseCost: 18.0,
    latestPurchaseRate: 18.0,
    usageType: "ONE_TIME",
    businessId: "aab_e_baraan_plant_01"
  },
  {
    id: "size_500ml",
    name: "500ml Pack (Carton of 12)",
    capacityLitres: 6.0,
    packQuantity: 12,
    defaultRefillPrice: 300.0,
    bottleSalePrice: 300.0,
    depositAmount: 0.0,
    replacementPrice: 0.0,
    active: true,
    refillCost: 144.0,
    deliveryCost: 50.0,
    deliveryUnit: "PER_PACKET",
    packetPackagingQty: 12,
    isReturnableBottle: false,
    uom: "Cartons",
    openingStock: 0,
    purchaseCost: 12.0,
    latestPurchaseRate: 12.0,
    usageType: "ONE_TIME",
    businessId: "aab_e_baraan_plant_01"
  }
];

export const defaultBottleInventory: BottleInventory[] = [
  {
    id: "inv_19l",
    bottleSizeId: "size_19l",
    sizeName: "19 Litre Bottle",
    atPlantFull: 0,
    atPlantEmpty: 0,
    withCustomers: 0,
    withStaff: 0,
    damaged: 0,
    totalPurchased: 0,
    totalIssuedOrSold: 0,
    businessId: "aab_e_baraan_plant_01"
  },
  {
    id: "inv_12l",
    bottleSizeId: "size_12l",
    sizeName: "12.5 Litre Bottle",
    atPlantFull: 0,
    atPlantEmpty: 0,
    withCustomers: 0,
    withStaff: 0,
    damaged: 0,
    totalPurchased: 0,
    totalIssuedOrSold: 0,
    businessId: "aab_e_baraan_plant_01"
  },
  {
    id: "inv_6l",
    bottleSizeId: "size_6l",
    sizeName: "6 Litre Bottle (One-Time)",
    atPlantFull: 0,
    atPlantEmpty: 0,
    withCustomers: 0,
    withStaff: 0,
    damaged: 0,
    totalPurchased: 0,
    totalIssuedOrSold: 0,
    businessId: "aab_e_baraan_plant_01"
  },
  {
    id: "inv_1_5l",
    bottleSizeId: "size_1_5l",
    sizeName: "1.5L Pack (Carton of 6)",
    atPlantFull: 0,
    atPlantEmpty: 0,
    withCustomers: 0,
    withStaff: 0,
    damaged: 0,
    totalPurchased: 0,
    totalIssuedOrSold: 0,
    businessId: "aab_e_baraan_plant_01"
  },
  {
    id: "inv_500ml",
    bottleSizeId: "size_500ml",
    sizeName: "500ml Pack (Carton of 12)",
    atPlantFull: 0,
    atPlantEmpty: 0,
    withCustomers: 0,
    withStaff: 0,
    damaged: 0,
    totalPurchased: 0,
    totalIssuedOrSold: 0,
    businessId: "aab_e_baraan_plant_01"
  }
];

// Clean fresh start: No dummy customers initially (users can add their own customers)
export const defaultCustomers: Customer[] = [];

export const defaultCustomerAllocations: CustomerBottleAllocation[] = [];
export const defaultCustomerRates: CustomerRate[] = [];

// Clean fresh start: No dummy deliveries, invoices, payments, or ledger entries
export const defaultDeliveries: Delivery[] = [];
export const defaultInvoices: Invoice[] = [];
export const defaultPayments: Payment[] = [];
export const defaultLedgerEntries: LedgerEntry[] = [];
export const defaultCashClosings: CashClosing[] = [];
export const defaultExpenses: Expense[] = [];

export const defaultExpenseCategories: ExpenseCategory[] = [
  { id: "cat_ro_maint", name: "RO maintenance", urduName: "آر او پلانٹ مرمت و سروس", type: "OPEX", iconName: "Wrench", isDefault: true, businessId: "aab_e_baraan_plant_01" },
  { id: "cat_vehicle_maint", name: "Vehicle maintenance", urduName: "گاڑی کی مرمت و مینٹیننس", type: "OPEX", iconName: "Truck", isDefault: true, businessId: "aab_e_baraan_plant_01" },
  { id: "cat_salary", name: "Staff Salary", urduName: "عملے کی ماہانہ تنخواہ", type: "OPEX", iconName: "Users", isDefault: true, businessId: "aab_e_baraan_plant_01" },
  { id: "cat_fuel_rent", name: "Fuel/vehciel Rent", urduName: "فیول / گاڑی کرایہ", type: "OPEX", iconName: "Fuel", isDefault: true, businessId: "aab_e_baraan_plant_01" },
  { id: "cat_raw_material", name: "Raw Material", urduName: "خام مال و منرلز", type: "OPEX", iconName: "FlaskConical", isDefault: true, businessId: "aab_e_baraan_plant_01" },
  { id: "cat_packing_mat", name: "Packing Material", urduName: "پیکنگ مٹیریل و سیلز", type: "OPEX", iconName: "Package", isDefault: true, businessId: "aab_e_baraan_plant_01" },
  { id: "cat_asset_machinery", name: "Assest/Machinery", urduName: "اثاثہ جات و پلانٹ مشینری", type: "CAPEX", iconName: "Cpu", isDefault: true, businessId: "aab_e_baraan_plant_01" },
  { id: "cat_entertainment", name: "Entertainment", urduName: "انٹرٹینمنٹ و مہمان نوازی", type: "OPEX", iconName: "Coffee", isDefault: true, businessId: "aab_e_baraan_plant_01" },
  { id: "cat_others", name: "Others", urduName: "دیگر متفرق اخراجات", type: "OPEX", iconName: "MoreHorizontal", isDefault: true, businessId: "aab_e_baraan_plant_01" }
];

export const defaultFactoryMaterials: FactoryMaterial[] = [
  {
    id: "mat_caps_19l",
    name: "19L Blue Sealed Caps",
    category: "Bottle and Caps",
    uom: "Piece",
    purchaseRate: 3.5,
    perPackQty: 1000,
    currentStock: 4500,
    openingStock: 5000,
    usageType: "PRODUCTION_CONSUMABLE",
    defaultIssueCategory: "PRODUCTION",
    issueTo: "Issue For Production",
    active: true,
    supplierName: "Pak Caps & Plastic Karachi",
    lastUpdated: Date.now()
  },
  {
    id: "mat_seals_19l",
    name: "19L Heat Shrink Neck Seals",
    category: "Packing Material",
    uom: "Piece",
    purchaseRate: 0.85,
    perPackQty: 2000,
    currentStock: 6200,
    openingStock: 8000,
    usageType: "PRODUCTION_CONSUMABLE",
    defaultIssueCategory: "PRODUCTION",
    issueTo: "Issue For Production",
    active: true,
    supplierName: "Al-Rehman Packaging Lahore",
    lastUpdated: Date.now()
  },
  {
    id: "mat_filter_sediment",
    name: "20-Inch Jumbo Sediment Filters (5 Micron)",
    category: "Filter and Cartages",
    uom: "Piece",
    purchaseRate: 650.0,
    perPackQty: 25,
    currentStock: 18,
    openingStock: 25,
    usageType: "MAINTENANCE_MATERIAL",
    defaultIssueCategory: "RO_PLANT",
    issueTo: "Issue to RO plant",
    active: true,
    supplierName: "Water Engineering Solutions",
    lastUpdated: Date.now()
  },
  {
    id: "mat_filter_carbon",
    name: "20-Inch Jumbo Activated Carbon Block CTO",
    category: "Filter and Cartages",
    uom: "Piece",
    purchaseRate: 1450.0,
    perPackQty: 12,
    currentStock: 8,
    openingStock: 12,
    usageType: "MAINTENANCE_MATERIAL",
    defaultIssueCategory: "RO_PLANT",
    issueTo: "Issue to RO plant",
    active: true,
    supplierName: "Water Engineering Solutions",
    lastUpdated: Date.now()
  }
];

export const defaultBottleCostings: BottleCostingRecord[] = [
  {
    id: "cost_19l",
    bottleSizeId: "size_19l",
    bottleSizeName: "19 Litre Bottle",
    bottlePurchaseRate: 800.0,
    packQty: 1,
    labelSealPacketPrice: 1700.0,
    labelSealTotalPieces: 2000,
    labelSealPiecesUsedPerPack: 1,
    labelSealCalculatedCost: 0.85,
    cartonPolytheneCost: 0.0,
    capCost: 3.50,
    waterCost: 5.50,
    labourCost: 12.00,
    electricityCost: 9.50,
    deliveryCost: 20.00,
    totalCostPerPackOrBottle: 51.35,
    salePrice: 120.0,
    profitPerPackOrBottle: 68.65,
    date: new Date().toISOString().split('T')[0],
    notes: "Standard 19L Refill Costing with RO backwash power",
    updatedBy: "Admin"
  }
];

export const defaultMonthlyRecurringExpenses: MonthlyRecurringExpense[] = [
  {
    id: "mre_rent_1",
    category: "RO_RENT",
    description: "RO Plant Building & Warehouse Monthly Rent",
    amount: 45000.0,
    month: new Date().toISOString().slice(0, 7),
    date: new Date().toISOString().split('T')[0],
    notes: "Paid via bank transfer",
    createdBy: "Admin"
  }
];

// User Accounts - Primary Admin (admin/admin123)
export const defaultUserAccounts: UserAccount[] = [
  {
    id: "user_admin_01",
    username: "admin",
    password: "admin123",
    name: "Muhammad Rafiq (Admin)",
    phone: "0300-8472910",
    role: "ADMIN",
    active: true,
    createdAt: Date.now()
  }
];

export const defaultNotifications: AppNotification[] = [
  {
    id: "notif_1",
    title: "RO Water Plant Online & Balanced",
    message: "TDS is at 135 PPM (Optimal). Current pressure 14 bar. Ready for full day operations.",
    timeAgo: "Just now",
    severity: "SUCCESS",
    isRead: false,
    timestamp: Date.now()
  }
];
