import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  Customer,
  BottleSize,
  BottleInventory,
  FactoryMaterial,
  ExpenseCategory,
  Expense,
  Delivery,
  Invoice,
  Payment,
  BottleCostingRecord,
  MonthlyRecurringExpense,
  BusinessProfile,
  UserAccount,
  UserProfile,
  AppNotification,
  CustomerBottleAllocation,
  CustomerRate,
  LedgerEntry,
  CashClosing,
  UserRole,
  DeliveryItem,
  RateHistoryEntry,
  InvoiceStatus,
  MaterialCategory,
  MaterialUOM,
  MaterialIssueTo,
  PaymentMethod,
  PaymentSource
} from '../types';
import {
  defaultBusinessProfile,
  defaultBottleSizes,
  defaultBottleInventory,
  defaultCustomers,
  defaultCustomerAllocations,
  defaultCustomerRates,
  defaultExpenseCategories,
  defaultExpenses,
  defaultFactoryMaterials,
  defaultBottleCostings,
  defaultMonthlyRecurringExpenses,
  defaultDeliveries,
  defaultInvoices,
  defaultPayments,
  defaultLedgerEntries,
  defaultCashClosings,
  defaultUserAccounts,
  defaultNotifications
} from '../data/defaultData';
import { 
  db, 
  auth, 
  googleProvider, 
  testConnection, 
  handleFirestoreError, 
  OperationType 
} from '../services/firebase';
import { 
  collection, 
  doc, 
  setDoc, 
  deleteDoc, 
  onSnapshot 
} from 'firebase/firestore';
import { signInWithPopup } from 'firebase/auth';

export type AppTab = 
  | 'dashboard' 
  | 'deliveries' 
  | 'customers' 
  | 'payments' 
  | 'cashclosing' 
  | 'inventory' 
  | 'expenses' 
  | 'reports' 
  | 'users' 
  | 'backup';

interface WaterAppContextType {
  // Authentication & Session
  isAuthenticated: boolean;
  currentUser: UserProfile;
  login: (username: string, password: string) => { success: boolean; error?: string };
  loginWithGoogle: () => Promise<{ success: boolean; error?: string }>;
  logout: () => void;
  switchUserWithCredentials: (username: string, password: string) => { success: boolean; error?: string };
  requestPasswordReset: (username: string, reason: string) => void;
  
  // User Accounts
  userAccounts: UserAccount[];
  addUserAccount: (user: Omit<UserAccount, 'id' | 'createdAt'>) => void;
  updateUserAccount: (user: UserAccount) => void;
  deleteUserAccount: (id: string) => void;
  
  // Business Profile & System Settings
  businessProfile: BusinessProfile;
  updateBusinessProfile: (profile: Partial<BusinessProfile>) => void;
  bottleSizes: BottleSize[];
  bottleInventory: BottleInventory[];
  customers: Customer[];
  customerAllocations: CustomerBottleAllocation[];
  customerRates: CustomerRate[];
  deliveries: Delivery[];
  invoices: Invoice[];
  payments: Payment[];
  ledgerEntries: LedgerEntry[];
  expenses: Expense[];
  expenseCategories: ExpenseCategory[];
  factoryMaterials: FactoryMaterial[];
  bottleCostings: BottleCostingRecord[];
  monthlyRecurringExpenses: MonthlyRecurringExpense[];
  cashClosings: CashClosing[];
  notifications: AppNotification[];
  isDarkMode: boolean;
  toggleDarkMode: () => void;
  viewMode: 'mobile' | 'desktop';
  toggleViewMode: () => void;
  activeTab: AppTab;
  setActiveTab: (tab: AppTab) => void;
  
  // Operational Methods
  createDelivery: (delivery: {
    customerId: string;
    items: DeliveryItem[];
    assignedStaffName: string;
    deliveryCharges: number;
    paymentCollected: number;
    paymentMethod: string;
    notes?: string;
  }) => { success: boolean; deliveryId?: string; error?: string };

  updateDeliveryStatus: (deliveryId: string, status: Delivery['status']) => void;
  
  receivePayment: (payment: {
    customerId: string;
    amount: number;
    paymentMethod: Payment['paymentMethod'];
    transactionRef?: string;
    notes?: string;
  }) => { success: boolean; receiptNumber?: string };

  addCustomer: (customer: Omit<Customer, 'id' | 'customerCode' | 'currentBalance' | 'emptyBottlesOwed' | 'totalPurchases' | 'businessId'>) => string;
  updateCustomer: (customer: Customer) => void;
  setCustomerPrice: (customerId: string, bottleSizeId: string, customPrice: number, effectiveDate?: string) => void;
  
  updateDelivery: (deliveryId: string, updated: {
    items: DeliveryItem[];
    deliveryCharges: number;
    paymentCollected: number;
    paymentMethod: string;
    notes?: string;
    date?: string;
  }) => { success: boolean; error?: string };

  payForDelivery: (params: {
    deliveryId: string;
    amount: number;
    paymentMethod: Payment['paymentMethod'];
    transactionRef?: string;
    notes?: string;
    date?: string;
  }) => { success: boolean; receiptNumber?: string; error?: string };

  updateExpense: (expenseId: string, updated: Partial<Expense>) => { success: boolean; error?: string };

  updatePayment: (paymentId: string, updated: {
    amount: number;
    paymentMethod: Payment['paymentMethod'];
    transactionRef?: string;
    notes?: string;
    date?: string;
  }) => { success: boolean; error?: string };
  
  collectEmptyBottles: (customerId: string, count: number, notes?: string) => void;
  
  recordRefillBatch: (bottleSizeId: string, quantityFilled: number, operatorName: string, notes?: string) => void;
  purchaseBottles: (bottleSizeId: string, quantity: number, unitCost: number, supplierName: string, paymentSource?: PaymentSource, paymentMethod?: PaymentMethod) => void;
  recordDamagedBottles: (bottleSizeId: string, quantity: number, customerId?: string, notes?: string) => void;
  issueBottles: (params: {
    targetType: 'CUSTOMER' | 'RO_PLANT';
    customerId?: string;
    customerName?: string;
    bottleSizeId: string;
    quantity: number;
    notes?: string;
  }) => { success: boolean; error?: string };
  resetAllBottleStocksToZero: () => void;
  
  addFactoryMaterial: (material: Omit<FactoryMaterial, 'id' | 'lastUpdated'>) => void;
  updateFactoryMaterial: (id: string, updates: Partial<FactoryMaterial>) => void;
  deleteFactoryMaterial: (id: string) => void;
  issueMaterial: (materialId: string, quantity: number, issueTo: MaterialIssueTo | string, notes?: string) => void;
  refillMaterial: (materialId: string, quantity: number, unitCost: number, supplier: string) => void;
  
  addExpense: (expense: Omit<Expense, 'id' | 'voucherNumber' | 'createdAt' | 'businessId'>) => void;
  approveExpense: (expenseId: string) => void;
  
  recordCashClosing: (closing: {
    openingCash: number;
    customerCashCollected: number;
    otherCashIncome: number;
    cashExpenses: number;
    actualClosingCash: number;
    denominationBreakdown?: Record<number, number>;
    notes?: string;
  }) => void;
  
  updateBottleCosting: (costing: BottleCostingRecord) => void;
  
  // Bottle Size Management (Admin)
  addBottleSize: (bottleSize: Omit<BottleSize, 'id' | 'businessId'>) => { success: boolean; id?: string; error?: string };
  updateBottleSize: (bottleSize: BottleSize) => { success: boolean; error?: string };
  deleteBottleSize: (bottleSizeId: string) => { success: boolean; error?: string };
  
  // Admin-Only Deletion Functions
  deleteDelivery: (deliveryId: string) => { success: boolean; error?: string };
  deletePayment: (paymentId: string) => { success: boolean; error?: string };
  deleteExpense: (expenseId: string) => { success: boolean; error?: string };
  deleteCustomer: (customerId: string, force?: boolean) => { 
    success: boolean; 
    error?: string; 
    hasPendingItems?: boolean; 
    dues?: number; 
    bottles?: number 
  };
  
  // Data Maintenance & Backups
  resetToDemoData: () => void;
  exportBackupJson: () => string;
  importBackupJson: (json: string) => boolean;
  markNotificationAsRead: (id: string) => void;
  clearAllNotifications: () => void;
}

const WaterAppContext = createContext<WaterAppContextType | null>(null);

const STORAGE_KEY_PREFIX = 'aab_e_baraan_';
const DATA_VERSION_KEY = 'v8_strict_auth_required_prod';

function loadFromStorage<T>(key: string, defaultValue: T): T {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_PREFIX + key);
    if (!raw) return defaultValue;
    return JSON.parse(raw);
  } catch (e) {
    console.error(`Failed to load ${key} from storage`, e);
    return defaultValue;
  }
}

function saveToStorage<T>(key: string, value: T) {
  try {
    localStorage.setItem(STORAGE_KEY_PREFIX + key, JSON.stringify(value));
  } catch (e) {
    console.error(`Failed to save ${key} to storage`, e);
  }
}

export const WaterAppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Check and purge legacy dummy data so the user gets clean, real records
  useEffect(() => {
    try {
      const currentVersion = localStorage.getItem(STORAGE_KEY_PREFIX + 'data_version');
      if (currentVersion !== DATA_VERSION_KEY) {
        // Reset cached dummy customers, deliveries, expenses, payments
        localStorage.removeItem(STORAGE_KEY_PREFIX + 'customers');
        localStorage.removeItem(STORAGE_KEY_PREFIX + 'deliveries');
        localStorage.removeItem(STORAGE_KEY_PREFIX + 'invoices');
        localStorage.removeItem(STORAGE_KEY_PREFIX + 'payments');
        localStorage.removeItem(STORAGE_KEY_PREFIX + 'expenses');
        localStorage.removeItem(STORAGE_KEY_PREFIX + 'cash_closings');
        localStorage.removeItem(STORAGE_KEY_PREFIX + 'ledger_entries');
        localStorage.removeItem(STORAGE_KEY_PREFIX + 'customer_allocations');
        localStorage.removeItem(STORAGE_KEY_PREFIX + 'customer_rates');
        
        // Clear automatic session to force fresh login with credentials
        localStorage.removeItem(STORAGE_KEY_PREFIX + 'is_authenticated');
        localStorage.removeItem(STORAGE_KEY_PREFIX + 'current_user');
        
        // Remove supervisor aslam if cached
        const cachedUsers = loadFromStorage<UserAccount[]>('user_accounts', defaultUserAccounts);
        const filteredUsers = cachedUsers.filter(u => u.username.toLowerCase() !== 'aslam');
        saveToStorage('user_accounts', filteredUsers);

        localStorage.setItem(STORAGE_KEY_PREFIX + 'data_version', DATA_VERSION_KEY);
      }
    } catch (e) {
      console.warn("Storage cleanup error:", e);
    }
  }, []);

  // Always clean up any legacy persistent auth tokens on startup
  try {
    localStorage.removeItem(STORAGE_KEY_PREFIX + 'is_authenticated');
  } catch {}

  // Strict Authentication State: ALWAYS FALSE on page load.
  // The user MUST explicitly enter their password on every session.
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);

  const [currentUser, setCurrentUser] = useState<UserProfile>(() => {
    try {
      const isAuth = localStorage.getItem(STORAGE_KEY_PREFIX + 'is_authenticated') === 'true';
      if (isAuth) {
        const saved = loadFromStorage<UserProfile | null>('current_user', null);
        if (saved && saved.name) {
          saved.name = saved.name.replace(' (Admin / Owner)', ' (Admin)').replace(' / Owner', '').replace(' / مالک', '');
          return saved;
        }
      }
    } catch (e) {
      console.warn("Error reading current user:", e);
    }
    return {
      id: "unauthenticated",
      username: "",
      name: "Please Log In",
      email: "",
      phone: "",
      role: "STAFF" as UserRole,
      businessId: "aab_e_baraan_plant_01",
      active: false
    };
  });

  const [userAccounts, setUserAccounts] = useState<UserAccount[]>(() => {
    const loaded = loadFromStorage('user_accounts', defaultUserAccounts);
    return loaded
      .filter(u => u.username.toLowerCase() !== 'aslam')
      .map(u => {
        let name = u.name;
        if (name && (name.includes('Owner') || name.includes('مالک'))) {
          name = name.replace(' (Admin / Owner)', ' (Admin)').replace(' / Owner', '').replace(' / مالک', '');
        }
        let updated = { ...u, name };
        if (u.username.toLowerCase() === 'admin' && (!u.password || u.password !== 'admin123')) {
          updated.password = 'admin123';
        }
        return updated;
      });
  });

  const [viewMode, setViewMode] = useState<'mobile' | 'desktop'>('desktop');
  const [activeTab, setActiveTab] = useState<AppTab>('dashboard');
  const [isDarkMode, setIsDarkMode] = useState<boolean>(false);

  const [businessProfile, setBusinessProfile] = useState<BusinessProfile>(() => 
    loadFromStorage('business_profile', defaultBusinessProfile)
  );

  const [bottleSizes, setBottleSizes] = useState<BottleSize[]>(() => 
    loadFromStorage('bottle_sizes', defaultBottleSizes)
  );

  const [bottleInventory, setBottleInventory] = useState<BottleInventory[]>(() => 
    loadFromStorage('bottle_inventory', defaultBottleInventory)
  );

  // Clean empty defaults: no dummy records
  const [customers, setCustomers] = useState<Customer[]>(() => 
    loadFromStorage('customers', defaultCustomers)
  );

  const [customerAllocations, setCustomerAllocations] = useState<CustomerBottleAllocation[]>(() => 
    loadFromStorage('customer_allocations', defaultCustomerAllocations)
  );

  const [customerRates, setCustomerRates] = useState<CustomerRate[]>(() => 
    loadFromStorage('customer_rates', defaultCustomerRates)
  );

  const [deliveries, setDeliveries] = useState<Delivery[]>(() => 
    loadFromStorage('deliveries', defaultDeliveries)
  );

  const [invoices, setInvoices] = useState<Invoice[]>(() => 
    loadFromStorage('invoices', defaultInvoices)
  );

  const [payments, setPayments] = useState<Payment[]>(() => 
    loadFromStorage('payments', defaultPayments)
  );

  const [ledgerEntries, setLedgerEntries] = useState<LedgerEntry[]>(() => 
    loadFromStorage('ledger_entries', defaultLedgerEntries)
  );

  const [expenses, setExpenses] = useState<Expense[]>(() => 
    loadFromStorage('expenses', defaultExpenses)
  );

  const [expenseCategories, setExpenseCategories] = useState<ExpenseCategory[]>(() => {
    const saved = loadFromStorage('expense_categories', defaultExpenseCategories);
    if (!saved || !saved.length || !saved.some((c: ExpenseCategory) => c.name === 'RO maintenance' || c.id === 'cat_ro_maint')) {
      return defaultExpenseCategories;
    }
    return saved;
  });

  const [factoryMaterials, setFactoryMaterials] = useState<FactoryMaterial[]>(() => {
    const saved = loadFromStorage('factory_materials', defaultFactoryMaterials);
    if (!saved || !saved.length) return defaultFactoryMaterials;
    return saved.map((m: any) => ({
      ...m,
      category: m.category || 'General Items',
      uom: m.uom || 'Piece',
      issueTo: m.issueTo || 'Issue For Production'
    }));
  });

  const [bottleCostings, setBottleCostings] = useState<BottleCostingRecord[]>(() => 
    loadFromStorage('bottle_costings', defaultBottleCostings)
  );

  const [monthlyRecurringExpenses, setMonthlyRecurringExpenses] = useState<MonthlyRecurringExpense[]>(() => 
    loadFromStorage('monthly_expenses', defaultMonthlyRecurringExpenses)
  );

  const [cashClosings, setCashClosings] = useState<CashClosing[]>(() => 
    loadFromStorage('cash_closings', defaultCashClosings)
  );

  const [notifications, setNotifications] = useState<AppNotification[]>(() => 
    loadFromStorage('notifications', defaultNotifications)
  );

  // Sync to local storage
  useEffect(() => { 
    localStorage.setItem(STORAGE_KEY_PREFIX + 'is_authenticated', isAuthenticated ? 'true' : 'false');
  }, [isAuthenticated]);
  useEffect(() => { saveToStorage('current_user', currentUser); }, [currentUser]);
  useEffect(() => { saveToStorage('business_profile', businessProfile); }, [businessProfile]);
  useEffect(() => { saveToStorage('bottle_sizes', bottleSizes); }, [bottleSizes]);
  useEffect(() => { saveToStorage('bottle_inventory', bottleInventory); }, [bottleInventory]);
  useEffect(() => { saveToStorage('customers', customers); }, [customers]);
  useEffect(() => { saveToStorage('customer_allocations', customerAllocations); }, [customerAllocations]);
  useEffect(() => { saveToStorage('customer_rates', customerRates); }, [customerRates]);
  useEffect(() => { saveToStorage('deliveries', deliveries); }, [deliveries]);
  useEffect(() => { saveToStorage('invoices', invoices); }, [invoices]);
  useEffect(() => { saveToStorage('payments', payments); }, [payments]);
  useEffect(() => { saveToStorage('ledger_entries', ledgerEntries); }, [ledgerEntries]);
  useEffect(() => { saveToStorage('expenses', expenses); }, [expenses]);
  useEffect(() => { saveToStorage('expense_categories', expenseCategories); }, [expenseCategories]);
  useEffect(() => { saveToStorage('factory_materials', factoryMaterials); }, [factoryMaterials]);
  useEffect(() => { saveToStorage('bottle_costings', bottleCostings); }, [bottleCostings]);
  useEffect(() => { saveToStorage('monthly_expenses', monthlyRecurringExpenses); }, [monthlyRecurringExpenses]);
  useEffect(() => { saveToStorage('cash_closings', cashClosings); }, [cashClosings]);
  useEffect(() => { saveToStorage('user_accounts', userAccounts); }, [userAccounts]);
  useEffect(() => { saveToStorage('notifications', notifications); }, [notifications]);

  // REAL-TIME CENTRALIZED FIRESTORE SYNCHRONIZATION
  useEffect(() => {
    testConnection();

    // 1. Business Profile
    const unsubProfile = onSnapshot(doc(db, 'businessProfile', 'aab_e_baraan_plant_01'), (snap) => {
      if (snap.exists()) {
        const data = snap.data() as BusinessProfile;
        setBusinessProfile(data);
      } else {
        setDoc(doc(db, 'businessProfile', 'aab_e_baraan_plant_01'), defaultBusinessProfile).catch(() => {});
      }
    }, (err) => console.warn('businessProfile sync notice:', err.message));

    // 2. Bottle Sizes
    const unsubSizes = onSnapshot(collection(db, 'bottleSizes'), (snap) => {
      if (!snap.empty) {
        setBottleSizes(snap.docs.map(d => d.data() as BottleSize));
      } else {
        defaultBottleSizes.forEach(s => setDoc(doc(db, 'bottleSizes', s.id), s).catch(() => {}));
      }
    }, (err) => console.warn('bottleSizes sync notice:', err.message));

    // 3. Bottle Inventory
    const unsubInv = onSnapshot(collection(db, 'bottleInventory'), (snap) => {
      if (!snap.empty) {
        setBottleInventory(snap.docs.map(d => d.data() as BottleInventory));
      } else {
        defaultBottleInventory.forEach(inv => setDoc(doc(db, 'bottleInventory', inv.id), inv).catch(() => {}));
      }
    }, (err) => console.warn('bottleInventory sync notice:', err.message));

    // 4. Customers
    const unsubCust = onSnapshot(collection(db, 'customers'), (snap) => {
      setCustomers(snap.docs.map(d => d.data() as Customer));
    }, (err) => console.warn('customers sync notice:', err.message));

    // 5. Customer Allocations
    const unsubAlloc = onSnapshot(collection(db, 'customerAllocations'), (snap) => {
      setCustomerAllocations(snap.docs.map(d => d.data() as CustomerBottleAllocation));
    }, (err) => console.warn('customerAllocations sync notice:', err.message));

    // 6. Customer Rates
    const unsubRates = onSnapshot(collection(db, 'customerRates'), (snap) => {
      setCustomerRates(snap.docs.map(d => d.data() as CustomerRate));
    }, (err) => console.warn('customerRates sync notice:', err.message));

    // 7. Deliveries
    const unsubDeliv = onSnapshot(collection(db, 'deliveries'), (snap) => {
      const items = snap.docs.map(d => d.data() as Delivery);
      items.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
      setDeliveries(items);
    }, (err) => console.warn('deliveries sync notice:', err.message));

    // 8. Invoices
    const unsubInvcs = onSnapshot(collection(db, 'invoices'), (snap) => {
      setInvoices(snap.docs.map(d => d.data() as Invoice));
    }, (err) => console.warn('invoices sync notice:', err.message));

    // 9. Payments
    const unsubPayments = onSnapshot(collection(db, 'payments'), (snap) => {
      const items = snap.docs.map(d => d.data() as Payment);
      items.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
      setPayments(items);
    }, (err) => console.warn('payments sync notice:', err.message));

    // 10. Ledger Entries
    const unsubLedger = onSnapshot(collection(db, 'ledgerEntries'), (snap) => {
      setLedgerEntries(snap.docs.map(d => d.data() as LedgerEntry));
    }, (err) => console.warn('ledgerEntries sync notice:', err.message));

    // 11. Expenses
    const unsubExpenses = onSnapshot(collection(db, 'expenses'), (snap) => {
      const items = snap.docs.map(d => d.data() as Expense);
      items.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
      setExpenses(items);
    }, (err) => console.warn('expenses sync notice:', err.message));

    // 12. Expense Categories
    const unsubExpCat = onSnapshot(collection(db, 'expenseCategories'), (snap) => {
      if (!snap.empty) {
        setExpenseCategories(snap.docs.map(d => d.data() as ExpenseCategory));
      } else {
        defaultExpenseCategories.forEach(c => setDoc(doc(db, 'expenseCategories', c.id), c).catch(() => {}));
      }
    }, (err) => console.warn('expenseCategories sync notice:', err.message));

    // 13. Factory Materials
    const unsubMat = onSnapshot(collection(db, 'factoryMaterials'), (snap) => {
      if (!snap.empty) {
        setFactoryMaterials(snap.docs.map(d => d.data() as FactoryMaterial));
      } else {
        defaultFactoryMaterials.forEach(m => setDoc(doc(db, 'factoryMaterials', m.id), m).catch(() => {}));
      }
    }, (err) => console.warn('factoryMaterials sync notice:', err.message));

    // 14. Bottle Costings
    const unsubCost = onSnapshot(collection(db, 'bottleCostings'), (snap) => {
      if (!snap.empty) {
        setBottleCostings(snap.docs.map(d => d.data() as BottleCostingRecord));
      } else {
        defaultBottleCostings.forEach(bc => setDoc(doc(db, 'bottleCostings', bc.id), bc).catch(() => {}));
      }
    }, (err) => console.warn('bottleCostings sync notice:', err.message));

    // 15. Monthly Recurring Expenses
    const unsubMre = onSnapshot(collection(db, 'monthlyRecurringExpenses'), (snap) => {
      setMonthlyRecurringExpenses(snap.docs.map(d => d.data() as MonthlyRecurringExpense));
    }, (err) => console.warn('monthlyRecurringExpenses sync notice:', err.message));

    // 16. Cash Closings (sorted descending by closedAt / date)
    const unsubClosings = onSnapshot(collection(db, 'cashClosings'), (snap) => {
      const items = snap.docs.map(d => d.data() as CashClosing);
      items.sort((a, b) => (b.closedAt || 0) - (a.closedAt || 0));
      setCashClosings(items);
    }, (err) => console.warn('cashClosings sync notice:', err.message));

    // 17. User Accounts
    const unsubUsers = onSnapshot(collection(db, 'userAccounts'), (snap) => {
      if (!snap.empty) {
        const items = snap.docs
          .map(d => d.data() as UserAccount)
          .filter(u => u.username.toLowerCase() !== 'aslam');
        setUserAccounts(items);
      } else {
        defaultUserAccounts.forEach(u => setDoc(doc(db, 'userAccounts', u.id), u).catch(() => {}));
      }
    }, (err) => console.warn('userAccounts sync notice:', err.message));

    // 18. Notifications
    const unsubNotifs = onSnapshot(collection(db, 'notifications'), (snap) => {
      if (!snap.empty) {
        const items = snap.docs.map(d => d.data() as AppNotification);
        items.sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0));
        setNotifications(items);
      }
    }, (err) => console.warn('notifications sync notice:', err.message));

    return () => {
      unsubProfile();
      unsubSizes();
      unsubInv();
      unsubCust();
      unsubAlloc();
      unsubRates();
      unsubDeliv();
      unsubInvcs();
      unsubPayments();
      unsubLedger();
      unsubExpenses();
      unsubExpCat();
      unsubMat();
      unsubCost();
      unsubMre();
      unsubClosings();
      unsubUsers();
      unsubNotifs();
    };
  }, []);

  // RESET ALL BOTTLE STOCKS & HELD BOTTLES TO ZERO (User requirement)
  const resetAllBottleStocksToZero = () => {
    setBottleInventory(prev => {
      const updated = prev.map(inv => ({
        ...inv,
        atPlantFull: 0,
        atPlantEmpty: 0,
        withCustomers: 0,
        withStaff: 0,
        damaged: 0,
        totalPurchased: 0,
        totalIssuedOrSold: 0
      }));
      updated.forEach(inv => setDoc(doc(db, 'bottleInventory', inv.id), inv).catch(() => {}));
      return updated;
    });

    setCustomers(prev => {
      const updated = prev.map(c => ({
        ...c,
        emptyBottlesOwed: 0
      }));
      updated.forEach(c => setDoc(doc(db, 'customers', c.id), c).catch(() => {}));
      return updated;
    });

    setCustomerAllocations(prev => {
      const updated = prev.map(a => ({
        ...a,
        emptyHeld: 0,
        totalIssued: 0,
        returnedCount: 0,
        damagedCount: 0
      }));
      updated.forEach(a => setDoc(doc(db, 'customerAllocations', a.id), a).catch(() => {}));
      return updated;
    });
  };

  // Run auto-zeroing once for existing browser cache
  useEffect(() => {
    const hasZeroed = localStorage.getItem('aab_e_baraan_stock_zeroed_v4');
    if (!hasZeroed) {
      resetAllBottleStocksToZero();
      localStorage.setItem('aab_e_baraan_stock_zeroed_v4', 'true');
    }
  }, []);

  // LOGIN METHOD
  const login = (username: string, pass: string): { success: boolean; error?: string } => {
    const cleanUser = username.trim().toLowerCase();
    const cleanPass = pass.trim();

    // Direct guarantee for Admin account
    if (cleanUser === 'admin' && (cleanPass === 'admin123' || cleanPass === 'admin')) {
      const adminAcc = userAccounts.find(u => u.username.toLowerCase() === 'admin');
      const profile: UserProfile = {
        id: adminAcc?.id || "user_admin_01",
        username: "admin",
        name: adminAcc?.name ? adminAcc.name.replace(' (Admin / Owner)', ' (Admin)').replace(' / Owner', '') : "Muhammad Rafiq (Admin)",
        email: "aabebaraan@gmail.com",
        phone: adminAcc?.phone || "+92 300 8472910",
        role: "ADMIN" as UserRole,
        businessId: "aab_e_baraan_plant_01",
        active: true
      };
      setCurrentUser(profile);
      setIsAuthenticated(true);
      saveToStorage('current_user', profile);
      saveToStorage('is_authenticated', true);
      return { success: true };
    }

    // Dynamic user accounts check
    const account = userAccounts.find(
      u => u.username.toLowerCase() === cleanUser && 
      (u.password?.trim() === cleanPass || 
       (u.username.toLowerCase() === 'admin' && cleanPass === 'admin123'))
    );

    if (account) {
      if (!account.active) {
        return { success: false, error: 'This user account is currently deactivated by Admin.' };
      }

      const profile: UserProfile = {
        id: account.id,
        username: account.username,
        name: account.name,
        email: `${account.username}@aabebaraan.com`,
        phone: account.phone,
        role: account.role,
        businessId: "aab_e_baraan_plant_01",
        active: true
      };
      setCurrentUser(profile);
      setIsAuthenticated(true);
      saveToStorage('current_user', profile);
      saveToStorage('is_authenticated', true);
      return { success: true };
    }

    return { 
      success: false, 
      error: 'Incorrect username or password. (غلط یوزر نیم یا پاس ورڈ)' 
    };
  };

  // GOOGLE LOGIN METHOD (FIREBASE AUTHENTICATION)
  const loginWithGoogle = async (): Promise<{ success: boolean; error?: string }> => {
    try {
      const result = await signInWithPopup(auth, googleProvider);
      const fbUser = result.user;
      const email = (fbUser.email || '').toLowerCase();
      const isMasterAdmin = email === 'mrafiqarain1998@gmail.com' || email.includes('rafiq');

      const userProfile: UserProfile = {
        id: fbUser.uid,
        username: email.split('@')[0] || 'admin',
        name: fbUser.displayName || (isMasterAdmin ? 'Muhammad Rafiq (Admin)' : 'Plant Staff'),
        email: fbUser.email || 'aabebaraan@gmail.com',
        phone: fbUser.phoneNumber || '+92 300 8472910',
        role: isMasterAdmin ? 'ADMIN' : 'INCHARGE',
        businessId: 'aab_e_baraan_plant_01',
        active: true
      };

      setCurrentUser(userProfile);
      setIsAuthenticated(true);
      saveToStorage('current_user', userProfile);
      saveToStorage('is_authenticated', true);

      if (isMasterAdmin) {
        setDoc(doc(db, 'admins', fbUser.uid), {
          id: fbUser.uid,
          email: fbUser.email,
          role: 'ADMIN',
          registeredAt: Date.now()
        }).catch(() => {});
      }

      return { success: true };
    } catch (err: any) {
      console.error("Google sign in error:", err);
      return { success: false, error: err.message };
    }
  };

  // LOGOUT METHOD
  const logout = () => {
    setIsAuthenticated(false);
    setCurrentUser({
      id: "unauthenticated",
      username: "",
      name: "Please Log In",
      email: "",
      phone: "",
      role: "STAFF" as UserRole,
      businessId: "aab_e_baraan_plant_01",
      active: false
    });
    saveToStorage('is_authenticated', false);
    saveToStorage('current_user', null);
  };

  // SWITCH USER WITH CREDENTIALS
  const switchUserWithCredentials = (username: string, pass: string): { success: boolean; error?: string } => {
    const cleanUser = username.trim().toLowerCase();
    const cleanPass = pass.trim();

    if (cleanUser === 'admin' && (cleanPass === 'admin123' || cleanPass === 'admin')) {
      const adminAcc = userAccounts.find(u => u.username.toLowerCase() === 'admin');
      const profile: UserProfile = {
        id: adminAcc?.id || "user_admin_01",
        username: "admin",
        name: adminAcc?.name ? adminAcc.name.replace(' (Admin / Owner)', ' (Admin)').replace(' / Owner', '') : "Muhammad Rafiq (Admin)",
        email: "aabebaraan@gmail.com",
        phone: adminAcc?.phone || "+92 300 8472910",
        role: "ADMIN" as UserRole,
        businessId: "aab_e_baraan_plant_01",
        active: true
      };
      setCurrentUser(profile);
      setIsAuthenticated(true);
      saveToStorage('current_user', profile);
      saveToStorage('is_authenticated', true);
      return { success: true };
    }

    const account = userAccounts.find(
      u => u.username.toLowerCase() === cleanUser && 
      (u.password?.trim() === cleanPass || 
       (u.username.toLowerCase() === 'admin' && cleanPass === 'admin123'))
    );

    if (account) {
      if (!account.active) {
        return { success: false, error: 'This user account is deactivated by Admin.' };
      }

      const profile: UserProfile = {
        id: account.id,
        username: account.username,
        name: account.name,
        email: `${account.username}@aabebaraan.com`,
        phone: account.phone,
        role: account.role,
        businessId: "aab_e_baraan_plant_01",
        active: true
      };
      setCurrentUser(profile);
      setIsAuthenticated(true);
      saveToStorage('current_user', profile);
      saveToStorage('is_authenticated', true);
      return { success: true };
    }

    return { 
      success: false, 
      error: 'Invalid username or password. Password is required to switch users.' 
    };
  };

  // REQUEST PASSWORD RESET
  const requestPasswordReset = (user: string, reason: string) => {
    const reqId = `reset_${Date.now()}`;
    const newNotif: AppNotification = {
      id: reqId,
      title: `Password Reset Request: ${user}`,
      message: `Staff member "${user}" requested a password reset. Reason: "${reason}". Please contact them or update password in Staff Management.`,
      timeAgo: 'Just now',
      severity: 'WARNING',
      isRead: false,
      targetRole: 'ADMIN',
      timestamp: Date.now()
    };
    setNotifications(prev => [newNotif, ...prev]);
    setDoc(doc(db, 'notifications', reqId), newNotif).catch(() => {});
    setDoc(doc(db, 'passwordResetRequests', reqId), {
      id: reqId,
      username: user,
      reason,
      requestedAt: Date.now(),
      resolved: false
    }).catch(() => {});
  };

  const toggleDarkMode = () => setIsDarkMode(prev => !prev);
  const toggleViewMode = () => setViewMode(prev => prev === 'mobile' ? 'desktop' : 'mobile');

  const updateBusinessProfile = (profile: Partial<BusinessProfile>) => {
    setBusinessProfile(prev => {
      const updated = { ...prev, ...profile };
      setDoc(doc(db, 'businessProfile', 'aab_e_baraan_plant_01'), updated).catch(() => {});
      return updated;
    });
  };

  const addUserAccount = (user: Omit<UserAccount, 'id' | 'createdAt'>) => {
    const newUser: UserAccount = {
      ...user,
      id: `user_${Date.now()}`,
      createdAt: Date.now()
    };
    setUserAccounts(prev => [newUser, ...prev]);
    setDoc(doc(db, 'userAccounts', newUser.id), newUser).catch(() => {});
  };

  const updateUserAccount = (updated: UserAccount) => {
    if (currentUser.role !== 'ADMIN') return;
    setUserAccounts(prev => prev.map(u => u.id === updated.id ? updated : u));
    setDoc(doc(db, 'userAccounts', updated.id), updated).catch(() => {});
  };

  const deleteUserAccount = (id: string) => {
    if (currentUser.role !== 'ADMIN') return;
    setUserAccounts(prev => prev.filter(u => u.id !== id));
    deleteDoc(doc(db, 'userAccounts', id)).catch(() => {});
  };

  const addCustomer = (customerData: Omit<Customer, 'id' | 'customerCode' | 'currentBalance' | 'emptyBottlesOwed' | 'totalPurchases' | 'businessId'>) => {
    const nextNum = customers.length + 1;
    const code = `CUST-${String(nextNum).padStart(3, '0')}`;
    const id = `cust_${Date.now()}`;
    const cleanedPhone = (customerData.phone || '').replace(/[^0-9+]/g, '');
    const cleanedWhatsapp = (customerData.whatsapp || customerData.phone || '').replace(/[^0-9+]/g, '');
    const today = new Date().toISOString().split('T')[0];

    const newCust: Customer = {
      ...customerData,
      phone: cleanedPhone,
      whatsapp: cleanedWhatsapp,
      id,
      customerCode: code,
      currentBalance: customerData.openingBalance || 0,
      emptyBottlesOwed: 0,
      totalPurchases: 0,
      businessId: "aab_e_baraan_plant_01"
    };

    setCustomers(prev => [newCust, ...prev]);

    // Requirement 2.6: For every new customer, all bottle sizes initially have a rate of 0
    const initialRates: CustomerRate[] = bottleSizes.map(bs => ({
      id: `rate_${id}_${bs.id}`,
      customerId: id,
      bottleSizeId: bs.id,
      bottleSizeName: bs.name,
      customPrice: 0,
      isAssigned: false,
      appliedDate: today,
      rateHistory: [],
      businessId: "aab_e_baraan_plant_01"
    }));
    setCustomerRates(prev => [...prev, ...initialRates]);

    return id;
  };

  const updateCustomer = (updated: Customer) => {
    const cleanedPhone = (updated.phone || '').replace(/[^0-9+]/g, '');
    const cleanedWhatsapp = (updated.whatsapp || updated.phone || '').replace(/[^0-9+]/g, '');
    const toSave: Customer = {
      ...updated,
      phone: cleanedPhone,
      whatsapp: cleanedWhatsapp,
      lastEditedAt: Date.now(),
      lastEditedBy: currentUser.name
    };
    setCustomers(prev => prev.map(c => c.id === updated.id ? toSave : c));
  };

  const setCustomerPrice = (customerId: string, bottleSizeId: string, customPrice: number, effectiveDate?: string) => {
    const size = bottleSizes.find(b => b.id === bottleSizeId);
    const sizeName = size ? size.name : bottleSizeId;
    const today = new Date().toISOString().split('T')[0];
    const effDate = effectiveDate || today;

    setCustomerRates(prev => {
      const existing = prev.find(r => r.customerId === customerId && r.bottleSizeId === bottleSizeId);
      const prevRate = existing ? existing.customPrice : 0;
      const historyEntry: RateHistoryEntry = {
        id: `rh_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        customerId,
        bottleSizeId,
        bottleSizeName: sizeName,
        previousRate: prevRate,
        newRate: customPrice,
        rate: customPrice,
        appliedFromDate: today,
        effectiveDate: effDate,
        updatedBy: currentUser.name,
        timestamp: Date.now()
      };

      if (existing) {
        return prev.map(r => r.id === existing.id ? {
          ...r,
          customPrice,
          isAssigned: customPrice > 0,
          appliedDate: effDate,
          rateHistory: [historyEntry, ...(r.rateHistory || [])]
        } : r);
      } else {
        const newRate: CustomerRate = {
          id: `rate_${customerId}_${bottleSizeId}`,
          customerId,
          bottleSizeId,
          bottleSizeName: sizeName,
          customPrice,
          isAssigned: customPrice > 0,
          appliedDate: effDate,
          rateHistory: [historyEntry],
          businessId: "aab_e_baraan_plant_01"
        };
        return [...prev, newRate];
      }
    });
  };

  // ADMIN UPDATE DELIVERY
  const updateDelivery = (deliveryId: string, updated: {
    items: DeliveryItem[];
    deliveryCharges: number;
    paymentCollected: number;
    paymentMethod: string;
    notes?: string;
    date?: string;
  }): { success: boolean; error?: string } => {
    if (currentUser.role !== 'ADMIN') {
      return { success: false, error: 'Only Admin can edit deliveries.' };
    }

    const oldDelivery = deliveries.find(d => d.id === deliveryId);
    if (!oldDelivery) return { success: false, error: 'Delivery not found.' };

    const customer = customers.find(c => c.id === oldDelivery.customerId);
    if (!customer) return { success: false, error: 'Customer not found.' };

    const newSubtotal = updated.items.reduce((acc, item) => acc + item.lineTotal, 0);
    const newTotalAmount = newSubtotal + updated.deliveryCharges;
    const newTotalFull = updated.items.reduce((acc, item) => acc + item.quantity, 0);
    const newTotalEmpty = updated.items.reduce((acc, item) => acc + (item.emptyCollected || 0), 0);

    // Delta calculations
    const netBalanceChange = (newTotalAmount - updated.paymentCollected) - (oldDelivery.totalAmount - oldDelivery.paymentCollected);
    const netBottlesDelta = (newTotalFull - newTotalEmpty) - (oldDelivery.totalFullDelivered - oldDelivery.totalEmptyCollected);
    const totalPurchasesDelta = newTotalAmount - oldDelivery.totalAmount;

    // 1. Update customer balance and bottle owed
    setCustomers(prev => prev.map(c => {
      if (c.id === customer.id) {
        return {
          ...c,
          currentBalance: c.currentBalance + netBalanceChange,
          emptyBottlesOwed: Math.max(0, c.emptyBottlesOwed + netBottlesDelta),
          totalPurchases: Math.max(0, c.totalPurchases + totalPurchasesDelta)
        };
      }
      return c;
    }));

    // 2. Adjust bottle inventory
    setBottleInventory(prev => prev.map(inv => {
      const oldItem = oldDelivery.items.find(i => i.bottleSizeId === inv.bottleSizeId);
      const newItem = updated.items.find(i => i.bottleSizeId === inv.bottleSizeId);
      const oldDelivered = oldItem ? oldItem.quantity : 0;
      const newDelivered = newItem ? newItem.quantity : 0;
      const oldEmpties = oldItem ? (oldItem.emptyCollected || 0) : 0;
      const newEmpties = newItem ? (newItem.emptyCollected || 0) : 0;

      const deltaDelivered = newDelivered - oldDelivered;
      const deltaEmpties = newEmpties - oldEmpties;

      if (deltaDelivered !== 0 || deltaEmpties !== 0) {
        const bottleDef = bottleSizes.find(b => b.id === inv.bottleSizeId);
        const returnable = bottleDef?.isReturnableBottle ?? true;
        return {
          ...inv,
          atPlantFull: Math.max(0, inv.atPlantFull - deltaDelivered),
          atPlantEmpty: returnable ? Math.max(0, inv.atPlantEmpty + deltaEmpties) : inv.atPlantEmpty,
          withCustomers: returnable ? Math.max(0, inv.withCustomers + (deltaDelivered - deltaEmpties)) : inv.withCustomers,
          totalIssuedOrSold: Math.max(0, inv.totalIssuedOrSold + deltaDelivered)
        };
      }
      return inv;
    }));

    // 3. Update Invoice
    const isFullyPaid = updated.paymentCollected >= newTotalAmount;
    const isPartiallyPaid = updated.paymentCollected > 0 && updated.paymentCollected < newTotalAmount;
    const newStatus: InvoiceStatus = isFullyPaid ? 'PAID' : isPartiallyPaid ? 'PARTIALLY_PAID' : 'UNPAID';

    setInvoices(prev => prev.map(inv => {
      if (inv.id === oldDelivery.invoiceId || inv.deliveryId === deliveryId) {
        return {
          ...inv,
          totalAmount: newTotalAmount,
          paidAmount: updated.paymentCollected,
          balanceDue: Math.max(0, newTotalAmount - updated.paymentCollected),
          status: newStatus,
          itemsSummary: updated.items.map(i => `${i.quantity}x ${i.bottleName}`).join(', '),
          date: updated.date || inv.date
        };
      }
      return inv;
    }));

    // 4. Update or link Payment
    setPayments(prev => {
      const existingPayIndex = prev.findIndex(p => p.deliveryId === deliveryId || (p.transactionRef && p.transactionRef.includes(oldDelivery.deliveryNumber)));
      if (existingPayIndex >= 0) {
        if (updated.paymentCollected <= 0) {
          return prev.filter((_, idx) => idx !== existingPayIndex);
        } else {
          return prev.map((p, idx) => idx === existingPayIndex ? {
            ...p,
            amount: updated.paymentCollected,
            paymentMethod: (updated.paymentMethod.toUpperCase() === 'CASH' ? 'CASH' : updated.paymentMethod.toUpperCase() === 'JAZZCASH' ? 'JAZZCASH' : updated.paymentMethod.toUpperCase() === 'EASYPAISA' ? 'EASYPAISA' : 'BANK_TRANSFER') as Payment['paymentMethod'],
            allocations: [{
              invoiceId: oldDelivery.invoiceId,
              invoiceNumber: oldDelivery.deliveryNumber.replace('DEL', 'INV'),
              allocatedAmount: Math.min(updated.paymentCollected, newTotalAmount)
            }],
            date: updated.date || p.date,
            lastEditedAt: Date.now(),
            lastEditedBy: currentUser.name
          } : p);
        }
      } else if (updated.paymentCollected > 0) {
        const newPay: Payment = {
          id: `pay_${Date.now()}`,
          receiptNumber: `RCT-${Date.now().toString().slice(-6)}`,
          customerId: customer.id,
          customerName: customer.name,
          deliveryId,
          amount: updated.paymentCollected,
          paymentMethod: (updated.paymentMethod.toUpperCase() === 'CASH' ? 'CASH' : updated.paymentMethod.toUpperCase() === 'JAZZCASH' ? 'JAZZCASH' : updated.paymentMethod.toUpperCase() === 'EASYPAISA' ? 'EASYPAISA' : 'BANK_TRANSFER') as Payment['paymentMethod'],
          allocations: [{
            invoiceId: oldDelivery.invoiceId,
            invoiceNumber: oldDelivery.deliveryNumber.replace('DEL', 'INV'),
            allocatedAmount: Math.min(updated.paymentCollected, newTotalAmount)
          }],
          advanceCredited: Math.max(0, updated.paymentCollected - newTotalAmount),
          transactionRef: `Delivery ${oldDelivery.deliveryNumber}`,
          notes: `Updated on edit by ${currentUser.name}`,
          date: updated.date || oldDelivery.date,
          receivedBy: currentUser.name,
          receivedByRole: currentUser.role,
          isAcknowledged: true,
          acknowledgedBy: currentUser.name,
          businessId: "aab_e_baraan_plant_01",
          createdAt: Date.now(),
          lastEditedAt: Date.now(),
          lastEditedBy: currentUser.name
        };
        return [newPay, ...prev];
      }
      return prev;
    });

    // 5. Update Delivery record
    setDeliveries(prev => prev.map(d => {
      if (d.id === deliveryId) {
        return {
          ...d,
          items: updated.items,
          totalFullDelivered: newTotalFull,
          totalEmptyCollected: newTotalEmpty,
          subtotal: newSubtotal,
          deliveryCharges: updated.deliveryCharges,
          totalAmount: newTotalAmount,
          paymentCollected: updated.paymentCollected,
          paymentMethod: updated.paymentMethod,
          notes: updated.notes !== undefined ? updated.notes : d.notes,
          date: updated.date || d.date,
          lastEditedAt: Date.now(),
          lastEditedBy: currentUser.name
        };
      }
      return d;
    }));

    // 6. Update ledger entry
    setLedgerEntries(prev => prev.map(l => {
      if (l.referenceNumber === oldDelivery.deliveryNumber) {
        return {
          ...l,
          debitAmount: newTotalAmount,
          runningBalance: l.runningBalance + (newTotalAmount - oldDelivery.totalAmount),
          description: `Delivery ${oldDelivery.deliveryNumber} - ${updated.items.map(i => `${i.quantity}x ${i.bottleName}`).join(', ')} [Edited by Admin]`
        };
      }
      return l;
    }));

    return { success: true };
  };

  // DEDICATED PAYMENT FOR UNPAID/CREDIT DELIVERIES (Requirement 11)
  const payForDelivery = ({
    deliveryId,
    amount,
    paymentMethod,
    transactionRef = '',
    notes = '',
    date = ''
  }: {
    deliveryId: string;
    amount: number;
    paymentMethod: Payment['paymentMethod'];
    transactionRef?: string;
    notes?: string;
    date?: string;
  }): { success: boolean; receiptNumber?: string; error?: string } => {
    const delivery = deliveries.find(d => d.id === deliveryId);
    if (!delivery) return { success: false, error: 'Delivery record not found.' };

    const customer = customers.find(c => c.id === delivery.customerId);
    if (!customer) return { success: false, error: 'Customer not found.' };

    const remainingDue = delivery.totalAmount - delivery.paymentCollected;
    if (remainingDue <= 0) {
      return { success: false, error: 'This delivery is already fully paid.' };
    }

    if (amount <= 0) {
      return { success: false, error: 'Payment amount must be greater than 0.' };
    }

    const payAmount = Math.min(amount, remainingDue);
    const today = new Date().toISOString().split('T')[0];
    const payDate = date || today;
    const receiptNum = `RCT-${Date.now().toString().slice(-6)}`;

    // 1. Update delivery
    const newCollected = delivery.paymentCollected + payAmount;
    setDeliveries(prev => prev.map(d => d.id === deliveryId ? {
      ...d,
      paymentCollected: newCollected,
      lastEditedAt: Date.now(),
      lastEditedBy: currentUser.name
    } : d));

    // 2. Update invoice
    setInvoices(prev => prev.map(inv => {
      if (inv.id === delivery.invoiceId || inv.deliveryId === deliveryId) {
        const newPaid = inv.paidAmount + payAmount;
        const newBalance = Math.max(0, inv.totalAmount - newPaid);
        return {
          ...inv,
          paidAmount: newPaid,
          balanceDue: newBalance,
          status: newBalance <= 0 ? 'PAID' : 'PARTIALLY_PAID'
        };
      }
      return inv;
    }));

    // 3. Create Payment record with date
    const newPayment: Payment = {
      id: `pay_${Date.now()}`,
      receiptNumber: receiptNum,
      customerId: delivery.customerId,
      customerName: customer.name,
      deliveryId,
      amount: payAmount,
      paymentMethod,
      allocations: [{
        invoiceId: delivery.invoiceId,
        invoiceNumber: delivery.deliveryNumber.replace('DEL', 'INV'),
        allocatedAmount: payAmount
      }],
      advanceCredited: 0,
      transactionRef: transactionRef || `Payment against ${delivery.deliveryNumber}`,
      notes: notes || `Direct delivery payment (${newCollected >= delivery.totalAmount ? 'Full' : 'Partial'})`,
      date: payDate,
      receivedBy: currentUser.name,
      receivedByRole: currentUser.role,
      isAcknowledged: true,
      acknowledgedBy: currentUser.name,
      businessId: "aab_e_baraan_plant_01",
      createdAt: Date.now()
    };
    setPayments(prev => [newPayment, ...prev]);

    // 4. Update customer balance
    setCustomers(prev => prev.map(c => c.id === customer.id ? {
      ...c,
      currentBalance: c.currentBalance - payAmount
    } : c));

    // 5. Add Ledger Entry with date
    setLedgerEntries(prev => [
      {
        id: `ledg_${Date.now()}`,
        customerId: customer.id,
        date: payDate,
        type: 'PAYMENT',
        referenceNumber: receiptNum,
        description: `Payment against Delivery ${delivery.deliveryNumber} via ${paymentMethod} on ${payDate} (Rs. ${payAmount})`,
        debitAmount: 0,
        creditAmount: payAmount,
        runningBalance: customer.currentBalance - payAmount,
        timestamp: Date.now()
      },
      ...prev
    ]);

    return { success: true, receiptNumber: receiptNum };
  };

  // ADMIN UPDATE EXPENSE (Requirement 10)
  const updateExpense = (expenseId: string, updated: Partial<Expense>): { success: boolean; error?: string } => {
    if (currentUser.role !== 'ADMIN') {
      return { success: false, error: 'Only Admin can edit expenses.' };
    }
    const exp = expenses.find(e => e.id === expenseId);
    if (!exp) return { success: false, error: 'Expense not found.' };

    setExpenses(prev => prev.map(e => e.id === expenseId ? {
      ...e,
      ...updated,
      lastEditedAt: Date.now(),
      lastEditedBy: currentUser.name
    } : e));

    return { success: true };
  };

  // ADMIN UPDATE PAYMENT (Requirement 10)
  const updatePayment = (paymentId: string, updated: {
    amount: number;
    paymentMethod: Payment['paymentMethod'];
    transactionRef?: string;
    notes?: string;
    date?: string;
  }): { success: boolean; error?: string } => {
    if (currentUser.role !== 'ADMIN') {
      return { success: false, error: 'Only Admin can edit payments.' };
    }
    const pay = payments.find(p => p.id === paymentId);
    if (!pay) return { success: false, error: 'Payment not found.' };

    const deltaAmount = updated.amount - pay.amount;

    // Adjust customer balance
    setCustomers(prev => prev.map(c => {
      if (c.id === pay.customerId) {
        return {
          ...c,
          currentBalance: c.currentBalance - deltaAmount
        };
      }
      return c;
    }));

    // Adjust ledger entry
    setLedgerEntries(prev => prev.map(l => {
      if (l.referenceNumber === pay.receiptNumber) {
        return {
          ...l,
          creditAmount: updated.amount,
          runningBalance: l.runningBalance - deltaAmount,
          description: `Payment received via ${updated.paymentMethod} ${updated.transactionRef ? `(Ref: ${updated.transactionRef})` : ''} [Edited by Admin]`
        };
      }
      return l;
    }));

    // Update payment record
    setPayments(prev => prev.map(p => p.id === paymentId ? {
      ...p,
      amount: updated.amount,
      paymentMethod: updated.paymentMethod,
      transactionRef: updated.transactionRef ?? p.transactionRef,
      notes: updated.notes ?? p.notes,
      date: updated.date ?? p.date,
      lastEditedAt: Date.now(),
      lastEditedBy: currentUser.name
    } : p));

    return { success: true };
  };

  // CREATE DELIVERY
  const createDelivery = ({
    customerId,
    items,
    assignedStaffName,
    deliveryCharges,
    paymentCollected,
    paymentMethod,
    notes = ''
  }: {
    customerId: string;
    items: DeliveryItem[];
    assignedStaffName: string;
    deliveryCharges: number;
    paymentCollected: number;
    paymentMethod: string;
    notes?: string;
  }) => {
    const customer = customers.find(c => c.id === customerId);
    if (!customer) return { success: false, error: 'Customer not found' };

    const today = new Date().toISOString().split('T')[0];
    const nowTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const deliveryId = `del_${Date.now()}`;
    const invoiceId = `inv_${Date.now()}`;
    const deliveryNum = `DEL-${today.replace(/-/g, '').slice(2)}-${String(deliveries.length + 1).padStart(3, '0')}`;
    const invoiceNum = `INV-${today.replace(/-/g, '').slice(2)}-${String(invoices.length + 1).padStart(3, '0')}`;

    const subtotal = items.reduce((acc, item) => acc + item.lineTotal, 0);
    const totalAmount = subtotal + deliveryCharges;
    const totalFullDelivered = items.reduce((acc, item) => acc + item.quantity, 0);
    const totalEmptyCollected = items.reduce((acc, item) => acc + (item.emptyCollected || 0), 0);

    const isFullyPaid = paymentCollected >= totalAmount;
    const isPartiallyPaid = paymentCollected > 0 && paymentCollected < totalAmount;
    const invoiceStatus = isFullyPaid ? 'PAID' : isPartiallyPaid ? 'PARTIALLY_PAID' : 'UNPAID';

    // 1. Create delivery object
    const newDelivery: Delivery = {
      id: deliveryId,
      deliveryNumber: deliveryNum,
      customerId,
      customerName: customer.name,
      customerPhone: customer.phone,
      customerAddress: customer.address,
      customerArea: customer.area,
      date: today,
      time: nowTime,
      items,
      totalFullDelivered,
      totalEmptyCollected,
      assignedStaffId: `staff_${Date.now()}`,
      staffName: assignedStaffName || 'Rider',
      status: 'DELIVERED',
      deliveryCharges,
      subtotal,
      totalAmount,
      paymentCollected,
      paymentMethod,
      notes,
      invoiceId,
      businessId: "aab_e_baraan_plant_01",
      createdBy: currentUser.name,
      createdAt: Date.now()
    };

    // 2. Create Invoice
    const newInvoice: Invoice = {
      id: invoiceId,
      invoiceNumber: invoiceNum,
      customerId,
      customerName: customer.name,
      deliveryId,
      date: today,
      dueDate: customer.paymentDueDate || today,
      totalAmount,
      paidAmount: paymentCollected,
      balanceDue: totalAmount - paymentCollected,
      status: invoiceStatus,
      itemsSummary: items.map(i => `${i.quantity}x ${i.bottleName}`).join(', '),
      businessId: "aab_e_baraan_plant_01",
      createdAt: Date.now()
    };

    // 3. If payment collected, create Payment
    let newPayment: Payment | null = null;
    if (paymentCollected > 0) {
      newPayment = {
        id: `pay_${Date.now()}`,
        receiptNumber: `RCT-${Date.now().toString().slice(-6)}`,
        customerId,
        customerName: customer.name,
        amount: paymentCollected,
        paymentMethod: (paymentMethod.toUpperCase() === 'CASH' ? 'CASH' : paymentMethod.toUpperCase() === 'JAZZCASH' ? 'JAZZCASH' : paymentMethod.toUpperCase() === 'EASYPAISA' ? 'EASYPAISA' : 'BANK_TRANSFER') as Payment['paymentMethod'],
        allocations: [{
          invoiceId,
          invoiceNumber: invoiceNum,
          allocatedAmount: Math.min(paymentCollected, totalAmount)
        }],
        advanceCredited: Math.max(0, paymentCollected - totalAmount),
        transactionRef: `Delivery ${deliveryNum}`,
        notes: `Collected on delivery by ${assignedStaffName}`,
        date: today,
        receivedBy: assignedStaffName || currentUser.name,
        receivedByRole: currentUser.role,
        isAcknowledged: true,
        acknowledgedBy: currentUser.name,
        businessId: "aab_e_baraan_plant_01",
        createdAt: Date.now()
      };
    }

    // 4. Update customer balance & bottle balance
    // CRITICAL: Only multiple-time use bottles (isReturnableBottle === true || usageType === 'MULTIPLE_TIME')
    // can be owed or held by customer. One-time/disposable bottles NEVER add to empty bottles owed.
    const netBalanceChange = totalAmount - paymentCollected;

    let returnableDelivered = 0;
    let returnableEmpties = 0;
    items.forEach(item => {
      const bDef = bottleSizes.find(b => b.id === item.bottleSizeId);
      const isReturnable = bDef ? (bDef.usageType === 'MULTIPLE_TIME' || bDef.isReturnableBottle) : false;
      if (isReturnable) {
        returnableDelivered += item.quantity;
        returnableEmpties += (item.emptyCollected || 0);
      }
    });
    const netBottlesDelta = returnableDelivered - returnableEmpties;

    setCustomers(prev => prev.map(c => {
      if (c.id === customerId) {
        return {
          ...c,
          currentBalance: c.currentBalance + netBalanceChange,
          emptyBottlesOwed: Math.max(0, c.emptyBottlesOwed + netBottlesDelta),
          totalPurchases: c.totalPurchases + totalAmount
        };
      }
      return c;
    }));

    // Update size-wise customer held allocations (size-wise tracking of held bottles)
    setCustomerAllocations(prev => {
      let updated = [...prev];
      items.forEach(item => {
        const bDef = bottleSizes.find(b => b.id === item.bottleSizeId);
        const isReturnable = bDef ? (bDef.usageType === 'MULTIPLE_TIME' || bDef.isReturnableBottle) : false;
        if (!isReturnable) return; // One-time bottles are never held

        const delta = item.quantity - (item.emptyCollected || 0);
        const idx = updated.findIndex(a => a.customerId === customerId && a.bottleSizeId === item.bottleSizeId);
        if (idx >= 0) {
          updated[idx] = {
            ...updated[idx],
            totalIssued: updated[idx].totalIssued + item.quantity,
            returnedCount: updated[idx].returnedCount + (item.emptyCollected || 0),
            emptyHeld: Math.max(0, updated[idx].emptyHeld + delta),
            lastUpdated: today
          };
        } else {
          updated.push({
            id: `alloc_${customerId}_${item.bottleSizeId}`,
            customerId,
            customerName: customer.name,
            bottleSizeId: item.bottleSizeId,
            sizeName: item.bottleName,
            totalIssued: item.quantity,
            returnedCount: item.emptyCollected || 0,
            emptyHeld: Math.max(0, delta),
            depositAmount: 0,
            damagedCount: 0,
            lastUpdated: today,
            businessId: "aab_e_baraan_plant_01"
          });
        }
      });
      return updated;
    });

    // 5. Update inventory (reduce plant full, increase plant empty if returnable)
    setBottleInventory(prev => prev.map(inv => {
      const deliveredItem = items.find(i => i.bottleSizeId === inv.bottleSizeId);
      if (deliveredItem) {
        const bottleDef = bottleSizes.find(b => b.id === inv.bottleSizeId);
        const returnable = bottleDef?.isReturnableBottle ?? true;
        return {
          ...inv,
          atPlantFull: Math.max(0, inv.atPlantFull - deliveredItem.quantity),
          atPlantEmpty: returnable ? inv.atPlantEmpty + (deliveredItem.emptyCollected || 0) : inv.atPlantEmpty,
          withCustomers: returnable ? inv.withCustomers + (deliveredItem.quantity - (deliveredItem.emptyCollected || 0)) : inv.withCustomers,
          totalIssuedOrSold: inv.totalIssuedOrSold + deliveredItem.quantity
        };
      }
      return inv;
    }));

    // 6. Add ledger entries
    const newLedgers: LedgerEntry[] = [];
    const currentCustBalance = customer.currentBalance;
    newLedgers.push({
      id: `ledg_${Date.now()}_inv`,
      customerId,
      date: today,
      type: 'INVOICE',
      referenceNumber: invoiceNum,
      description: `Delivery ${deliveryNum}: ${items.map(i => `${i.quantity}x ${i.bottleName}`).join(', ')}`,
      debitAmount: totalAmount,
      creditAmount: 0,
      runningBalance: currentCustBalance + totalAmount,
      timestamp: Date.now()
    });

    if (paymentCollected > 0) {
      newLedgers.push({
        id: `ledg_${Date.now()}_pay`,
        customerId,
        date: today,
        type: 'PAYMENT',
        referenceNumber: newPayment?.receiptNumber || 'RCT',
        description: `Payment received (${paymentMethod})`,
        debitAmount: 0,
        creditAmount: paymentCollected,
        runningBalance: currentCustBalance + totalAmount - paymentCollected,
        timestamp: Date.now() + 1
      });
    }

    setDeliveries(prev => [newDelivery, ...prev]);
    setInvoices(prev => [newInvoice, ...prev]);
    if (newPayment) setPayments(prev => [newPayment!, ...prev]);
    setLedgerEntries(prev => [...newLedgers, ...prev]);

    return { success: true, deliveryId };
  };

  const updateDeliveryStatus = (deliveryId: string, status: Delivery['status']) => {
    setDeliveries(prev => prev.map(d => d.id === deliveryId ? { ...d, status } : d));
  };

  // ADMIN-ONLY DELETE DELIVERY
  const deleteDelivery = (deliveryId: string): { success: boolean; error?: string } => {
    if (currentUser.role !== 'ADMIN') {
      return { success: false, error: 'Only Plant Administrator can delete deliveries.' };
    }

    const del = deliveries.find(d => d.id === deliveryId);
    if (!del) return { success: false, error: 'Delivery record not found.' };

    // 1. Revert customer balance and empty bottles
    const netBalanceChange = del.totalAmount - del.paymentCollected;
    const netBottlesDelta = del.totalFullDelivered - del.totalEmptyCollected;

    setCustomers(prev => prev.map(c => {
      if (c.id === del.customerId) {
        return {
          ...c,
          currentBalance: c.currentBalance - netBalanceChange,
          emptyBottlesOwed: Math.max(0, c.emptyBottlesOwed - netBottlesDelta),
          totalPurchases: Math.max(0, c.totalPurchases - del.totalAmount)
        };
      }
      return c;
    }));

    // 2. Revert bottle stock inventory
    setBottleInventory(prev => prev.map(inv => {
      const deliveredItem = del.items.find(i => i.bottleSizeId === inv.bottleSizeId);
      if (deliveredItem) {
        const bottleDef = bottleSizes.find(b => b.id === inv.bottleSizeId);
        const returnable = bottleDef?.isReturnableBottle ?? true;
        return {
          ...inv,
          atPlantFull: inv.atPlantFull + deliveredItem.quantity,
          atPlantEmpty: returnable ? Math.max(0, inv.atPlantEmpty - (deliveredItem.emptyCollected || 0)) : inv.atPlantEmpty,
          withCustomers: returnable ? Math.max(0, inv.withCustomers - (deliveredItem.quantity - (deliveredItem.emptyCollected || 0))) : inv.withCustomers,
          totalIssuedOrSold: Math.max(0, inv.totalIssuedOrSold - deliveredItem.quantity)
        };
      }
      return inv;
    }));

    // 3. Remove associated invoices, payments, and ledger entries
    setInvoices(prev => prev.filter(inv => inv.deliveryId !== deliveryId && inv.id !== del.invoiceId));
    setPayments(prev => prev.filter(p => !p.allocations.some(a => a.invoiceId === del.invoiceId)));
    setLedgerEntries(prev => prev.filter(l => !l.description.includes(del.deliveryNumber)));

    // 4. Remove delivery
    setDeliveries(prev => prev.filter(d => d.id !== deliveryId));

    return { success: true };
  };

  // RECEIVE PAYMENT
  const receivePayment = ({
    customerId,
    amount,
    paymentMethod,
    transactionRef = '',
    notes = ''
  }: {
    customerId: string;
    amount: number;
    paymentMethod: Payment['paymentMethod'];
    transactionRef?: string;
    notes?: string;
  }) => {
    const customer = customers.find(c => c.id === customerId);
    if (!customer) return { success: false };

    const today = new Date().toISOString().split('T')[0];
    const receiptNum = `RCT-${Date.now().toString().slice(-6)}`;

    // Allocate across customer's unpaid/partially paid invoices
    let remainingAmount = amount;
    const allocations: Payment['allocations'] = [];
    const updatedInvoices = invoices.map(inv => {
      if (inv.customerId === customerId && inv.status !== 'PAID' && remainingAmount > 0) {
        const canPay = Math.min(inv.balanceDue, remainingAmount);
        remainingAmount -= canPay;
        allocations.push({
          invoiceId: inv.id,
          invoiceNumber: inv.invoiceNumber,
          allocatedAmount: canPay
        });
        const newPaid = inv.paidAmount + canPay;
        const newDue = inv.totalAmount - newPaid;
        return {
          ...inv,
          paidAmount: newPaid,
          balanceDue: newDue,
          status: newDue <= 0 ? ('PAID' as const) : ('PARTIALLY_PAID' as const)
        };
      }
      return inv;
    });

    setInvoices(updatedInvoices);

    const newPayment: Payment = {
      id: `pay_${Date.now()}`,
      receiptNumber: receiptNum,
      customerId,
      customerName: customer.name,
      amount,
      paymentMethod,
      allocations,
      advanceCredited: remainingAmount,
      transactionRef,
      notes,
      date: today,
      receivedBy: currentUser.name,
      receivedByRole: currentUser.role,
      isAcknowledged: true,
      acknowledgedBy: currentUser.name,
      businessId: "aab_e_baraan_plant_01",
      createdAt: Date.now()
    };

    setPayments(prev => [newPayment, ...prev]);

    // Update customer balance
    setCustomers(prev => prev.map(c => {
      if (c.id === customerId) {
        return {
          ...c,
          currentBalance: c.currentBalance - amount
        };
      }
      return c;
    }));

    // Update Ledger
    setLedgerEntries(prev => [
      {
        id: `ledg_${Date.now()}`,
        customerId,
        date: today,
        type: 'PAYMENT',
        referenceNumber: receiptNum,
        description: `Payment received via ${paymentMethod} ${transactionRef ? `(Ref: ${transactionRef})` : ''}`,
        debitAmount: 0,
        creditAmount: amount,
        runningBalance: customer.currentBalance - amount,
        timestamp: Date.now()
      },
      ...prev
    ]);

    return { success: true, receiptNumber: receiptNum };
  };

  // ADMIN-ONLY DELETE PAYMENT
  const deletePayment = (paymentId: string): { success: boolean; error?: string } => {
    if (currentUser.role !== 'ADMIN') {
      return { success: false, error: 'Only Plant Administrator can delete payment receipts.' };
    }

    const pay = payments.find(p => p.id === paymentId);
    if (!pay) return { success: false, error: 'Payment not found.' };

    // 1. Revert customer debt
    setCustomers(prev => prev.map(c => {
      if (c.id === pay.customerId) {
        return {
          ...c,
          currentBalance: c.currentBalance + pay.amount
        };
      }
      return c;
    }));

    // 2. Revert invoice paid amounts
    if (pay.allocations && pay.allocations.length > 0) {
      setInvoices(prev => prev.map(inv => {
        const alloc = pay.allocations.find(a => a.invoiceId === inv.id);
        if (alloc) {
          const newPaid = Math.max(0, inv.paidAmount - alloc.allocatedAmount);
          const newDue = inv.totalAmount - newPaid;
          return {
            ...inv,
            paidAmount: newPaid,
            balanceDue: newDue,
            status: newPaid <= 0 ? 'UNPAID' : 'PARTIALLY_PAID'
          };
        }
        return inv;
      }));
    }

    // 3. Remove ledger entry
    setLedgerEntries(prev => prev.filter(l => l.referenceNumber !== pay.receiptNumber));

    // 4. Remove payment
    setPayments(prev => prev.filter(p => p.id !== paymentId));

    return { success: true };
  };

  // COLLECT EMPTY BOTTLES
  const collectEmptyBottles = (customerId: string, count: number, notes = '') => {
    const customer = customers.find(c => c.id === customerId);
    if (!customer) return;

    setCustomers(prev => prev.map(c => {
      if (c.id === customerId) {
        return {
          ...c,
          emptyBottlesOwed: Math.max(0, c.emptyBottlesOwed - count)
        };
      }
      return c;
    }));

    // Add back to plant empties for 19L
    setBottleInventory(prev => prev.map(inv => {
      if (inv.bottleSizeId === 'size_19l') {
        return {
          ...inv,
          atPlantEmpty: inv.atPlantEmpty + count,
          withCustomers: Math.max(0, inv.withCustomers - count)
        };
      }
      return inv;
    }));
  };

  // PRODUCTION REFILL BATCH
  const recordRefillBatch = (bottleSizeId: string, quantityFilled: number, operatorName: string, notes = '') => {
    const size = bottleSizes.find(b => b.id === bottleSizeId);
    if (!size) return;

    // Update bottle inventory: Empty -> Full
    setBottleInventory(prev => prev.map(inv => {
      if (inv.bottleSizeId === bottleSizeId) {
        return {
          ...inv,
          atPlantEmpty: Math.max(0, inv.atPlantEmpty - quantityFilled),
          atPlantFull: inv.atPlantFull + quantityFilled
        };
      }
      return inv;
    }));

    // Deduct consumable materials if 19L
    if (bottleSizeId === 'size_19l') {
      setFactoryMaterials(prev => prev.map(mat => {
        if (mat.id === 'mat_caps_19l') {
          return { ...mat, currentStock: Math.max(0, mat.currentStock - quantityFilled) };
        }
        if (mat.id === 'mat_seals_19l') {
          return { ...mat, currentStock: Math.max(0, mat.currentStock - quantityFilled) };
        }
        return mat;
      }));
    }
  };

  // PURCHASE BOTTLES
  const purchaseBottles = (
    bottleSizeId: string, 
    quantity: number, 
    unitCost: number, 
    supplierName: string, 
    paymentSource: PaymentSource = 'PAY_FROM_SALE',
    paymentMethod: PaymentMethod = 'CASH'
  ) => {
    const size = bottleSizes.find(b => b.id === bottleSizeId);
    if (!size) return;

    setBottleInventory(prev => prev.map(inv => {
      if (inv.bottleSizeId === bottleSizeId) {
        return {
          ...inv,
          atPlantEmpty: inv.atPlantEmpty + quantity,
          totalPurchased: inv.totalPurchased + quantity
        };
      }
      return inv;
    }));

    // Log CAPEX expense with selected payment source and payment method
    const today = new Date().toISOString().split('T')[0];
    addExpense({
      date: today,
      expenseType: 'CAPEX',
      categoryId: 'cat_bottles_capex',
      categoryName: '19L New Bottles Purchase',
      description: `Purchased ${quantity}x ${size.name} from ${supplierName || 'Vendor'}`,
      amount: quantity * unitCost,
      paymentSource,
      paymentMethod,
      payee: supplierName || 'Vendor',
      notes: `Unit cost: Rs. ${unitCost} • Source: ${paymentSource === 'PAY_FROM_SALE' ? 'Pay from Sale' : 'Investment'} • Method: ${paymentMethod}`,
      enteredBy: currentUser.name,
      enteredByRole: currentUser.role,
      isAcknowledged: true,
      acknowledgedBy: currentUser.name,
      isApprovedByOwner: true
    });
  };

  // DAMAGED BOTTLES (Customer, RO Plant Internal, or Plant Warehouse)
  const recordDamagedBottles = (bottleSizeId: string, quantity: number, customerId?: string, notes = '') => {
    const today = new Date().toISOString().split('T')[0];

    setBottleInventory(prev => prev.map(inv => {
      if (inv.bottleSizeId === bottleSizeId) {
        return {
          ...inv,
          damaged: inv.damaged + quantity,
          atPlantEmpty: customerId ? inv.atPlantEmpty : Math.max(0, inv.atPlantEmpty - quantity),
          withCustomers: customerId ? Math.max(0, inv.withCustomers - quantity) : inv.withCustomers
        };
      }
      return inv;
    }));

    if (customerId) {
      if (customerId === 'RO_PLANT') {
        // RO Plant Internal damage
        setCustomerAllocations(prev => prev.map(a => {
          if (a.customerId === 'RO_PLANT' && a.bottleSizeId === bottleSizeId) {
            return {
              ...a,
              emptyHeld: Math.max(0, a.emptyHeld - quantity),
              damagedCount: a.damagedCount + quantity,
              lastUpdated: today
            };
          }
          return a;
        }));
      } else {
        // Customer custody damage
        setCustomers(prev => prev.map(c => {
          if (c.id === customerId) {
            return {
              ...c,
              emptyBottlesOwed: Math.max(0, c.emptyBottlesOwed - quantity)
            };
          }
          return c;
        }));

        setCustomerAllocations(prev => prev.map(a => {
          if (a.customerId === customerId && a.bottleSizeId === bottleSizeId) {
            return {
              ...a,
              emptyHeld: Math.max(0, a.emptyHeld - quantity),
              damagedCount: a.damagedCount + quantity,
              lastUpdated: today
            };
          }
          return a;
        }));
      }
    }
  };

  // ISSUE BOTTLES (Multiple-time use bottles to Customer or RO Plant Internal)
  const issueBottles = (params: {
    targetType: 'CUSTOMER' | 'RO_PLANT';
    customerId?: string;
    customerName?: string;
    bottleSizeId: string;
    quantity: number;
    notes?: string;
  }): { success: boolean; error?: string } => {
    const { targetType, customerId, bottleSizeId, quantity, notes = '' } = params;
    if (quantity <= 0) return { success: false, error: 'Quantity must be greater than 0' };

    const size = bottleSizes.find(b => b.id === bottleSizeId);
    if (!size) return { success: false, error: 'Bottle size not found' };

    const today = new Date().toISOString().split('T')[0];

    if (targetType === 'CUSTOMER') {
      if (!customerId) return { success: false, error: 'Please select a customer' };
      const cust = customers.find(c => c.id === customerId);
      if (!cust) return { success: false, error: 'Customer not found' };

      // Update customer total owed
      setCustomers(prev => prev.map(c => c.id === customerId ? {
        ...c,
        emptyBottlesOwed: c.emptyBottlesOwed + quantity
      } : c));

      // Update size-wise customer allocations
      setCustomerAllocations(prev => {
        const existingIdx = prev.findIndex(a => a.customerId === customerId && a.bottleSizeId === bottleSizeId);
        if (existingIdx >= 0) {
          return prev.map((a, idx) => idx === existingIdx ? {
            ...a,
            totalIssued: a.totalIssued + quantity,
            emptyHeld: a.emptyHeld + quantity,
            lastUpdated: today
          } : a);
        } else {
          return [...prev, {
            id: `alloc_${customerId}_${bottleSizeId}`,
            customerId,
            customerName: cust.name,
            bottleSizeId,
            sizeName: size.name,
            totalIssued: quantity,
            emptyHeld: quantity,
            returnedCount: 0,
            damagedCount: 0,
            depositAmount: 0,
            lastUpdated: today,
            businessId: "aab_e_baraan_plant_01"
          }];
        }
      });

      // Update bottle inventory
      setBottleInventory(prev => prev.map(inv => {
        if (inv.bottleSizeId === bottleSizeId) {
          return {
            ...inv,
            withCustomers: inv.withCustomers + quantity,
            atPlantEmpty: Math.max(0, inv.atPlantEmpty - quantity),
            totalIssuedOrSold: inv.totalIssuedOrSold + quantity
          };
        }
        return inv;
      }));
    } else {
      // Issue to RO Plant Internal Use
      setCustomerAllocations(prev => {
        const existingIdx = prev.findIndex(a => a.customerId === 'RO_PLANT' && a.bottleSizeId === bottleSizeId);
        if (existingIdx >= 0) {
          return prev.map((a, idx) => idx === existingIdx ? {
            ...a,
            totalIssued: a.totalIssued + quantity,
            emptyHeld: a.emptyHeld + quantity,
            lastUpdated: today
          } : a);
        } else {
          return [...prev, {
            id: `alloc_RO_PLANT_${bottleSizeId}`,
            customerId: 'RO_PLANT',
            customerName: 'RO Plant Internal Use (آر او پلانٹ)',
            bottleSizeId,
            sizeName: size.name,
            totalIssued: quantity,
            emptyHeld: quantity,
            returnedCount: 0,
            damagedCount: 0,
            depositAmount: 0,
            lastUpdated: today,
            businessId: "aab_e_baraan_plant_01"
          }];
        }
      });

      // Update bottle inventory
      setBottleInventory(prev => prev.map(inv => {
        if (inv.bottleSizeId === bottleSizeId) {
          return {
            ...inv,
            withCustomers: inv.withCustomers + quantity,
            atPlantEmpty: Math.max(0, inv.atPlantEmpty - quantity),
            totalIssuedOrSold: inv.totalIssuedOrSold + quantity
          };
        }
        return inv;
      }));
    }

    return { success: true };
  };

  // MATERIAL MANAGEMENT (CRUD + ISSUE + REFILL)
  const addFactoryMaterial = (materialData: Omit<FactoryMaterial, 'id' | 'lastUpdated'>) => {
    const newId = `mat_${Date.now()}`;
    const newMaterial: FactoryMaterial = {
      ...materialData,
      id: newId,
      lastUpdated: Date.now()
    };
    setFactoryMaterials(prev => [newMaterial, ...prev]);
  };

  const updateFactoryMaterial = (id: string, updates: Partial<FactoryMaterial>) => {
    setFactoryMaterials(prev => prev.map(mat => {
      if (mat.id === id) {
        return {
          ...mat,
          ...updates,
          lastUpdated: Date.now()
        };
      }
      return mat;
    }));
  };

  const deleteFactoryMaterial = (id: string) => {
    setFactoryMaterials(prev => prev.filter(mat => mat.id !== id));
  };

  const issueMaterial = (materialId: string, quantity: number, issueTo: MaterialIssueTo | string, notes = '') => {
    setFactoryMaterials(prev => prev.map(mat => {
      if (mat.id === materialId) {
        return {
          ...mat,
          currentStock: Math.max(0, mat.currentStock - quantity),
          issueTo: issueTo as MaterialIssueTo,
          lastUpdated: Date.now()
        };
      }
      return mat;
    }));
  };

  const refillMaterial = (materialId: string, quantity: number, unitCost: number, supplier: string) => {
    setFactoryMaterials(prev => prev.map(mat => {
      if (mat.id === materialId) {
        return {
          ...mat,
          currentStock: mat.currentStock + quantity,
          purchaseRate: unitCost > 0 ? unitCost : mat.purchaseRate,
          supplierName: supplier || mat.supplierName,
          lastUpdated: Date.now()
        };
      }
      return mat;
    }));
  };

  // EXPENSES
  const addExpense = (expenseData: Omit<Expense, 'id' | 'voucherNumber' | 'createdAt' | 'businessId'>) => {
    const voucherNumber = `EXP-${new Date().getFullYear()}-${String(expenses.length + 1).padStart(3, '0')}`;
    const newExp: Expense = {
      ...expenseData,
      id: `exp_${Date.now()}`,
      voucherNumber,
      businessId: "aab_e_baraan_plant_01",
      createdAt: Date.now()
    };
    setExpenses(prev => [newExp, ...prev]);
  };

  const approveExpense = (expenseId: string) => {
    setExpenses(prev => prev.map(e => e.id === expenseId ? { ...e, isApprovedByOwner: true, acknowledgedBy: currentUser.name } : e));
  };

  // ADMIN-ONLY DELETE EXPENSE
  const deleteExpense = (expenseId: string): { success: boolean; error?: string } => {
    if (currentUser.role !== 'ADMIN') {
      return { success: false, error: 'Only Plant Administrator can delete expense vouchers.' };
    }
    setExpenses(prev => prev.filter(e => e.id !== expenseId));
    return { success: true };
  };

  // ADMIN-ONLY DELETE CUSTOMER
  const deleteCustomer = (customerId: string, force = false): { 
    success: boolean; 
    error?: string; 
    hasPendingItems?: boolean; 
    dues?: number; 
    bottles?: number 
  } => {
    if (currentUser.role !== 'ADMIN') {
      return { success: false, error: 'Only Plant Administrator can delete customers.' };
    }

    const cust = customers.find(c => c.id === customerId);
    if (!cust) return { success: false, error: 'Customer not found.' };

    const hasDues = cust.currentBalance > 0;
    const hasBottles = cust.emptyBottlesOwed > 0;

    if (!force && (hasDues || hasBottles)) {
      return {
        success: false,
        hasPendingItems: true,
        dues: cust.currentBalance,
        bottles: cust.emptyBottlesOwed,
        error: `Customer has outstanding balance of Rs. ${cust.currentBalance} and ${cust.emptyBottlesOwed} bottles pending.`
      };
    }

    // Clean up
    setCustomers(prev => prev.filter(c => c.id !== customerId));
    setCustomerRates(prev => prev.filter(r => r.customerId !== customerId));
    setCustomerAllocations(prev => prev.filter(a => a.customerId !== customerId));
    setLedgerEntries(prev => prev.filter(l => l.customerId !== customerId));

    return { success: true };
  };

  // ADMIN BOTTLE SIZE MANAGEMENT (Add, Edit, Delete)
  const addBottleSize = (bottleSizeData: Omit<BottleSize, 'id' | 'businessId'>): { success: boolean; id?: string; error?: string } => {
    if (currentUser.role !== 'ADMIN') {
      return { success: false, error: 'Only Plant Administrator can add bottle sizes.' };
    }
    const newId = `size_${Date.now()}`;
    const newSize: BottleSize = {
      ...bottleSizeData,
      id: newId,
      businessId: "aab_e_baraan_plant_01"
    };

    setBottleSizes(prev => [...prev, newSize]);

    // Create 0-count inventory record
    setBottleInventory(prev => [
      ...prev,
      {
        id: `inv_${newId}`,
        bottleSizeId: newId,
        sizeName: newSize.name,
        atPlantFull: 0,
        atPlantEmpty: 0,
        withCustomers: 0,
        withStaff: 0,
        damaged: 0,
        totalPurchased: 0,
        totalIssuedOrSold: 0,
        businessId: "aab_e_baraan_plant_01"
      }
    ]);

    // Initialize custom rate for every customer with rate 0
    const today = new Date().toISOString().split('T')[0];
    const initialRates: CustomerRate[] = customers.map(c => ({
      id: `rate_${c.id}_${newId}`,
      customerId: c.id,
      bottleSizeId: newId,
      bottleSizeName: newSize.name,
      customPrice: 0,
      isAssigned: false,
      appliedDate: today,
      rateHistory: [],
      businessId: "aab_e_baraan_plant_01"
    }));
    setCustomerRates(prev => [...prev, ...initialRates]);

    return { success: true, id: newId };
  };

  const updateBottleSize = (updatedSize: BottleSize): { success: boolean; error?: string } => {
    if (currentUser.role !== 'ADMIN') {
      return { success: false, error: 'Only Plant Administrator can edit bottle sizes.' };
    }
    setBottleSizes(prev => prev.map(b => b.id === updatedSize.id ? updatedSize : b));
    setBottleInventory(prev => prev.map(inv => inv.bottleSizeId === updatedSize.id ? {
      ...inv,
      sizeName: updatedSize.name
    } : inv));
    return { success: true };
  };

  const deleteBottleSize = (bottleSizeId: string): { success: boolean; error?: string } => {
    if (currentUser.role !== 'ADMIN') {
      return { success: false, error: 'Only Plant Administrator can delete bottle items.' };
    }
    setBottleSizes(prev => prev.filter(b => b.id !== bottleSizeId));
    setBottleInventory(prev => prev.filter(inv => inv.bottleSizeId !== bottleSizeId));
    setCustomerRates(prev => prev.filter(r => r.bottleSizeId !== bottleSizeId));
    setCustomerAllocations(prev => prev.filter(a => a.bottleSizeId !== bottleSizeId));
    return { success: true };
  };

  // CASH CLOSING (Only ONE closing per calendar date; later closings overwrite today's record)
  const recordCashClosing = ({
    openingCash,
    customerCashCollected,
    otherCashIncome,
    cashExpenses,
    actualClosingCash,
    denominationBreakdown,
    notes = ''
  }: {
    openingCash: number;
    customerCashCollected: number;
    otherCashIncome: number;
    cashExpenses: number;
    actualClosingCash: number;
    denominationBreakdown?: Record<number, number>;
    notes?: string;
  }) => {
    const expected = openingCash + customerCashCollected + otherCashIncome - cashExpenses;
    const diff = actualClosingCash - expected;
    const today = new Date().toISOString().split('T')[0];
    const closingId = `closing_${today}`;

    const closing: CashClosing = {
      id: closingId,
      date: today,
      openingCash,
      customerCashCollected,
      otherCashIncome,
      cashExpenses,
      cashRefunds: 0,
      expectedClosingCash: expected,
      actualClosingCash,
      difference: diff,
      denominationBreakdown,
      notes,
      closedBy: currentUser.name,
      isApprovedByOwner: currentUser.role === 'ADMIN',
      businessId: "aab_e_baraan_plant_01",
      closedAt: Date.now()
    };

    // Filter out previous closing for today so only the latest is preserved
    setCashClosings(prev => {
      const filtered = prev.filter(c => c.date !== today && c.id !== closingId);
      return [closing, ...filtered];
    });

    setDoc(doc(db, 'cashClosings', closingId), closing).catch(err => {
      handleFirestoreError(err, OperationType.WRITE, 'cashClosings/' + closingId);
    });
  };

  const updateBottleCosting = (costing: BottleCostingRecord) => {
    setBottleCostings(prev => prev.map(c => c.id === costing.id ? costing : c));
    setDoc(doc(db, 'bottleCostings', costing.id), costing).catch(() => {});
  };

  const markNotificationAsRead = (id: string) => {
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, isRead: true } : n));
    setDoc(doc(db, 'notifications', id), { isRead: true }, { merge: true }).catch(() => {});
  };

  const clearAllNotifications = () => {
    setNotifications([]);
  };

  const resetToDemoData = () => {
    localStorage.clear();
    setBusinessProfile(defaultBusinessProfile);
    setBottleSizes(defaultBottleSizes);
    setBottleInventory(defaultBottleInventory);
    setCustomers([]);
    setCustomerAllocations([]);
    setCustomerRates([]);
    setDeliveries([]);
    setInvoices([]);
    setPayments([]);
    setLedgerEntries([]);
    setExpenses([]);
    setExpenseCategories(defaultExpenseCategories);
    setFactoryMaterials(defaultFactoryMaterials);
    setBottleCostings(defaultBottleCostings);
    setMonthlyRecurringExpenses(defaultMonthlyRecurringExpenses);
    setCashClosings([]);
    setUserAccounts(defaultUserAccounts);
    setNotifications(defaultNotifications);
  };

  const exportBackupJson = () => {
    const fullState = {
      exportDate: new Date().toISOString(),
      businessProfile,
      bottleSizes,
      bottleInventory,
      customers,
      customerAllocations,
      customerRates,
      deliveries,
      invoices,
      payments,
      ledgerEntries,
      expenses,
      expenseCategories,
      factoryMaterials,
      bottleCostings,
      monthlyRecurringExpenses,
      cashClosings,
      userAccounts
    };
    return JSON.stringify(fullState, null, 2);
  };

  const importBackupJson = (jsonStr: string): boolean => {
    try {
      const data = JSON.parse(jsonStr);
      if (data.customers && Array.isArray(data.customers)) {
        setCustomers(data.customers);
        data.customers.forEach((c: Customer) => setDoc(doc(db, 'customers', c.id), c).catch(() => {}));
      }
      if (data.bottleSizes && Array.isArray(data.bottleSizes)) {
        setBottleSizes(data.bottleSizes);
        data.bottleSizes.forEach((b: BottleSize) => setDoc(doc(db, 'bottleSizes', b.id), b).catch(() => {}));
      }
      if (data.bottleInventory && Array.isArray(data.bottleInventory)) {
        setBottleInventory(data.bottleInventory);
        data.bottleInventory.forEach((bi: BottleInventory) => setDoc(doc(db, 'bottleInventory', bi.id), bi).catch(() => {}));
      }
      if (data.deliveries && Array.isArray(data.deliveries)) {
        setDeliveries(data.deliveries);
        data.deliveries.forEach((d: Delivery) => setDoc(doc(db, 'deliveries', d.id), d).catch(() => {}));
      }
      if (data.invoices && Array.isArray(data.invoices)) {
        setInvoices(data.invoices);
        data.invoices.forEach((inv: Invoice) => setDoc(doc(db, 'invoices', inv.id), inv).catch(() => {}));
      }
      if (data.payments && Array.isArray(data.payments)) {
        setPayments(data.payments);
        data.payments.forEach((p: Payment) => setDoc(doc(db, 'payments', p.id), p).catch(() => {}));
      }
      if (data.expenses && Array.isArray(data.expenses)) {
        setExpenses(data.expenses);
        data.expenses.forEach((e: Expense) => setDoc(doc(db, 'expenses', e.id), e).catch(() => {}));
      }
      if (data.factoryMaterials && Array.isArray(data.factoryMaterials)) {
        setFactoryMaterials(data.factoryMaterials);
        data.factoryMaterials.forEach((m: FactoryMaterial) => setDoc(doc(db, 'factoryMaterials', m.id), m).catch(() => {}));
      }
      if (data.bottleCostings && Array.isArray(data.bottleCostings)) {
        setBottleCostings(data.bottleCostings);
        data.bottleCostings.forEach((bc: BottleCostingRecord) => setDoc(doc(db, 'bottleCostings', bc.id), bc).catch(() => {}));
      }
      if (data.cashClosings && Array.isArray(data.cashClosings)) {
        setCashClosings(data.cashClosings);
        data.cashClosings.forEach((cc: CashClosing) => setDoc(doc(db, 'cashClosings', cc.id), cc).catch(() => {}));
      }
      return true;
    } catch (e) {
      console.error("Failed to import backup JSON", e);
      return false;
    }
  };

  return (
    <WaterAppContext.Provider
      value={{
        isAuthenticated,
        currentUser,
        login,
        loginWithGoogle,
        logout,
        switchUserWithCredentials,
        requestPasswordReset,
        userAccounts,
        addUserAccount,
        updateUserAccount,
        deleteUserAccount,
        businessProfile,
        updateBusinessProfile,
        bottleSizes,
        bottleInventory,
        customers,
        customerAllocations,
        customerRates,
        deliveries,
        invoices,
        payments,
        ledgerEntries,
        expenses,
        expenseCategories,
        factoryMaterials,
        bottleCostings,
        monthlyRecurringExpenses,
        cashClosings,
        notifications,
        isDarkMode,
        toggleDarkMode,
        viewMode,
        toggleViewMode,
        activeTab,
        setActiveTab,
        createDelivery,
        updateDeliveryStatus,
        updateDelivery,
        payForDelivery,
        receivePayment,
        addCustomer,
        updateCustomer,
        setCustomerPrice,
        collectEmptyBottles,
        recordRefillBatch,
        purchaseBottles,
        recordDamagedBottles,
        issueBottles,
        resetAllBottleStocksToZero,
        addFactoryMaterial,
        updateFactoryMaterial,
        deleteFactoryMaterial,
        issueMaterial,
        refillMaterial,
        addExpense,
        updateExpense,
        updatePayment,
        approveExpense,
        recordCashClosing,
        updateBottleCosting,
        addBottleSize,
        updateBottleSize,
        deleteBottleSize,
        deleteDelivery,
        deletePayment,
        deleteExpense,
        deleteCustomer,
        resetToDemoData,
        exportBackupJson,
        importBackupJson,
        markNotificationAsRead,
        clearAllNotifications
      }}
    >
      {children}
    </WaterAppContext.Provider>
  );
};

export const useWaterApp = () => {
  const context = useContext(WaterAppContext);
  if (!context) {
    throw new Error('useWaterApp must be used within a WaterAppProvider');
  }
  return context;
};
